<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-12 13:19:14 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:14 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:14 --> No URI present. Default controller set.
DEBUG - 2016-01-12 13:19:14 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:14 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:14 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:14 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:15 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:15 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:15 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Auth MX_Controller Initialized
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:15 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:15 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:15 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:15 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:15 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:15 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:15 --> Admin MX_Controller Initialized
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:19:15 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:19:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:19:15 --> Final output sent to browser
DEBUG - 2016-01-12 13:19:15 --> Total execution time: 0.5541
DEBUG - 2016-01-12 13:19:27 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:27 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:27 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:27 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:27 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:27 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:28 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:28 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Auth MX_Controller Initialized
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:28 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:28 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:28 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:28 --> A session cookie was not found.
DEBUG - 2016-01-12 13:19:28 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:28 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Auth MX_Controller Initialized
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:28 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:19:28 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-12 13:19:28 --> Final output sent to browser
DEBUG - 2016-01-12 13:19:28 --> Total execution time: 0.1742
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Router Class Initialized
ERROR - 2016-01-12 13:19:28 --> 404 Page Not Found --> 
DEBUG - 2016-01-12 13:19:28 --> Router Class Initialized
ERROR - 2016-01-12 13:19:28 --> 404 Page Not Found --> 
ERROR - 2016-01-12 13:19:28 --> 404 Page Not Found --> 
DEBUG - 2016-01-12 13:19:28 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:28 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:28 --> Router Class Initialized
ERROR - 2016-01-12 13:19:28 --> 404 Page Not Found --> 
DEBUG - 2016-01-12 13:19:30 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:30 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:30 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:30 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:30 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:30 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Auth MX_Controller Initialized
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:19:30 --> XSS Filtering completed
DEBUG - 2016-01-12 13:19:30 --> Unable to find validation rule: exists
DEBUG - 2016-01-12 13:19:30 --> XSS Filtering completed
DEBUG - 2016-01-12 13:19:30 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:19:30 --> URI Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Router Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Output Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Security Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Input Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:19:30 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Language Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Config Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Loader Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:19:30 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Session Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:19:30 --> Session routines successfully run
DEBUG - 2016-01-12 13:19:30 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Email Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Controller Class Initialized
DEBUG - 2016-01-12 13:19:30 --> Admin MX_Controller Initialized
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:19:30 --> Model Class Initialized
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:19:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:19:30 --> Final output sent to browser
DEBUG - 2016-01-12 13:19:30 --> Total execution time: 0.2148
DEBUG - 2016-01-12 13:20:51 --> Config Class Initialized
DEBUG - 2016-01-12 13:20:51 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:20:51 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:20:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:20:52 --> URI Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Router Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Output Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Security Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Input Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:20:52 --> Language Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Language Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Config Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Loader Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:20:52 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:20:52 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Session Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:20:52 --> Session routines successfully run
DEBUG - 2016-01-12 13:20:52 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Email Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Controller Class Initialized
DEBUG - 2016-01-12 13:20:52 --> Property MX_Controller Initialized
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:20:52 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:20:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:20:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:53 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:20:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:20:53 --> Final output sent to browser
DEBUG - 2016-01-12 13:20:53 --> Total execution time: 1.9512
DEBUG - 2016-01-12 13:20:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:20:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:20:56 --> URI Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Router Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Output Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Security Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Input Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:20:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Loader Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:20:56 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:20:56 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Session Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:20:56 --> Session routines successfully run
DEBUG - 2016-01-12 13:20:56 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Email Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Controller Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Property MX_Controller Initialized
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:20:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:20:56 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:20:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:20:56 --> Final output sent to browser
DEBUG - 2016-01-12 13:20:56 --> Total execution time: 0.5943
DEBUG - 2016-01-12 13:21:31 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:21:31 --> URI Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Router Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Output Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Security Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Input Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:21:31 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Loader Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:21:31 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Session Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:21:31 --> Session routines successfully run
DEBUG - 2016-01-12 13:21:31 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Email Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Controller Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Property MX_Controller Initialized
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> XSS Filtering completed
DEBUG - 2016-01-12 13:21:31 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:21:31 --> URI Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Router Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Output Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Security Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Input Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:21:31 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Loader Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:21:31 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Session Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:21:31 --> Session routines successfully run
DEBUG - 2016-01-12 13:21:31 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Email Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Controller Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Property MX_Controller Initialized
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:21:31 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:31 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:21:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:21:31 --> Final output sent to browser
DEBUG - 2016-01-12 13:21:31 --> Total execution time: 0.2508
DEBUG - 2016-01-12 13:21:35 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:21:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:21:35 --> URI Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Router Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Output Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Security Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Input Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:21:35 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Language Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Loader Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:21:35 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:21:35 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Session Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:21:35 --> Session routines successfully run
DEBUG - 2016-01-12 13:21:35 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Email Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Controller Class Initialized
DEBUG - 2016-01-12 13:21:35 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:21:35 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:21:36 --> Model Class Initialized
DEBUG - 2016-01-12 13:21:36 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:21:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:21:36 --> Final output sent to browser
DEBUG - 2016-01-12 13:21:36 --> Total execution time: 0.5810
DEBUG - 2016-01-12 13:21:38 --> Config Class Initialized
DEBUG - 2016-01-12 13:21:38 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:21:38 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:21:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:21:38 --> URI Class Initialized
DEBUG - 2016-01-12 13:21:38 --> Router Class Initialized
ERROR - 2016-01-12 13:21:38 --> 404 Page Not Found --> 
DEBUG - 2016-01-12 13:22:00 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:22:00 --> URI Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Router Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Output Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Security Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Input Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:22:00 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Loader Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:22:00 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:22:00 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Session Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:22:00 --> Session routines successfully run
DEBUG - 2016-01-12 13:22:00 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Email Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Controller Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:22:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:00 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:22:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:22:00 --> Final output sent to browser
DEBUG - 2016-01-12 13:22:00 --> Total execution time: 0.4745
DEBUG - 2016-01-12 13:22:22 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:22:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:22:22 --> URI Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Router Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Output Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Security Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Input Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:22:22 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Loader Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:22:22 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Session Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:22:22 --> Session routines successfully run
DEBUG - 2016-01-12 13:22:22 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Email Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Controller Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:22:22 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:22:22 --> XSS Filtering completed
DEBUG - 2016-01-12 13:22:22 --> XSS Filtering completed
DEBUG - 2016-01-12 13:22:22 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:22:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:22:22 --> URI Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Router Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Output Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Security Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Input Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:22:22 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Loader Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:22:22 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Session Class Initialized
DEBUG - 2016-01-12 13:22:22 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:22:22 --> Session routines successfully run
DEBUG - 2016-01-12 13:22:22 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Email Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Controller Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:22:23 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:23 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:22:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:22:23 --> Final output sent to browser
DEBUG - 2016-01-12 13:22:23 --> Total execution time: 0.2512
DEBUG - 2016-01-12 13:22:38 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:22:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:22:38 --> URI Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Router Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Output Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Security Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Input Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:22:38 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Loader Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:22:38 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Session Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:22:38 --> Session routines successfully run
DEBUG - 2016-01-12 13:22:38 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Email Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Controller Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:22:38 --> XSS Filtering completed
DEBUG - 2016-01-12 13:22:38 --> XSS Filtering completed
DEBUG - 2016-01-12 13:22:38 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:22:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:22:38 --> URI Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Router Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Output Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Security Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Input Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:22:38 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Language Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Config Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Loader Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:22:38 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Session Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:22:38 --> Session routines successfully run
DEBUG - 2016-01-12 13:22:38 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Email Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Controller Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:22:38 --> Model Class Initialized
DEBUG - 2016-01-12 13:22:38 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:22:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:22:38 --> Final output sent to browser
DEBUG - 2016-01-12 13:22:38 --> Total execution time: 0.2504
DEBUG - 2016-01-12 13:23:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:23:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:23:01 --> URI Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Router Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Output Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Security Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Input Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:23:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Loader Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:23:01 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Session Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:23:01 --> Session routines successfully run
DEBUG - 2016-01-12 13:23:01 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Email Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Controller Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:23:01 --> XSS Filtering completed
DEBUG - 2016-01-12 13:23:01 --> XSS Filtering completed
DEBUG - 2016-01-12 13:23:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:23:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:23:01 --> URI Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Router Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Output Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Security Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Input Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:23:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Loader Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:23:01 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Session Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:23:01 --> Session routines successfully run
DEBUG - 2016-01-12 13:23:01 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Email Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Controller Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:23:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:01 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:23:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:23:01 --> Final output sent to browser
DEBUG - 2016-01-12 13:23:01 --> Total execution time: 0.2626
DEBUG - 2016-01-12 13:23:10 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:23:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:23:10 --> URI Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Router Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Output Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Security Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Input Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:23:10 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Language Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Config Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Loader Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:23:10 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:23:10 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Session Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:23:10 --> Session routines successfully run
DEBUG - 2016-01-12 13:23:10 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Email Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Controller Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:23:10 --> Model Class Initialized
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:23:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:23:10 --> Final output sent to browser
DEBUG - 2016-01-12 13:23:10 --> Total execution time: 0.6278
DEBUG - 2016-01-12 13:24:20 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:20 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:20 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:20 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:20 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:20 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:24:20 --> XSS Filtering completed
DEBUG - 2016-01-12 13:24:20 --> XSS Filtering completed
DEBUG - 2016-01-12 13:24:20 --> XSS Filtering completed
DEBUG - 2016-01-12 13:24:20 --> XSS Filtering completed
DEBUG - 2016-01-12 13:24:20 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:20 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:20 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:20 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:20 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:20 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:24:20 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:24:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:24:20 --> Final output sent to browser
DEBUG - 2016-01-12 13:24:20 --> Total execution time: 0.3112
DEBUG - 2016-01-12 13:24:37 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:37 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:37 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:37 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:37 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:37 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:37 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:37 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:37 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:24:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:24:37 --> Final output sent to browser
DEBUG - 2016-01-12 13:24:37 --> Total execution time: 0.2668
DEBUG - 2016-01-12 13:24:43 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:43 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:43 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:43 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:43 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:43 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:43 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:43 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:43 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:24:44 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:24:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:24:44 --> Final output sent to browser
DEBUG - 2016-01-12 13:24:44 --> Total execution time: 0.2801
DEBUG - 2016-01-12 13:24:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:56 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:56 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:56 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:56 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:24:56 --> XSS Filtering completed
DEBUG - 2016-01-12 13:24:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:24:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:24:56 --> URI Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Router Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Output Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Security Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Input Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:24:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Language Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Config Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Loader Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:24:56 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Session Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:24:56 --> Session routines successfully run
DEBUG - 2016-01-12 13:24:56 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Email Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Controller Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:24:56 --> Model Class Initialized
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:24:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:24:56 --> Final output sent to browser
DEBUG - 2016-01-12 13:24:57 --> Total execution time: 0.3383
DEBUG - 2016-01-12 13:25:53 --> Config Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:25:53 --> URI Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Router Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Output Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Security Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Input Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:25:53 --> Language Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Language Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Config Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Loader Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:25:53 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Session Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:25:53 --> Session routines successfully run
DEBUG - 2016-01-12 13:25:53 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Email Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Controller Class Initialized
DEBUG - 2016-01-12 13:25:53 --> leases MX_Controller Initialized
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-12 13:25:53 --> XSS Filtering completed
DEBUG - 2016-01-12 13:25:53 --> XSS Filtering completed
DEBUG - 2016-01-12 13:25:53 --> XSS Filtering completed
DEBUG - 2016-01-12 13:25:53 --> XSS Filtering completed
DEBUG - 2016-01-12 13:25:53 --> Config Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:25:53 --> URI Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Router Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Output Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Security Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Input Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:25:53 --> Language Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Language Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Config Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Loader Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:25:53 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Session Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:25:53 --> Session routines successfully run
DEBUG - 2016-01-12 13:25:53 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Email Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Controller Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:25:53 --> Model Class Initialized
DEBUG - 2016-01-12 13:25:53 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:25:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:25:54 --> Final output sent to browser
DEBUG - 2016-01-12 13:25:54 --> Total execution time: 0.3663
DEBUG - 2016-01-12 13:26:16 --> Config Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:26:16 --> URI Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Router Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Output Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Security Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Input Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:26:16 --> Language Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Language Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Config Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Loader Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:26:16 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:26:16 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Session Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:26:16 --> Session routines successfully run
DEBUG - 2016-01-12 13:26:16 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Email Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Controller Class Initialized
DEBUG - 2016-01-12 13:26:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-12 13:26:16 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:26:16 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:26:16 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-12 13:26:17 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:26:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:26:17 --> Final output sent to browser
DEBUG - 2016-01-12 13:26:17 --> Total execution time: 0.5807
DEBUG - 2016-01-12 13:26:26 --> Config Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:26:26 --> URI Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Router Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Output Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Security Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Input Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:26:26 --> Language Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Language Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Config Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Loader Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:26:26 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:26:26 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Session Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:26:26 --> Session routines successfully run
DEBUG - 2016-01-12 13:26:26 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Email Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Controller Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-12 13:26:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:26:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:26:26 --> Final output sent to browser
DEBUG - 2016-01-12 13:26:26 --> Total execution time: 0.3551
DEBUG - 2016-01-12 13:27:40 --> Config Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:27:40 --> URI Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Router Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Output Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Security Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Input Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:27:40 --> Language Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Language Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Config Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Loader Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:27:40 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:27:40 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Session Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:27:40 --> Session routines successfully run
DEBUG - 2016-01-12 13:27:40 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Email Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Controller Class Initialized
DEBUG - 2016-01-12 13:27:40 --> Water_management MX_Controller Initialized
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-12 13:27:40 --> Model Class Initialized
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:27:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:27:40 --> Final output sent to browser
DEBUG - 2016-01-12 13:27:40 --> Total execution time: 0.3825
DEBUG - 2016-01-12 13:28:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:28:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:28:01 --> URI Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Router Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Output Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Security Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Input Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:28:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Language Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Config Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Loader Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:28:01 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:28:01 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Session Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:28:01 --> Session routines successfully run
DEBUG - 2016-01-12 13:28:01 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Email Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Controller Class Initialized
DEBUG - 2016-01-12 13:28:01 --> Water_management MX_Controller Initialized
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-12 13:28:01 --> Model Class Initialized
DEBUG - 2016-01-12 13:28:01 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2016-01-12 13:28:01 --> Final output sent to browser
DEBUG - 2016-01-12 13:28:01 --> Total execution time: 0.3357
DEBUG - 2016-01-12 13:34:03 --> Config Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:34:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:34:03 --> URI Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Router Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Output Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Security Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Input Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:34:03 --> Language Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Language Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Config Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Loader Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:34:03 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:34:03 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Session Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:34:03 --> Session routines successfully run
DEBUG - 2016-01-12 13:34:03 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Email Class Initialized
DEBUG - 2016-01-12 13:34:03 --> Controller Class Initialized
DEBUG - 2016-01-12 13:34:03 --> leases MX_Controller Initialized
DEBUG - 2016-01-12 13:34:03 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:34:03 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-12 13:34:03 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:34:03 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-12 13:34:04 --> Model Class Initialized
DEBUG - 2016-01-12 13:34:04 --> Image Lib Class Initialized
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/views/leases/lease_details.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/real_estate_administration/views/leases/all_leases.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:34:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:34:04 --> Final output sent to browser
DEBUG - 2016-01-12 13:34:04 --> Total execution time: 0.4181
DEBUG - 2016-01-12 13:36:59 --> Config Class Initialized
DEBUG - 2016-01-12 13:36:59 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:36:59 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:36:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:36:59 --> URI Class Initialized
DEBUG - 2016-01-12 13:36:59 --> Router Class Initialized
DEBUG - 2016-01-12 13:36:59 --> Output Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Security Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Input Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:37:00 --> Language Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Language Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Config Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Loader Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:37:00 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:37:00 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Session Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:37:00 --> Session routines successfully run
DEBUG - 2016-01-12 13:37:00 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Email Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Controller Class Initialized
DEBUG - 2016-01-12 13:37:00 --> Water_management MX_Controller Initialized
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-12 13:37:00 --> Model Class Initialized
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-12 13:37:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-12 13:37:00 --> Final output sent to browser
DEBUG - 2016-01-12 13:37:00 --> Total execution time: 0.2830
DEBUG - 2016-01-12 13:59:24 --> Config Class Initialized
DEBUG - 2016-01-12 13:59:24 --> Hooks Class Initialized
DEBUG - 2016-01-12 13:59:24 --> Utf8 Class Initialized
DEBUG - 2016-01-12 13:59:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-12 13:59:24 --> URI Class Initialized
DEBUG - 2016-01-12 13:59:24 --> Router Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Output Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Security Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Input Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-12 13:59:25 --> Language Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Language Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Config Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Loader Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Helper loaded: url_helper
DEBUG - 2016-01-12 13:59:25 --> Helper loaded: form_helper
DEBUG - 2016-01-12 13:59:25 --> Database Driver Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Session Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Helper loaded: string_helper
DEBUG - 2016-01-12 13:59:25 --> Session routines successfully run
DEBUG - 2016-01-12 13:59:25 --> Form Validation Class Initialized
DEBUG - 2016-01-12 13:59:25 --> Pagination Class Initialized
DEBUG - 2016-01-12 13:59:26 --> Encrypt Class Initialized
DEBUG - 2016-01-12 13:59:26 --> Email Class Initialized
DEBUG - 2016-01-12 13:59:26 --> Controller Class Initialized
DEBUG - 2016-01-12 13:59:26 --> Water_management MX_Controller Initialized
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-12 13:59:26 --> Model Class Initialized
DEBUG - 2016-01-12 13:59:26 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2016-01-12 13:59:26 --> Final output sent to browser
DEBUG - 2016-01-12 13:59:26 --> Total execution time: 2.4962
