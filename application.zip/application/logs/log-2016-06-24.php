<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-06-24 08:05:29 --> Config Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:05:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:05:29 --> URI Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Router Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Output Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Security Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Input Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:05:29 --> Language Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Language Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Config Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Loader Class Initialized
DEBUG - 2016-06-24 08:05:29 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:05:29 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:05:29 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:05:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:05:31 --> Session Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:05:31 --> A session cookie was not found.
DEBUG - 2016-06-24 08:05:31 --> Session routines successfully run
DEBUG - 2016-06-24 08:05:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Email Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Controller Class Initialized
DEBUG - 2016-06-24 08:05:31 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:05:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:05:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:05:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:05:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:05:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/video_promotion.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/promotion.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:05:31 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:05:31 --> Final output sent to browser
DEBUG - 2016-06-24 08:05:31 --> Total execution time: 1.7521
DEBUG - 2016-06-24 08:06:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:06:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:06:03 --> URI Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Router Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Output Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Security Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Input Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:06:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Loader Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:06:03 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:06:03 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:06:03 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:06:03 --> Session Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:06:03 --> Session routines successfully run
DEBUG - 2016-06-24 08:06:03 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Email Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Controller Class Initialized
DEBUG - 2016-06-24 08:06:03 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:06:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:06:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:06:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:06:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:06:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:06:03 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:06:03 --> Final output sent to browser
DEBUG - 2016-06-24 08:06:03 --> Total execution time: 0.3193
DEBUG - 2016-06-24 08:06:39 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:06:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:06:39 --> URI Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Router Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Output Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Security Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Input Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:06:39 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Loader Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:06:39 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:06:39 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:06:39 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:06:39 --> Session Class Initialized
DEBUG - 2016-06-24 08:06:39 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:06:40 --> Session routines successfully run
DEBUG - 2016-06-24 08:06:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Email Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Controller Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:06:40 --> Final output sent to browser
DEBUG - 2016-06-24 08:06:40 --> Total execution time: 0.5075
DEBUG - 2016-06-24 08:06:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:06:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:06:40 --> URI Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Router Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Output Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Security Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Input Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:06:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Loader Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:06:40 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:06:40 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:06:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:06:40 --> Session Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:06:40 --> Session routines successfully run
DEBUG - 2016-06-24 08:06:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Email Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Controller Class Initialized
DEBUG - 2016-06-24 08:06:40 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:06:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:06:40 --> Severity: Notice  --> Undefined property: stdClass::$property_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:06:40 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:06:41 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:06:41 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:06:41 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:06:41 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:06:41 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:06:41 --> Final output sent to browser
DEBUG - 2016-06-24 08:06:41 --> Total execution time: 0.1845
DEBUG - 2016-06-24 08:06:49 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:06:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:06:49 --> URI Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Router Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Output Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Security Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Input Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:06:49 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Language Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Config Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Loader Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:06:49 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:06:49 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:06:49 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:06:49 --> Session Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:06:49 --> Session routines successfully run
DEBUG - 2016-06-24 08:06:49 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Email Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Controller Class Initialized
DEBUG - 2016-06-24 08:06:49 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:06:49 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:06:49 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:06:49 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:49 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:06:49 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:49 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:06:49 --> Model Class Initialized
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:06:50 --> Severity: Notice  --> Undefined property: stdClass::$property_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:06:50 --> Severity: Notice  --> Undefined property: stdClass::$property_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:06:50 --> Severity: Notice  --> Undefined property: stdClass::$property_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:06:50 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:06:50 --> Final output sent to browser
DEBUG - 2016-06-24 08:06:50 --> Total execution time: 0.2680
DEBUG - 2016-06-24 08:08:45 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:08:45 --> URI Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Router Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Output Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Security Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Input Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:08:45 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Loader Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:08:45 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:08:45 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:08:45 --> Session Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:08:45 --> Session routines successfully run
DEBUG - 2016-06-24 08:08:45 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Email Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Controller Class Initialized
DEBUG - 2016-06-24 08:08:45 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:08:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:08:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:08:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:08:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:08:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:08:45 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:08:45 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:08:45 --> Final output sent to browser
DEBUG - 2016-06-24 08:08:45 --> Total execution time: 0.2320
DEBUG - 2016-06-24 08:08:46 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:08:46 --> URI Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Router Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Output Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Security Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Input Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:08:46 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Loader Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:08:46 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:08:46 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:08:46 --> Session Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:08:46 --> Session routines successfully run
DEBUG - 2016-06-24 08:08:46 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Email Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Controller Class Initialized
DEBUG - 2016-06-24 08:08:46 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:08:46 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:08:46 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:08:46 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:08:46 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:08:46 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:08:46 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:08:46 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:08:46 --> Final output sent to browser
DEBUG - 2016-06-24 08:08:46 --> Total execution time: 0.1710
DEBUG - 2016-06-24 08:08:55 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:08:55 --> URI Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Router Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Output Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Security Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Input Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:08:55 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Language Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Config Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Loader Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:08:55 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:08:55 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:08:55 --> Session Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:08:55 --> Session routines successfully run
DEBUG - 2016-06-24 08:08:55 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Email Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Controller Class Initialized
DEBUG - 2016-06-24 08:08:55 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:08:55 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:08:55 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:08:55 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:08:55 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:08:55 --> Model Class Initialized
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:08:55 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:08:55 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:08:55 --> Final output sent to browser
DEBUG - 2016-06-24 08:08:55 --> Total execution time: 0.1650
DEBUG - 2016-06-24 08:09:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:09:58 --> URI Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Router Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Output Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Security Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Input Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:09:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Loader Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:09:58 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:09:58 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:09:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:09:58 --> Session Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:09:58 --> Session routines successfully run
DEBUG - 2016-06-24 08:09:58 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Email Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Controller Class Initialized
DEBUG - 2016-06-24 08:09:58 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:09:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:09:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:09:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:09:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:09:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:09:58 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:09:58 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:09:58 --> Final output sent to browser
DEBUG - 2016-06-24 08:09:58 --> Total execution time: 0.2620
DEBUG - 2016-06-24 08:09:59 --> Config Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:09:59 --> URI Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Router Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Output Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Security Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Input Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:09:59 --> Language Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Language Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Config Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Loader Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:09:59 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:09:59 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:09:59 --> Session Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:09:59 --> Session routines successfully run
DEBUG - 2016-06-24 08:09:59 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Email Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Controller Class Initialized
DEBUG - 2016-06-24 08:09:59 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:09:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:09:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:09:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:09:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:09:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:09:59 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:09:59 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:09:59 --> Final output sent to browser
DEBUG - 2016-06-24 08:09:59 --> Total execution time: 0.1790
DEBUG - 2016-06-24 08:10:34 --> Config Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:10:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:10:34 --> URI Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Router Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Output Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Security Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Input Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:10:34 --> Language Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Language Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Config Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Loader Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:10:34 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:10:34 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:10:34 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:10:34 --> Session Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:10:34 --> Session routines successfully run
DEBUG - 2016-06-24 08:10:34 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Email Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Controller Class Initialized
DEBUG - 2016-06-24 08:10:34 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:10:34 --> Model Class Initialized
DEBUG - 2016-06-24 08:10:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:10:34 --> Model Class Initialized
DEBUG - 2016-06-24 08:10:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:10:34 --> Model Class Initialized
DEBUG - 2016-06-24 08:10:34 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:10:34 --> Model Class Initialized
DEBUG - 2016-06-24 08:10:34 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:10:34 --> Model Class Initialized
DEBUG - 2016-06-24 08:10:34 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/home/latest.php
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_price C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 21
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 22
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_id C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 23
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_name C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 24
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_description C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 25
ERROR - 2016-06-24 08:10:35 --> Severity: Notice  --> Undefined property: stdClass::$retail_unit_size C:\xampp\htdocs\omnis_rents\application\modules\site\views\home\featured.php 29
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:10:35 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:10:35 --> Final output sent to browser
DEBUG - 2016-06-24 08:10:35 --> Total execution time: 0.4180
DEBUG - 2016-06-24 08:18:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:18:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:18:50 --> URI Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Router Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Output Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Security Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Input Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:18:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Loader Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:18:50 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:18:50 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:18:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:18:50 --> Session Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:18:50 --> Session routines successfully run
DEBUG - 2016-06-24 08:18:50 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Email Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Controller Class Initialized
DEBUG - 2016-06-24 08:18:50 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:18:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:18:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:18:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:18:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:18:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:18:50 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:19:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:19:58 --> URI Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Router Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Output Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Security Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Input Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:19:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Loader Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:19:58 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:19:58 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:19:58 --> Session Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:19:58 --> Session routines successfully run
DEBUG - 2016-06-24 08:19:58 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Email Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Controller Class Initialized
DEBUG - 2016-06-24 08:19:58 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:19:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:19:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:19:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:19:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:19:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:19:58 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:19:58 --> Final output sent to browser
DEBUG - 2016-06-24 08:19:58 --> Total execution time: 0.2230
DEBUG - 2016-06-24 08:24:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:24:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:24:35 --> URI Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Router Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Output Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Security Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Input Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:24:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Loader Class Initialized
DEBUG - 2016-06-24 08:24:35 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:24:35 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:24:35 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:24:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:24:35 --> Session Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:24:36 --> Session routines successfully run
DEBUG - 2016-06-24 08:24:36 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Email Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Controller Class Initialized
DEBUG - 2016-06-24 08:24:36 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:24:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:24:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:24:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:24:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:24:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:24:36 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:24:36 --> Final output sent to browser
DEBUG - 2016-06-24 08:24:36 --> Total execution time: 0.0975
DEBUG - 2016-06-24 08:25:59 --> Config Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:25:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:25:59 --> URI Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Router Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Output Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Security Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Input Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:25:59 --> Language Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Language Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Config Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Loader Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:25:59 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:25:59 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:25:59 --> Session Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:25:59 --> Session routines successfully run
DEBUG - 2016-06-24 08:25:59 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Email Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Controller Class Initialized
DEBUG - 2016-06-24 08:25:59 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:25:59 --> Model Class Initialized
DEBUG - 2016-06-24 08:25:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:26:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:26:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:26:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:26:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:26:00 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:26:00 --> Final output sent to browser
DEBUG - 2016-06-24 08:26:00 --> Total execution time: 0.2660
DEBUG - 2016-06-24 08:26:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:26:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:26:40 --> URI Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Router Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Output Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Security Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Input Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:26:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Loader Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:26:40 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:26:40 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:26:40 --> Session Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:26:40 --> Session routines successfully run
DEBUG - 2016-06-24 08:26:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Email Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Controller Class Initialized
DEBUG - 2016-06-24 08:26:40 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:26:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:26:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:26:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:26:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:26:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:26:40 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:26:40 --> Final output sent to browser
DEBUG - 2016-06-24 08:26:40 --> Total execution time: 0.2350
DEBUG - 2016-06-24 08:26:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:26:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:26:58 --> URI Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Router Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Output Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Security Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Input Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:26:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Language Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Config Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Loader Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:26:58 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:26:58 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:26:58 --> Session Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:26:58 --> Session routines successfully run
DEBUG - 2016-06-24 08:26:58 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Email Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Controller Class Initialized
DEBUG - 2016-06-24 08:26:58 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:26:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:26:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:26:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:26:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:26:58 --> Model Class Initialized
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:26:58 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:26:58 --> Final output sent to browser
DEBUG - 2016-06-24 08:26:58 --> Total execution time: 0.1663
DEBUG - 2016-06-24 08:27:46 --> Config Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:27:46 --> URI Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Router Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Output Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Security Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Input Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:27:46 --> Language Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Language Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Config Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Loader Class Initialized
DEBUG - 2016-06-24 08:27:46 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:27:46 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:27:47 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:27:47 --> Session Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:27:47 --> Session routines successfully run
DEBUG - 2016-06-24 08:27:47 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Email Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Controller Class Initialized
DEBUG - 2016-06-24 08:27:47 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:27:47 --> Model Class Initialized
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:27:47 --> Model Class Initialized
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:27:47 --> Model Class Initialized
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:27:47 --> Model Class Initialized
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:27:47 --> Model Class Initialized
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:27:47 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:27:47 --> Final output sent to browser
DEBUG - 2016-06-24 08:27:47 --> Total execution time: 0.1710
DEBUG - 2016-06-24 08:32:23 --> Config Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:32:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:32:23 --> URI Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Router Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Output Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Security Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Input Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:32:23 --> Language Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Language Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Config Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Loader Class Initialized
DEBUG - 2016-06-24 08:32:23 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:32:23 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:32:24 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:32:24 --> Session Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:32:24 --> Session routines successfully run
DEBUG - 2016-06-24 08:32:24 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Email Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Controller Class Initialized
DEBUG - 2016-06-24 08:32:24 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:32:24 --> Model Class Initialized
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:32:24 --> Model Class Initialized
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:32:24 --> Model Class Initialized
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:32:24 --> Model Class Initialized
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:32:24 --> Model Class Initialized
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:32:24 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:32:24 --> Final output sent to browser
DEBUG - 2016-06-24 08:32:24 --> Total execution time: 0.3400
DEBUG - 2016-06-24 08:37:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:35 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Output Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Security Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Input Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:37:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Loader Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:37:35 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:37:35 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:37:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:37:35 --> Session Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:37:35 --> Session routines successfully run
DEBUG - 2016-06-24 08:37:35 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Email Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Controller Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Auth MX_Controller Initialized
DEBUG - 2016-06-24 08:37:35 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:37:35 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:37:35 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-06-24 08:37:35 --> XSS Filtering completed
DEBUG - 2016-06-24 08:37:35 --> Unable to find validation rule: exists
DEBUG - 2016-06-24 08:37:35 --> XSS Filtering completed
DEBUG - 2016-06-24 08:37:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:37:35 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-06-24 08:37:35 --> Final output sent to browser
DEBUG - 2016-06-24 08:37:35 --> Total execution time: 0.3160
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:37:36 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:36 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:36 --> Router Class Initialized
ERROR - 2016-06-24 08:37:36 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:37:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:40 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Output Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Security Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Input Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:37:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Loader Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:37:40 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:37:40 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:37:40 --> Session Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:37:40 --> Session routines successfully run
DEBUG - 2016-06-24 08:37:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Email Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Controller Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Auth MX_Controller Initialized
DEBUG - 2016-06-24 08:37:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:37:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:37:40 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-06-24 08:37:40 --> XSS Filtering completed
DEBUG - 2016-06-24 08:37:40 --> Unable to find validation rule: exists
DEBUG - 2016-06-24 08:37:40 --> XSS Filtering completed
DEBUG - 2016-06-24 08:37:41 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:41 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Output Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Security Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Input Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:37:41 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Loader Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:37:41 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:37:41 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:37:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:37:41 --> Session Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:37:41 --> Session routines successfully run
DEBUG - 2016-06-24 08:37:41 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Email Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Controller Class Initialized
DEBUG - 2016-06-24 08:37:41 --> Admin MX_Controller Initialized
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:37:41 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:37:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:37:41 --> Final output sent to browser
DEBUG - 2016-06-24 08:37:41 --> Total execution time: 0.5760
DEBUG - 2016-06-24 08:37:43 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:43 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:43 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:43 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:43 --> Router Class Initialized
ERROR - 2016-06-24 08:37:43 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:37:44 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:44 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:44 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:44 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:44 --> Router Class Initialized
ERROR - 2016-06-24 08:37:44 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:37:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:50 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Router Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Output Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Security Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Input Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:37:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Loader Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:37:50 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:37:50 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:37:50 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:37:50 --> Session Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:37:50 --> Session routines successfully run
DEBUG - 2016-06-24 08:37:50 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Email Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Controller Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Property MX_Controller Initialized
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:37:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:37:50 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:37:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:37:50 --> Final output sent to browser
DEBUG - 2016-06-24 08:37:50 --> Total execution time: 0.3610
DEBUG - 2016-06-24 08:37:53 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:53 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Router Class Initialized
ERROR - 2016-06-24 08:37:53 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:37:53 --> Config Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:37:53 --> URI Class Initialized
DEBUG - 2016-06-24 08:37:53 --> Router Class Initialized
ERROR - 2016-06-24 08:37:53 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:02 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:02 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:02 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:02 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:02 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:02 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:02 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:02 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Property MX_Controller Initialized
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:02 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:02 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:02 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:02 --> Total execution time: 0.1800
DEBUG - 2016-06-24 08:38:04 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:04 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:04 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:04 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:04 --> Router Class Initialized
ERROR - 2016-06-24 08:38:04 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:38:04 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:16 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:16 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:16 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:16 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:17 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:17 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:17 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:17 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:17 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Property MX_Controller Initialized
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:17 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:17 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:17 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:17 --> Total execution time: 0.1350
DEBUG - 2016-06-24 08:38:18 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:18 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:18 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:18 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:18 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:18 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:18 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:18 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:18 --> URI Class Initialized
ERROR - 2016-06-24 08:38:18 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:18 --> Router Class Initialized
ERROR - 2016-06-24 08:38:18 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:21 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:21 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:21 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:21 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:21 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:21 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:21 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:21 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Property MX_Controller Initialized
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:21 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:21 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/real_estate_administration/views/property/add_property.php
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:21 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:21 --> Total execution time: 0.1980
DEBUG - 2016-06-24 08:38:24 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:24 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Router Class Initialized
ERROR - 2016-06-24 08:38:24 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:24 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:24 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:24 --> Router Class Initialized
ERROR - 2016-06-24 08:38:24 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:25 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:25 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:25 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:25 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:25 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:25 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:25 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:25 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Property MX_Controller Initialized
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:25 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:25 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:25 --> Total execution time: 0.1190
DEBUG - 2016-06-24 08:38:29 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:29 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:29 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:29 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:29 --> Router Class Initialized
ERROR - 2016-06-24 08:38:29 --> 404 Page Not Found --> 
ERROR - 2016-06-24 08:38:29 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:31 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:31 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:31 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:31 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:31 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:31 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:31 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:38:31 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:31 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:31 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:31 --> Total execution time: 0.1650
DEBUG - 2016-06-24 08:38:33 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:33 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Router Class Initialized
ERROR - 2016-06-24 08:38:33 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:33 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:33 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:33 --> Router Class Initialized
ERROR - 2016-06-24 08:38:33 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:50 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Router Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Output Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Security Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Input Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:38:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Loader Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:38:50 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:38:50 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:38:50 --> Session Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:38:50 --> Session routines successfully run
DEBUG - 2016-06-24 08:38:50 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Email Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Controller Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:38:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:38:50 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/real_estate_administration/views/rental_unit/add_rental_unit.php
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:38:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:38:50 --> Final output sent to browser
DEBUG - 2016-06-24 08:38:50 --> Total execution time: 0.1150
DEBUG - 2016-06-24 08:38:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:52 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Router Class Initialized
ERROR - 2016-06-24 08:38:52 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:38:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:38:52 --> URI Class Initialized
DEBUG - 2016-06-24 08:38:52 --> Router Class Initialized
ERROR - 2016-06-24 08:38:52 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:09 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:09 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Router Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Output Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Security Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Input Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:39:09 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Loader Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:39:09 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:39:09 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:39:09 --> Session Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:39:09 --> Session routines successfully run
DEBUG - 2016-06-24 08:39:09 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Email Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Controller Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:39:09 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:09 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:39:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:39:09 --> Final output sent to browser
DEBUG - 2016-06-24 08:39:09 --> Total execution time: 0.1190
DEBUG - 2016-06-24 08:39:11 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:11 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:11 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:11 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:11 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:11 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:11 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:11 --> Router Class Initialized
DEBUG - 2016-06-24 08:39:11 --> URI Class Initialized
ERROR - 2016-06-24 08:39:11 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:11 --> Router Class Initialized
ERROR - 2016-06-24 08:39:11 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:13 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:13 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Router Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Output Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Security Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Input Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:39:13 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Loader Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:39:13 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:39:13 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:39:13 --> Session Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:39:13 --> Session routines successfully run
DEBUG - 2016-06-24 08:39:13 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Email Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Controller Class Initialized
DEBUG - 2016-06-24 08:39:13 --> Sub_units MX_Controller Initialized
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:39:13 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:39:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:39:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/real_estate_administration/models/units_model.php
DEBUG - 2016-06-24 08:39:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:39:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:39:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:14 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/real_estate_administration/views/units/all_units.php
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:39:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:39:14 --> Final output sent to browser
DEBUG - 2016-06-24 08:39:14 --> Total execution time: 0.5090
DEBUG - 2016-06-24 08:39:16 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:16 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Router Class Initialized
ERROR - 2016-06-24 08:39:16 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:16 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:16 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:16 --> Router Class Initialized
ERROR - 2016-06-24 08:39:16 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:19 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:19 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Router Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Output Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Security Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Input Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:39:19 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Language Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Loader Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:39:19 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:39:19 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-06-24 08:39:19 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:39:19 --> Session Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:39:19 --> Session routines successfully run
DEBUG - 2016-06-24 08:39:19 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:39:19 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:39:20 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:39:20 --> Email Class Initialized
DEBUG - 2016-06-24 08:39:20 --> Controller Class Initialized
DEBUG - 2016-06-24 08:39:20 --> Sub_units MX_Controller Initialized
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/real_estate_administration/models/units_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:39:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:39:20 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/real_estate_administration/views/units/add_units.php
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:39:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:39:20 --> Final output sent to browser
DEBUG - 2016-06-24 08:39:20 --> Total execution time: 0.2300
DEBUG - 2016-06-24 08:39:22 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:22 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Router Class Initialized
ERROR - 2016-06-24 08:39:22 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:39:22 --> Config Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:39:22 --> URI Class Initialized
DEBUG - 2016-06-24 08:39:22 --> Router Class Initialized
ERROR - 2016-06-24 08:39:22 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:40:44 --> Config Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:40:44 --> URI Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Router Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Output Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Security Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Input Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:40:44 --> Language Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Language Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Config Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Loader Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:40:44 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:40:44 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:40:44 --> Session Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:40:44 --> Session routines successfully run
DEBUG - 2016-06-24 08:40:44 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Email Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Controller Class Initialized
DEBUG - 2016-06-24 08:40:44 --> Sub_units MX_Controller Initialized
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-06-24 08:40:44 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:40:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/real_estate_administration/models/units_model.php
DEBUG - 2016-06-24 08:40:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-06-24 08:40:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-06-24 08:40:45 --> Model Class Initialized
DEBUG - 2016-06-24 08:40:45 --> Image Lib Class Initialized
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/real_estate_administration/views/units/all_units.php
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-06-24 08:40:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-06-24 08:40:45 --> Final output sent to browser
DEBUG - 2016-06-24 08:40:45 --> Total execution time: 0.1120
DEBUG - 2016-06-24 08:40:47 --> Config Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:40:47 --> URI Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Router Class Initialized
ERROR - 2016-06-24 08:40:47 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:40:47 --> Config Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:40:47 --> URI Class Initialized
DEBUG - 2016-06-24 08:40:47 --> Router Class Initialized
ERROR - 2016-06-24 08:40:47 --> 404 Page Not Found --> 
DEBUG - 2016-06-24 08:42:37 --> Config Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:42:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:42:37 --> URI Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Router Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Output Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Security Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Input Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:42:37 --> Language Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Language Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Config Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Loader Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:42:37 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:42:37 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:42:37 --> Session Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:42:37 --> Session routines successfully run
DEBUG - 2016-06-24 08:42:37 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Email Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Controller Class Initialized
DEBUG - 2016-06-24 08:42:37 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:42:37 --> Model Class Initialized
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:42:37 --> Model Class Initialized
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:42:37 --> Model Class Initialized
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:42:37 --> Model Class Initialized
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:42:37 --> Model Class Initialized
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:42:37 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:42:37 --> Final output sent to browser
DEBUG - 2016-06-24 08:42:37 --> Total execution time: 0.1970
DEBUG - 2016-06-24 08:43:24 --> Config Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:43:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:43:24 --> URI Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Router Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Output Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Security Class Initialized
DEBUG - 2016-06-24 08:43:24 --> Input Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:43:25 --> Language Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Language Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Config Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Loader Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:43:25 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:43:25 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:43:25 --> Session Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:43:25 --> Session routines successfully run
DEBUG - 2016-06-24 08:43:25 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Email Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Controller Class Initialized
DEBUG - 2016-06-24 08:43:25 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:43:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:43:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:43:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:43:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:43:25 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:43:25 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:43:25 --> Final output sent to browser
DEBUG - 2016-06-24 08:43:25 --> Total execution time: 0.1510
DEBUG - 2016-06-24 08:43:54 --> Config Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:43:54 --> URI Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Router Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Output Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Security Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Input Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:43:54 --> Language Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Language Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Config Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Loader Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:43:54 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:43:54 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:43:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:43:54 --> Session Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:43:54 --> Session routines successfully run
DEBUG - 2016-06-24 08:43:54 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Email Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Controller Class Initialized
DEBUG - 2016-06-24 08:43:54 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:43:54 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:43:54 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:43:54 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:43:54 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:43:54 --> Model Class Initialized
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:43:54 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:43:54 --> Final output sent to browser
DEBUG - 2016-06-24 08:43:54 --> Total execution time: 0.2425
DEBUG - 2016-06-24 08:44:28 --> Config Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:44:28 --> URI Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Router Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Output Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Security Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Input Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:44:28 --> Language Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Language Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Config Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Loader Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:44:28 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:44:28 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:44:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:44:28 --> Session Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:44:28 --> Session routines successfully run
DEBUG - 2016-06-24 08:44:28 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Email Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Controller Class Initialized
DEBUG - 2016-06-24 08:44:28 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:44:28 --> Model Class Initialized
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:44:28 --> Model Class Initialized
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:44:28 --> Model Class Initialized
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:44:28 --> Model Class Initialized
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:44:28 --> Model Class Initialized
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:44:28 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:44:28 --> Final output sent to browser
DEBUG - 2016-06-24 08:44:28 --> Total execution time: 0.1420
DEBUG - 2016-06-24 08:45:11 --> Config Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:45:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:45:11 --> URI Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Router Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Output Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Security Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Input Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:45:11 --> Language Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Language Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Config Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Loader Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:45:11 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:45:11 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:45:11 --> Session Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:45:11 --> Session routines successfully run
DEBUG - 2016-06-24 08:45:11 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Email Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Controller Class Initialized
DEBUG - 2016-06-24 08:45:11 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:45:11 --> Model Class Initialized
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:45:11 --> Model Class Initialized
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:45:11 --> Model Class Initialized
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:45:11 --> Model Class Initialized
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:45:11 --> Model Class Initialized
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:45:11 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:45:11 --> Final output sent to browser
DEBUG - 2016-06-24 08:45:11 --> Total execution time: 0.1900
DEBUG - 2016-06-24 08:46:14 --> Config Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:46:14 --> URI Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Router Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Output Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Security Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Input Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:46:14 --> Language Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Language Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Config Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Loader Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:46:14 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:46:14 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:46:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:46:14 --> Session Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:46:14 --> Session routines successfully run
DEBUG - 2016-06-24 08:46:14 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Email Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Controller Class Initialized
DEBUG - 2016-06-24 08:46:14 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:46:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:46:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:46:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:46:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:46:14 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:46:14 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:46:14 --> Final output sent to browser
DEBUG - 2016-06-24 08:46:14 --> Total execution time: 0.2200
DEBUG - 2016-06-24 08:46:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:46:52 --> URI Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Router Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Output Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Security Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Input Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:46:52 --> Language Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Language Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Loader Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:46:52 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:46:52 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:46:52 --> Session Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:46:52 --> Session routines successfully run
DEBUG - 2016-06-24 08:46:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Email Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Controller Class Initialized
DEBUG - 2016-06-24 08:46:52 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:46:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:46:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:46:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:46:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:46:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:46:52 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:46:52 --> Final output sent to browser
DEBUG - 2016-06-24 08:46:52 --> Total execution time: 0.2450
DEBUG - 2016-06-24 08:48:38 --> Config Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:48:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:48:38 --> URI Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Router Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Output Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Security Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Input Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:48:38 --> Language Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Language Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Config Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Loader Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:48:38 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:48:38 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:48:38 --> Session Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:48:38 --> Session routines successfully run
DEBUG - 2016-06-24 08:48:38 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Email Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Controller Class Initialized
DEBUG - 2016-06-24 08:48:38 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:48:38 --> Model Class Initialized
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:48:38 --> Model Class Initialized
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:48:38 --> Model Class Initialized
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:48:38 --> Model Class Initialized
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:48:38 --> Model Class Initialized
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:48:38 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:48:38 --> Final output sent to browser
DEBUG - 2016-06-24 08:48:38 --> Total execution time: 0.2260
DEBUG - 2016-06-24 08:50:18 --> Config Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:50:18 --> URI Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Router Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Output Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Security Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Input Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:50:18 --> Language Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Language Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Config Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Loader Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:50:18 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:50:18 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:50:18 --> Session Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:50:18 --> Session routines successfully run
DEBUG - 2016-06-24 08:50:18 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Email Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Controller Class Initialized
DEBUG - 2016-06-24 08:50:18 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:50:18 --> Model Class Initialized
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:50:18 --> Model Class Initialized
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:50:18 --> Model Class Initialized
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:50:18 --> Model Class Initialized
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:50:18 --> Model Class Initialized
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:50:18 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:50:18 --> Final output sent to browser
DEBUG - 2016-06-24 08:50:18 --> Total execution time: 0.2445
DEBUG - 2016-06-24 08:51:08 --> Config Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:51:08 --> URI Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Router Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Output Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Security Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Input Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:51:08 --> Language Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Language Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Config Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Loader Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:51:08 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:51:08 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:51:08 --> Session Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:51:08 --> Session routines successfully run
DEBUG - 2016-06-24 08:51:08 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Email Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Controller Class Initialized
DEBUG - 2016-06-24 08:51:08 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:51:08 --> Model Class Initialized
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:51:08 --> Model Class Initialized
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:51:08 --> Model Class Initialized
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:51:08 --> Model Class Initialized
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:51:08 --> Model Class Initialized
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:51:08 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:51:08 --> Final output sent to browser
DEBUG - 2016-06-24 08:51:08 --> Total execution time: 0.1350
DEBUG - 2016-06-24 08:54:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:54:03 --> URI Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Router Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Output Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Security Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Input Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:54:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Loader Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:54:03 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:54:03 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:54:03 --> Session Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:54:03 --> Session routines successfully run
DEBUG - 2016-06-24 08:54:03 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Email Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Controller Class Initialized
DEBUG - 2016-06-24 08:54:03 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:54:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:54:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:54:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:03 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:54:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:03 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:54:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:04 --> DB Transaction Failure
ERROR - 2016-06-24 08:54:04 --> Query error: Unknown column 'property.sale_status' in 'where clause'
DEBUG - 2016-06-24 08:54:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 08:54:07 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:54:07 --> URI Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Router Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Output Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Security Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Input Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:54:07 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Loader Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:54:07 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:54:07 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:54:07 --> Session Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:54:07 --> Session routines successfully run
DEBUG - 2016-06-24 08:54:07 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Email Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Controller Class Initialized
DEBUG - 2016-06-24 08:54:07 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:54:07 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:54:07 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:54:07 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:54:07 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:54:07 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:54:07 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:54:07 --> Final output sent to browser
DEBUG - 2016-06-24 08:54:07 --> Total execution time: 0.1500
DEBUG - 2016-06-24 08:54:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:54:50 --> URI Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Router Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Output Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Security Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Input Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:54:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Loader Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:54:50 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:54:50 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:54:50 --> Session Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:54:50 --> Session routines successfully run
DEBUG - 2016-06-24 08:54:50 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Email Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Controller Class Initialized
DEBUG - 2016-06-24 08:54:50 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:54:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:54:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:54:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:54:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:54:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:54:50 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:54:50 --> Final output sent to browser
DEBUG - 2016-06-24 08:54:50 --> Total execution time: 0.1900
DEBUG - 2016-06-24 08:55:05 --> Config Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:55:05 --> URI Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Router Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Output Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Security Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Input Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:55:05 --> Language Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Language Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Config Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Loader Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:55:05 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:55:05 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:55:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:55:05 --> Session Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:55:05 --> Session routines successfully run
DEBUG - 2016-06-24 08:55:05 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Email Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Controller Class Initialized
DEBUG - 2016-06-24 08:55:05 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:55:05 --> Model Class Initialized
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:55:05 --> Model Class Initialized
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:55:05 --> Model Class Initialized
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:55:05 --> Model Class Initialized
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:55:05 --> Model Class Initialized
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:55:05 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:55:05 --> Final output sent to browser
DEBUG - 2016-06-24 08:55:05 --> Total execution time: 0.2630
DEBUG - 2016-06-24 08:56:00 --> Config Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:56:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:56:00 --> URI Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Router Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Output Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Security Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Input Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:56:00 --> Language Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Language Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Config Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Loader Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:56:00 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:56:00 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:56:00 --> Session Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:56:00 --> Session routines successfully run
DEBUG - 2016-06-24 08:56:00 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Email Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Controller Class Initialized
DEBUG - 2016-06-24 08:56:00 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:56:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:56:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:56:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:56:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:56:00 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:56:00 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:56:00 --> Final output sent to browser
DEBUG - 2016-06-24 08:56:00 --> Total execution time: 0.1048
DEBUG - 2016-06-24 08:56:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:56:52 --> URI Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Router Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Output Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Security Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Input Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:56:52 --> Language Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Language Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Config Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Loader Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:56:52 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:56:52 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:56:52 --> Session Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:56:52 --> Session routines successfully run
DEBUG - 2016-06-24 08:56:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Email Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Controller Class Initialized
DEBUG - 2016-06-24 08:56:52 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:56:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:56:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:56:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:56:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:56:52 --> Model Class Initialized
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:56:52 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:56:52 --> Final output sent to browser
DEBUG - 2016-06-24 08:56:52 --> Total execution time: 0.2270
DEBUG - 2016-06-24 08:57:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:57:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:57:35 --> URI Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Router Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Output Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Security Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Input Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:57:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Language Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Config Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Loader Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:57:35 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:57:35 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:57:35 --> Session Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:57:35 --> Session routines successfully run
DEBUG - 2016-06-24 08:57:35 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Email Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Controller Class Initialized
DEBUG - 2016-06-24 08:57:35 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:57:35 --> Model Class Initialized
DEBUG - 2016-06-24 08:57:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:57:35 --> Model Class Initialized
DEBUG - 2016-06-24 08:57:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:57:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:57:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:57:36 --> Model Class Initialized
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:57:36 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:57:36 --> Final output sent to browser
DEBUG - 2016-06-24 08:57:36 --> Total execution time: 0.3550
DEBUG - 2016-06-24 08:58:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:58:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:58:03 --> URI Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Router Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Output Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Security Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Input Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:58:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Language Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Config Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Loader Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:58:03 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:58:03 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:58:03 --> Session Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:58:03 --> Session routines successfully run
DEBUG - 2016-06-24 08:58:03 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Email Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Controller Class Initialized
DEBUG - 2016-06-24 08:58:03 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:58:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:58:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:58:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:58:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:58:03 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:58:03 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:58:03 --> Final output sent to browser
DEBUG - 2016-06-24 08:58:03 --> Total execution time: 0.1990
DEBUG - 2016-06-24 08:58:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:58:50 --> URI Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Router Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Output Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Security Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Input Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:58:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Language Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Config Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Loader Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:58:50 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:58:50 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:58:50 --> Session Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:58:50 --> Session routines successfully run
DEBUG - 2016-06-24 08:58:50 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Email Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Controller Class Initialized
DEBUG - 2016-06-24 08:58:50 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:58:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:58:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:58:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:58:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:58:50 --> Model Class Initialized
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:58:50 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:58:50 --> Final output sent to browser
DEBUG - 2016-06-24 08:58:50 --> Total execution time: 0.2120
DEBUG - 2016-06-24 08:59:20 --> Config Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Hooks Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Utf8 Class Initialized
DEBUG - 2016-06-24 08:59:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 08:59:20 --> URI Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Router Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Output Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Security Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Input Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 08:59:20 --> Language Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Language Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Config Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Loader Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Helper loaded: url_helper
DEBUG - 2016-06-24 08:59:20 --> Helper loaded: form_helper
DEBUG - 2016-06-24 08:59:20 --> Database Driver Class Initialized
ERROR - 2016-06-24 08:59:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 08:59:20 --> Session Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Helper loaded: string_helper
DEBUG - 2016-06-24 08:59:20 --> Session routines successfully run
DEBUG - 2016-06-24 08:59:20 --> Form Validation Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Pagination Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Encrypt Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Email Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Controller Class Initialized
DEBUG - 2016-06-24 08:59:20 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 08:59:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 08:59:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 08:59:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 08:59:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 08:59:20 --> Model Class Initialized
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 08:59:20 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 08:59:20 --> Final output sent to browser
DEBUG - 2016-06-24 08:59:20 --> Total execution time: 0.2600
DEBUG - 2016-06-24 09:01:26 --> Config Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:01:26 --> URI Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Router Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Output Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Security Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Input Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:01:26 --> Language Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Language Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Config Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Loader Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:01:26 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:01:26 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:01:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:01:26 --> Session Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:01:26 --> Session routines successfully run
DEBUG - 2016-06-24 09:01:26 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Email Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Controller Class Initialized
DEBUG - 2016-06-24 09:01:26 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:01:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:01:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:01:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:01:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:01:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:01:26 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:01:26 --> Final output sent to browser
DEBUG - 2016-06-24 09:01:26 --> Total execution time: 0.2058
DEBUG - 2016-06-24 09:07:03 --> Config Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:07:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:07:03 --> URI Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Router Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Output Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Security Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Input Class Initialized
DEBUG - 2016-06-24 09:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:07:03 --> Language Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Language Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Config Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Loader Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:07:04 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:07:04 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:07:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:07:04 --> Session Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:07:04 --> Session routines successfully run
DEBUG - 2016-06-24 09:07:04 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Email Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Controller Class Initialized
DEBUG - 2016-06-24 09:07:04 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:07:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:07:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:07:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:07:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:07:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:07:04 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:07:04 --> Final output sent to browser
DEBUG - 2016-06-24 09:07:04 --> Total execution time: 0.1550
DEBUG - 2016-06-24 09:07:45 --> Config Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:07:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:07:45 --> URI Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Router Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Output Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Security Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Input Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:07:45 --> Language Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Language Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Config Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Loader Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:07:45 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:07:45 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:07:45 --> Session Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:07:45 --> Session routines successfully run
DEBUG - 2016-06-24 09:07:45 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Email Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Controller Class Initialized
DEBUG - 2016-06-24 09:07:45 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:07:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:07:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:07:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:45 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:07:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:45 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:07:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:07:45 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 09:07:46 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:08:04 --> Config Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:08:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:08:04 --> URI Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Router Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Output Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Security Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Input Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:08:04 --> Language Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Language Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Config Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Loader Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:08:04 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:08:04 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:08:04 --> Session Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:08:04 --> Session routines successfully run
DEBUG - 2016-06-24 09:08:04 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Email Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Controller Class Initialized
DEBUG - 2016-06-24 09:08:04 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:08:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:08:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:08:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:08:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:08:04 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 09:08:04 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:08:41 --> Config Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:08:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:08:41 --> URI Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Router Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Output Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Security Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Input Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:08:41 --> Language Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Language Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Config Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Loader Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:08:41 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:08:41 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:08:41 --> Session Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:08:41 --> Session routines successfully run
DEBUG - 2016-06-24 09:08:41 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Email Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Controller Class Initialized
DEBUG - 2016-06-24 09:08:41 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:08:41 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:08:41 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:08:41 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:08:41 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:08:41 --> Model Class Initialized
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/slider.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/video.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/latest.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/featured.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/home/home.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:08:41 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:08:41 --> Final output sent to browser
DEBUG - 2016-06-24 09:08:41 --> Total execution time: 0.2940
DEBUG - 2016-06-24 09:09:16 --> Config Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:09:16 --> URI Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Router Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Output Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Security Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Input Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:09:16 --> Language Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Language Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Config Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Loader Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:09:16 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:09:16 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:09:16 --> Session Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:09:16 --> Session routines successfully run
DEBUG - 2016-06-24 09:09:16 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Email Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Controller Class Initialized
DEBUG - 2016-06-24 09:09:16 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:09:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:09:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:09:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:09:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:09:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:09:16 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:09:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:09:16 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:09:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:09:16 --> DB Transaction Failure
ERROR - 2016-06-24 09:09:16 --> Query error: Unknown column 'property.property_bathrooms' in 'where clause'
DEBUG - 2016-06-24 09:09:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:11:45 --> Config Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:11:45 --> URI Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Router Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Output Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Security Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Input Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:11:45 --> Language Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Language Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Config Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Loader Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:11:45 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:11:45 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:11:45 --> Session Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:11:45 --> Session routines successfully run
DEBUG - 2016-06-24 09:11:45 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Email Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Controller Class Initialized
DEBUG - 2016-06-24 09:11:45 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:11:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:11:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:11:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:11:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:11:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:11:45 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:11:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:11:45 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:11:45 --> Model Class Initialized
DEBUG - 2016-06-24 09:11:45 --> DB Transaction Failure
ERROR - 2016-06-24 09:11:45 --> Query error: Unknown column 'property.sale_status' in 'order clause'
DEBUG - 2016-06-24 09:11:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:12:26 --> Config Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:12:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:12:26 --> URI Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Router Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Output Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Security Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Input Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:12:26 --> Language Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Language Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Config Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Loader Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:12:26 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:12:26 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:12:26 --> Session Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:12:26 --> Session routines successfully run
DEBUG - 2016-06-24 09:12:26 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Email Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Controller Class Initialized
DEBUG - 2016-06-24 09:12:26 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:12:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:12:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:12:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:26 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:12:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:26 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:12:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:26 --> DB Transaction Failure
ERROR - 2016-06-24 09:12:26 --> Query error: Unknown column 'property_type_status' in 'where clause'
DEBUG - 2016-06-24 09:12:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:12:59 --> Config Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:12:59 --> URI Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Router Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Output Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Security Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Input Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:12:59 --> Language Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Language Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Config Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Loader Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:12:59 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:12:59 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:12:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:12:59 --> Session Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:12:59 --> Session routines successfully run
DEBUG - 2016-06-24 09:12:59 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Email Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Controller Class Initialized
DEBUG - 2016-06-24 09:12:59 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:12:59 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:12:59 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:12:59 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:59 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:12:59 --> Model Class Initialized
DEBUG - 2016-06-24 09:12:59 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:12:59 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Config Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:13:07 --> URI Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Router Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Output Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Security Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Input Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:13:07 --> Language Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Language Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Config Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Loader Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:13:07 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:13:07 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:13:07 --> Session Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:13:07 --> Session routines successfully run
DEBUG - 2016-06-24 09:13:07 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Email Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Controller Class Initialized
DEBUG - 2016-06-24 09:13:07 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:13:07 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:13:07 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:13:07 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:13:07 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:13:07 --> Model Class Initialized
DEBUG - 2016-06-24 09:13:07 --> File loaded: application/modules/site/views/property/property_header.php
DEBUG - 2016-06-24 09:13:07 --> DB Transaction Failure
ERROR - 2016-06-24 09:13:07 --> Query error: Unknown column 'property_type_status' in 'where clause'
DEBUG - 2016-06-24 09:13:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:14:11 --> Config Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:14:11 --> URI Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Router Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Output Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Security Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Input Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:14:11 --> Language Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Language Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Config Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Loader Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:14:11 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:14:11 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:14:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:14:11 --> Session Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:14:11 --> Session routines successfully run
DEBUG - 2016-06-24 09:14:11 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Email Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Controller Class Initialized
DEBUG - 2016-06-24 09:14:11 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:14:11 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:14:11 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:14:11 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:11 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:14:11 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:11 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:14:11 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:11 --> DB Transaction Failure
ERROR - 2016-06-24 09:14:11 --> Query error: Unknown column 'property_type_status' in 'where clause'
DEBUG - 2016-06-24 09:14:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:14:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:14:31 --> URI Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Router Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Output Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Security Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Input Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:14:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Loader Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:14:31 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:14:31 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:14:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:14:31 --> Session Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:14:31 --> Session routines successfully run
DEBUG - 2016-06-24 09:14:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Email Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Controller Class Initialized
DEBUG - 2016-06-24 09:14:31 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:14:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:14:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:14:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:14:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:14:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:14:31 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:14:31 --> Final output sent to browser
DEBUG - 2016-06-24 09:14:31 --> Total execution time: 0.2060
DEBUG - 2016-06-24 09:15:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:15:31 --> URI Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Router Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Output Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Security Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Input Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:15:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Loader Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:15:31 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:15:31 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:15:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:15:31 --> Session Class Initialized
DEBUG - 2016-06-24 09:15:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:15:31 --> Session routines successfully run
DEBUG - 2016-06-24 09:15:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:15:32 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:15:32 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:15:32 --> Email Class Initialized
DEBUG - 2016-06-24 09:15:32 --> Controller Class Initialized
DEBUG - 2016-06-24 09:15:32 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:15:32 --> Model Class Initialized
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:15:32 --> Model Class Initialized
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:15:32 --> Model Class Initialized
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:15:32 --> Model Class Initialized
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:15:32 --> Model Class Initialized
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:15:32 --> Severity: Notice  --> Undefined variable: sale_status C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 56
ERROR - 2016-06-24 09:15:32 --> Severity: Notice  --> Undefined variable: rental_unit_price_type C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 65
ERROR - 2016-06-24 09:15:32 --> Severity: Notice  --> Undefined variable: rental_unit_bedroom C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 87
ERROR - 2016-06-24 09:15:32 --> Severity: Notice  --> Undefined variable: rental_unit_bathrooms C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 93
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:15:32 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:15:32 --> Final output sent to browser
DEBUG - 2016-06-24 09:15:32 --> Total execution time: 0.2800
DEBUG - 2016-06-24 09:16:42 --> Config Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:16:42 --> URI Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Router Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Output Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Security Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Input Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:16:42 --> Language Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Language Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Config Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Loader Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:16:42 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:16:42 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:16:42 --> Session Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:16:42 --> Session routines successfully run
DEBUG - 2016-06-24 09:16:42 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Email Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Controller Class Initialized
DEBUG - 2016-06-24 09:16:42 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:16:42 --> Model Class Initialized
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:16:42 --> Model Class Initialized
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:16:42 --> Model Class Initialized
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:16:42 --> Model Class Initialized
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:16:42 --> Model Class Initialized
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:16:42 --> Severity: Notice  --> Undefined variable: rental_unit_price_type C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 66
ERROR - 2016-06-24 09:16:42 --> Severity: Notice  --> Undefined variable: rental_unit_bedroom C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 88
ERROR - 2016-06-24 09:16:42 --> Severity: Notice  --> Undefined variable: rental_unit_bathrooms C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 94
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:16:42 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:16:42 --> Final output sent to browser
DEBUG - 2016-06-24 09:16:42 --> Total execution time: 0.2380
DEBUG - 2016-06-24 09:17:57 --> Config Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:17:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:17:57 --> URI Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Router Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Output Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Security Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Input Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:17:57 --> Language Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Language Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Config Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Loader Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:17:57 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:17:57 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:17:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:17:57 --> Session Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:17:57 --> Session routines successfully run
DEBUG - 2016-06-24 09:17:57 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Email Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Controller Class Initialized
DEBUG - 2016-06-24 09:17:57 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:17:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:17:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:17:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:17:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:17:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:17:57 --> Severity: Notice  --> Undefined property: stdClass::$rental_unit_type C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property.php 46
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:17:57 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:17:57 --> Final output sent to browser
DEBUG - 2016-06-24 09:17:57 --> Total execution time: 0.1075
DEBUG - 2016-06-24 09:18:16 --> Config Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:18:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:18:16 --> URI Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Router Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Output Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Security Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Input Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:18:16 --> Language Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Language Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Config Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Loader Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:18:16 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:18:16 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:18:16 --> Session Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:18:16 --> Session routines successfully run
DEBUG - 2016-06-24 09:18:16 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Email Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Controller Class Initialized
DEBUG - 2016-06-24 09:18:16 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:18:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:18:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:18:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:18:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:18:16 --> Model Class Initialized
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:18:16 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:18:16 --> Final output sent to browser
DEBUG - 2016-06-24 09:18:16 --> Total execution time: 0.1338
DEBUG - 2016-06-24 09:19:23 --> Config Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:19:23 --> URI Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Router Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Output Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Security Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Input Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:19:23 --> Language Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Language Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Config Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Loader Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:19:23 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:19:23 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:19:23 --> Session Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:19:23 --> Session routines successfully run
DEBUG - 2016-06-24 09:19:23 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Email Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Controller Class Initialized
DEBUG - 2016-06-24 09:19:23 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:19:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:19:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:19:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:19:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:19:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:19:23 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:19:23 --> Final output sent to browser
DEBUG - 2016-06-24 09:19:23 --> Total execution time: 0.1990
DEBUG - 2016-06-24 09:19:52 --> Config Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:19:52 --> URI Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Router Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Output Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Security Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Input Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:19:52 --> Language Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Language Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Config Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Loader Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:19:52 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:19:52 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:19:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:19:52 --> Session Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:19:52 --> Session routines successfully run
DEBUG - 2016-06-24 09:19:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Email Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Controller Class Initialized
DEBUG - 2016-06-24 09:19:52 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:19:52 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:19:52 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:19:52 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:19:52 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:19:52 --> Model Class Initialized
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:19:52 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:19:52 --> Final output sent to browser
DEBUG - 2016-06-24 09:19:52 --> Total execution time: 0.0893
DEBUG - 2016-06-24 09:21:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:21:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:21:14 --> URI Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Router Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Output Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Security Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Input Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:21:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Loader Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:21:14 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:21:14 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:21:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:21:14 --> Session Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:21:14 --> Session routines successfully run
DEBUG - 2016-06-24 09:21:14 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Email Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Controller Class Initialized
DEBUG - 2016-06-24 09:21:14 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:21:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:21:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:21:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:21:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:21:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:21:14 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:21:14 --> Final output sent to browser
DEBUG - 2016-06-24 09:21:14 --> Total execution time: 0.0990
DEBUG - 2016-06-24 09:22:03 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:22:03 --> URI Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Router Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Output Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Security Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Input Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:22:03 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Loader Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:22:03 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:22:03 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:22:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:22:03 --> Session Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:22:03 --> Session routines successfully run
DEBUG - 2016-06-24 09:22:03 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Email Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Controller Class Initialized
DEBUG - 2016-06-24 09:22:03 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/home/filter.php
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/property/property.php
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:22:03 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:22:03 --> Final output sent to browser
DEBUG - 2016-06-24 09:22:03 --> Total execution time: 0.1960
DEBUG - 2016-06-24 09:22:18 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:22:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:22:18 --> URI Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Router Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Output Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Security Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Input Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:22:18 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Loader Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:22:18 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:22:18 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:22:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:22:18 --> Session Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:22:18 --> Session routines successfully run
DEBUG - 2016-06-24 09:22:18 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Email Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Controller Class Initialized
DEBUG - 2016-06-24 09:22:18 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:22:18 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:22:18 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:22:18 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:22:18 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:22:18 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/about/single_header.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/about/team.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/about/about.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:22:18 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:22:18 --> Final output sent to browser
DEBUG - 2016-06-24 09:22:18 --> Total execution time: 0.1020
DEBUG - 2016-06-24 09:22:34 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:22:34 --> URI Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Router Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Output Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Security Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Input Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:22:34 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Language Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Config Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Loader Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:22:34 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:22:34 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:22:34 --> Session Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:22:34 --> Session routines successfully run
DEBUG - 2016-06-24 09:22:34 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Email Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Controller Class Initialized
DEBUG - 2016-06-24 09:22:34 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:22:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:22:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:22:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:34 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:22:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:34 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:22:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:22:34 --> File loaded: application/modules/site/views/contact/contact_header.php
DEBUG - 2016-06-24 09:22:34 --> DB Transaction Failure
ERROR - 2016-06-24 09:22:34 --> Query error: Unknown column 'property_type_status' in 'where clause'
DEBUG - 2016-06-24 09:22:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:23:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:23:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:23:14 --> URI Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Router Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Output Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Security Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Input Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:23:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Loader Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:23:14 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:23:14 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:23:14 --> Session Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:23:14 --> Session routines successfully run
DEBUG - 2016-06-24 09:23:14 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Email Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Controller Class Initialized
DEBUG - 2016-06-24 09:23:14 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:23:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:23:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:23:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:14 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:23:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:14 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:23:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:14 --> File loaded: application/modules/site/views/contact/contact_header.php
DEBUG - 2016-06-24 09:23:28 --> Config Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:23:28 --> URI Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Router Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Output Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Security Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Input Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:23:28 --> Language Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Language Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Config Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Loader Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:23:28 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:23:28 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:23:28 --> Session Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:23:28 --> Session routines successfully run
DEBUG - 2016-06-24 09:23:28 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Email Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Controller Class Initialized
DEBUG - 2016-06-24 09:23:28 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:23:28 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:23:28 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:23:28 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:23:28 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:23:28 --> Model Class Initialized
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/contact/contact_header.php
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:23:28 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:23:28 --> Final output sent to browser
DEBUG - 2016-06-24 09:23:28 --> Total execution time: 0.2533
DEBUG - 2016-06-24 09:24:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:24:31 --> URI Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Router Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Output Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Security Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Input Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:24:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Loader Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:24:31 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:24:31 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:24:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:24:31 --> Session Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:24:31 --> Session routines successfully run
DEBUG - 2016-06-24 09:24:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Email Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Controller Class Initialized
DEBUG - 2016-06-24 09:24:31 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:24:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:24:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:24:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:24:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:24:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:24:31 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:24:31 --> Final output sent to browser
DEBUG - 2016-06-24 09:24:31 --> Total execution time: 0.2160
DEBUG - 2016-06-24 09:25:36 --> Config Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:25:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:25:36 --> URI Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Router Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Output Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Security Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Input Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:25:36 --> Language Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Language Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Config Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Loader Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:25:36 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:25:36 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:25:36 --> Session Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:25:36 --> Session routines successfully run
DEBUG - 2016-06-24 09:25:36 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Email Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Controller Class Initialized
DEBUG - 2016-06-24 09:25:36 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:25:36 --> Model Class Initialized
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:25:36 --> Model Class Initialized
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:25:36 --> Model Class Initialized
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:25:36 --> Model Class Initialized
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:25:36 --> Model Class Initialized
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:25:36 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:25:36 --> Final output sent to browser
DEBUG - 2016-06-24 09:25:36 --> Total execution time: 0.1330
DEBUG - 2016-06-24 09:27:40 --> Config Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:27:40 --> URI Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Router Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Output Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Security Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Input Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:27:40 --> Language Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Language Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Config Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Loader Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:27:40 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:27:40 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:27:40 --> Session Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:27:40 --> Session routines successfully run
DEBUG - 2016-06-24 09:27:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Email Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Controller Class Initialized
DEBUG - 2016-06-24 09:27:40 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:27:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:27:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:27:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:27:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:27:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:27:40 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:27:40 --> Final output sent to browser
DEBUG - 2016-06-24 09:27:40 --> Total execution time: 0.1840
DEBUG - 2016-06-24 09:28:05 --> Config Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:28:05 --> URI Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Router Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Output Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Security Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Input Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:28:05 --> Language Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Language Class Initialized
DEBUG - 2016-06-24 09:28:05 --> Config Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Loader Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:28:06 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:28:06 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:28:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:28:06 --> Session Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:28:06 --> Session routines successfully run
DEBUG - 2016-06-24 09:28:06 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Email Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Controller Class Initialized
DEBUG - 2016-06-24 09:28:06 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:28:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:28:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:28:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:28:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:28:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:28:06 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:28:06 --> Final output sent to browser
DEBUG - 2016-06-24 09:28:06 --> Total execution time: 0.1890
DEBUG - 2016-06-24 09:30:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:30:14 --> URI Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Router Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Output Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Security Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Input Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:30:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Language Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Config Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Loader Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:30:14 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:30:14 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:30:14 --> Session Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:30:14 --> Session routines successfully run
DEBUG - 2016-06-24 09:30:14 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Email Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Controller Class Initialized
DEBUG - 2016-06-24 09:30:14 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:30:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:30:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:30:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:30:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:30:14 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:30:14 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:30:14 --> Final output sent to browser
DEBUG - 2016-06-24 09:30:14 --> Total execution time: 0.2220
DEBUG - 2016-06-24 09:30:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:30:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:30:54 --> URI Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Router Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Output Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Security Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Input Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:30:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Loader Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:30:54 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:30:54 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:30:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:30:54 --> Session Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:30:54 --> Session routines successfully run
DEBUG - 2016-06-24 09:30:54 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Email Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Controller Class Initialized
DEBUG - 2016-06-24 09:30:54 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:30:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:30:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:30:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:30:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:30:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:30:55 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:30:55 --> Final output sent to browser
DEBUG - 2016-06-24 09:30:55 --> Total execution time: 0.1500
DEBUG - 2016-06-24 09:31:25 --> Config Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:31:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:31:25 --> URI Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Router Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Output Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Security Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Input Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:31:25 --> Language Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Language Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Config Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Loader Class Initialized
DEBUG - 2016-06-24 09:31:25 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:31:25 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:31:26 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:31:26 --> Session Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:31:26 --> Session routines successfully run
DEBUG - 2016-06-24 09:31:26 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Email Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Controller Class Initialized
DEBUG - 2016-06-24 09:31:26 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:31:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:31:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:31:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:31:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:31:26 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:31:26 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:31:26 --> Final output sent to browser
DEBUG - 2016-06-24 09:31:26 --> Total execution time: 0.1460
DEBUG - 2016-06-24 09:31:47 --> Config Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:31:47 --> URI Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Router Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Output Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Security Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Input Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:31:47 --> Language Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Language Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Config Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Loader Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:31:47 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:31:47 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:31:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:31:47 --> Session Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:31:47 --> Session routines successfully run
DEBUG - 2016-06-24 09:31:47 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Email Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Controller Class Initialized
DEBUG - 2016-06-24 09:31:47 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:31:47 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:31:47 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:31:47 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:47 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:31:47 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:47 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:31:47 --> Model Class Initialized
DEBUG - 2016-06-24 09:31:47 --> DB Transaction Failure
ERROR - 2016-06-24 09:31:47 --> Query error: Unknown column 'property.sale_status' in 'where clause'
DEBUG - 2016-06-24 09:31:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:36:06 --> Config Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:36:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:36:06 --> URI Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Router Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Output Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Security Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Input Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:36:06 --> Language Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Language Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Config Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Loader Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:36:06 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:36:06 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:36:06 --> Session Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:36:06 --> Session routines successfully run
DEBUG - 2016-06-24 09:36:06 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Email Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Controller Class Initialized
DEBUG - 2016-06-24 09:36:06 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:36:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:36:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:36:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:06 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:36:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:06 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:36:06 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:06 --> DB Transaction Failure
ERROR - 2016-06-24 09:36:06 --> Query error: Unknown column 'property.actual_date' in 'order clause'
DEBUG - 2016-06-24 09:36:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-06-24 09:36:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:36:54 --> URI Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Router Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Output Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Security Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Input Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:36:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Loader Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:36:54 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:36:54 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:36:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:36:54 --> Session Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:36:54 --> Session routines successfully run
DEBUG - 2016-06-24 09:36:54 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Email Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Controller Class Initialized
DEBUG - 2016-06-24 09:36:54 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:36:54 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:36:54 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:36:54 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:36:54 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:36:54 --> Model Class Initialized
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/property/property_header.php
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:36:54 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
ERROR - 2016-06-24 09:36:54 --> Severity: Notice  --> Undefined variable: bedrooms C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 104
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:36:54 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:36:54 --> Final output sent to browser
DEBUG - 2016-06-24 09:36:54 --> Total execution time: 0.2553
DEBUG - 2016-06-24 09:38:00 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:38:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:38:00 --> URI Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Router Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Output Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Security Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Input Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:38:00 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Loader Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:38:00 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:38:00 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:38:00 --> Session Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:38:00 --> Session routines successfully run
DEBUG - 2016-06-24 09:38:00 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Email Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Controller Class Initialized
DEBUG - 2016-06-24 09:38:00 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:38:00 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:38:00 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:38:00 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:38:00 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:38:00 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:38:00 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
ERROR - 2016-06-24 09:38:00 --> Severity: Notice  --> Undefined variable: rental_unit_bedrooms C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 104
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:38:00 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:38:00 --> Final output sent to browser
DEBUG - 2016-06-24 09:38:00 --> Total execution time: 0.2000
DEBUG - 2016-06-24 09:38:22 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:38:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:38:22 --> URI Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Router Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Output Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Security Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Input Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:38:22 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Loader Class Initialized
DEBUG - 2016-06-24 09:38:22 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:38:22 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:38:23 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:38:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:38:23 --> Session Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:38:23 --> Session routines successfully run
DEBUG - 2016-06-24 09:38:23 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Email Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Controller Class Initialized
DEBUG - 2016-06-24 09:38:23 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:38:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:38:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:38:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:38:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:38:23 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:38:23 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:38:23 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:38:23 --> Final output sent to browser
DEBUG - 2016-06-24 09:38:23 --> Total execution time: 0.2135
DEBUG - 2016-06-24 09:38:58 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:38:58 --> URI Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Router Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Output Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Security Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Input Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:38:58 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Language Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Config Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Loader Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:38:58 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:38:58 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:38:58 --> Session Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:38:58 --> Session routines successfully run
DEBUG - 2016-06-24 09:38:58 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Email Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Controller Class Initialized
DEBUG - 2016-06-24 09:38:58 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:38:58 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:38:58 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:38:58 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:38:58 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:38:58 --> Model Class Initialized
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:38:58 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:38:58 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:38:58 --> Final output sent to browser
DEBUG - 2016-06-24 09:38:58 --> Total execution time: 0.2583
DEBUG - 2016-06-24 09:40:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:40:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:40:31 --> URI Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Router Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Output Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Security Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Input Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:40:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Language Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Config Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Loader Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:40:31 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:40:31 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:40:31 --> Session Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:40:31 --> Session routines successfully run
DEBUG - 2016-06-24 09:40:31 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Email Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Controller Class Initialized
DEBUG - 2016-06-24 09:40:31 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:40:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:40:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:40:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:40:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:40:31 --> Model Class Initialized
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:40:31 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:40:31 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:40:31 --> Final output sent to browser
DEBUG - 2016-06-24 09:40:31 --> Total execution time: 0.3410
DEBUG - 2016-06-24 09:41:20 --> Config Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:41:20 --> URI Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Router Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Output Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Security Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Input Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:41:20 --> Language Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Language Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Config Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Loader Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:41:20 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:41:20 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:41:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:41:20 --> Session Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:41:20 --> Session routines successfully run
DEBUG - 2016-06-24 09:41:20 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Email Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Controller Class Initialized
DEBUG - 2016-06-24 09:41:20 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:41:20 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:41:20 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:41:20 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:41:20 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:41:20 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:41:20 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:41:20 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:41:21 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:41:21 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:41:21 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:41:21 --> Final output sent to browser
DEBUG - 2016-06-24 09:41:21 --> Total execution time: 0.1963
DEBUG - 2016-06-24 09:41:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:41:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:41:54 --> URI Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Router Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Output Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Security Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Input Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:41:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Language Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Config Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Loader Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:41:54 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:41:54 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:41:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:41:54 --> Session Class Initialized
DEBUG - 2016-06-24 09:41:54 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:41:54 --> Session routines successfully run
DEBUG - 2016-06-24 09:41:55 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:41:55 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:41:55 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:41:55 --> Email Class Initialized
DEBUG - 2016-06-24 09:41:55 --> Controller Class Initialized
DEBUG - 2016-06-24 09:41:55 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:41:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:41:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:41:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:41:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:41:55 --> Model Class Initialized
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:41:55 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:41:55 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:41:55 --> Final output sent to browser
DEBUG - 2016-06-24 09:41:55 --> Total execution time: 0.2570
DEBUG - 2016-06-24 09:42:24 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:42:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:42:24 --> URI Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Router Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Output Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Security Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Input Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:42:24 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Loader Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:42:24 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:42:24 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:42:24 --> Session Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:42:24 --> Session routines successfully run
DEBUG - 2016-06-24 09:42:24 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Email Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Controller Class Initialized
DEBUG - 2016-06-24 09:42:24 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:42:24 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:42:24 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:42:24 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:42:24 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:42:24 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:42:24 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:42:24 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:42:24 --> Final output sent to browser
DEBUG - 2016-06-24 09:42:24 --> Total execution time: 0.3068
DEBUG - 2016-06-24 09:42:40 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:42:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:42:40 --> URI Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Router Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Output Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Security Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Input Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:42:40 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Loader Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:42:40 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:42:40 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:42:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:42:40 --> Session Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:42:40 --> Session routines successfully run
DEBUG - 2016-06-24 09:42:40 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Email Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Controller Class Initialized
DEBUG - 2016-06-24 09:42:40 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:42:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:42:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:42:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:42:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:42:40 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/home/filter.php
ERROR - 2016-06-24 09:42:40 --> Severity: Notice  --> Undefined variable: rental_unit_image C:\xampp\htdocs\omnis_rents\application\modules\site\views\property\property_onsale.php 80
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/property/property_onsale.php
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:42:40 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:42:40 --> Final output sent to browser
DEBUG - 2016-06-24 09:42:40 --> Total execution time: 0.3000
DEBUG - 2016-06-24 09:42:57 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:42:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:42:57 --> URI Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Router Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Output Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Security Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Input Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:42:57 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Language Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Config Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Loader Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:42:57 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:42:57 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:42:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:42:57 --> Session Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:42:57 --> Session routines successfully run
DEBUG - 2016-06-24 09:42:57 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Email Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Controller Class Initialized
DEBUG - 2016-06-24 09:42:57 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:42:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:42:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:42:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:42:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:42:57 --> Model Class Initialized
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/views/property/single_property.php
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:42:57 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:42:57 --> Final output sent to browser
DEBUG - 2016-06-24 09:42:57 --> Total execution time: 0.1480
DEBUG - 2016-06-24 09:44:33 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:44:33 --> URI Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Router Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Output Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Security Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Input Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:44:33 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:33 --> Loader Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:44:34 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:44:34 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:44:34 --> Session Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:44:34 --> Session routines successfully run
DEBUG - 2016-06-24 09:44:34 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Email Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Controller Class Initialized
DEBUG - 2016-06-24 09:44:34 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:44:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:44:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:44:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:44:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:44:34 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/views/property/single_property.php
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:44:34 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:44:34 --> Final output sent to browser
DEBUG - 2016-06-24 09:44:34 --> Total execution time: 0.2360
DEBUG - 2016-06-24 09:44:49 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:44:49 --> URI Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Router Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Output Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Security Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Input Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:44:49 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Loader Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:44:49 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:44:49 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:44:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:44:49 --> Session Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:44:49 --> Session routines successfully run
DEBUG - 2016-06-24 09:44:49 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Email Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Controller Class Initialized
DEBUG - 2016-06-24 09:44:49 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:44:49 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:44:49 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:44:49 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:44:49 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:44:49 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/views/contact/contact.php
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:44:49 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:44:49 --> Final output sent to browser
DEBUG - 2016-06-24 09:44:49 --> Total execution time: 0.1020
DEBUG - 2016-06-24 09:44:56 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Hooks Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Utf8 Class Initialized
DEBUG - 2016-06-24 09:44:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 09:44:56 --> URI Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Router Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Output Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Security Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Input Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 09:44:56 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Language Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Config Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Loader Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Helper loaded: url_helper
DEBUG - 2016-06-24 09:44:56 --> Helper loaded: form_helper
DEBUG - 2016-06-24 09:44:56 --> Database Driver Class Initialized
ERROR - 2016-06-24 09:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\omnis_rents\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2016-06-24 09:44:56 --> Session Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Helper loaded: string_helper
DEBUG - 2016-06-24 09:44:56 --> Session routines successfully run
DEBUG - 2016-06-24 09:44:56 --> Form Validation Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Pagination Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Encrypt Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Email Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Controller Class Initialized
DEBUG - 2016-06-24 09:44:56 --> Site MX_Controller Initialized
DEBUG - 2016-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/admin/models/blog_model.php
DEBUG - 2016-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/models/property_model.php
DEBUG - 2016-06-24 09:44:56 --> Model Class Initialized
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/views/property/single_property.php
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/views/includes/header.php
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/views/includes/top_navigation.php
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/views/includes/footer.php
DEBUG - 2016-06-24 09:44:56 --> File loaded: application/modules/site/views/templates/general_page.php
DEBUG - 2016-06-24 09:44:56 --> Final output sent to browser
DEBUG - 2016-06-24 09:44:56 --> Total execution time: 0.1480
