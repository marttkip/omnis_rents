<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-19 09:34:45 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:45 --> URI Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Router Class Initialized
DEBUG - 2016-02-19 09:34:45 --> No URI present. Default controller set.
DEBUG - 2016-02-19 09:34:45 --> Output Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Security Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Input Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-19 09:34:45 --> Language Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Language Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:45 --> Loader Class Initialized
DEBUG - 2016-02-19 09:34:46 --> Helper loaded: url_helper
DEBUG - 2016-02-19 09:34:46 --> Helper loaded: form_helper
DEBUG - 2016-02-19 09:34:46 --> Database Driver Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Session Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Helper loaded: string_helper
DEBUG - 2016-02-19 09:34:47 --> A session cookie was not found.
DEBUG - 2016-02-19 09:34:47 --> Session routines successfully run
DEBUG - 2016-02-19 09:34:47 --> Form Validation Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Pagination Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Encrypt Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Email Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Controller Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Auth MX_Controller Initialized
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:47 --> URI Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Router Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Output Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Security Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Input Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-19 09:34:47 --> Language Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Language Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Loader Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Helper loaded: url_helper
DEBUG - 2016-02-19 09:34:47 --> Helper loaded: form_helper
DEBUG - 2016-02-19 09:34:47 --> Database Driver Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Session Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Helper loaded: string_helper
DEBUG - 2016-02-19 09:34:47 --> Session routines successfully run
DEBUG - 2016-02-19 09:34:47 --> Form Validation Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Pagination Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Encrypt Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Email Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Controller Class Initialized
DEBUG - 2016-02-19 09:34:47 --> Auth MX_Controller Initialized
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-19 09:34:47 --> Model Class Initialized
DEBUG - 2016-02-19 09:34:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-19 09:34:48 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-19 09:34:48 --> Final output sent to browser
DEBUG - 2016-02-19 09:34:48 --> Total execution time: 0.8414
DEBUG - 2016-02-19 09:34:50 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:50 --> URI Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Router Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:50 --> URI Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Router Class Initialized
ERROR - 2016-02-19 09:34:50 --> 404 Page Not Found --> 
DEBUG - 2016-02-19 09:34:50 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:50 --> URI Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Router Class Initialized
ERROR - 2016-02-19 09:34:50 --> 404 Page Not Found --> 
DEBUG - 2016-02-19 09:34:50 --> Config Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 09:34:50 --> Utf8 Class Initialized
DEBUG - 2016-02-19 09:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-19 09:34:50 --> URI Class Initialized
ERROR - 2016-02-19 09:34:50 --> 404 Page Not Found --> 
DEBUG - 2016-02-19 09:34:50 --> Router Class Initialized
ERROR - 2016-02-19 09:34:50 --> 404 Page Not Found --> 
