<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-22 07:45:35 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:36 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:36 --> Router Class Initialized
DEBUG - 2016-01-22 07:45:37 --> No URI present. Default controller set.
DEBUG - 2016-01-22 07:45:37 --> Output Class Initialized
DEBUG - 2016-01-22 07:45:37 --> Security Class Initialized
DEBUG - 2016-01-22 07:45:37 --> Input Class Initialized
DEBUG - 2016-01-22 07:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:45:37 --> Language Class Initialized
DEBUG - 2016-01-22 07:45:37 --> Language Class Initialized
DEBUG - 2016-01-22 07:45:37 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:38 --> Loader Class Initialized
DEBUG - 2016-01-22 07:45:38 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:45:38 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:45:39 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:45:40 --> Session Class Initialized
DEBUG - 2016-01-22 07:45:40 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:45:40 --> A session cookie was not found.
DEBUG - 2016-01-22 07:45:41 --> Session routines successfully run
DEBUG - 2016-01-22 07:45:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:45:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:45:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:45:41 --> Email Class Initialized
DEBUG - 2016-01-22 07:45:41 --> Controller Class Initialized
DEBUG - 2016-01-22 07:45:41 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:42 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Router Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Output Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Security Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Input Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:45:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Loader Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:45:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:45:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Session Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:45:42 --> Session routines successfully run
DEBUG - 2016-01-22 07:45:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Email Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Controller Class Initialized
DEBUG - 2016-01-22 07:45:42 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:45:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:45:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:45:44 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-22 07:45:44 --> Final output sent to browser
DEBUG - 2016-01-22 07:45:44 --> Total execution time: 1.7472
DEBUG - 2016-01-22 07:45:48 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:48 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:48 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Router Class Initialized
DEBUG - 2016-01-22 07:45:48 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:48 --> Router Class Initialized
DEBUG - 2016-01-22 07:45:49 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:49 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:49 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:49 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:49 --> Router Class Initialized
ERROR - 2016-01-22 07:45:49 --> 404 Page Not Found --> 
ERROR - 2016-01-22 07:45:49 --> 404 Page Not Found --> 
ERROR - 2016-01-22 07:45:49 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:45:50 --> Config Class Initialized
DEBUG - 2016-01-22 07:45:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:45:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:45:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:45:50 --> URI Class Initialized
DEBUG - 2016-01-22 07:45:50 --> Router Class Initialized
ERROR - 2016-01-22 07:45:50 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:46:00 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:46:00 --> URI Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Router Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Output Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Security Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Input Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:46:00 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Loader Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:46:00 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:46:00 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Session Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:46:00 --> Session routines successfully run
DEBUG - 2016-01-22 07:46:00 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Email Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Controller Class Initialized
DEBUG - 2016-01-22 07:46:00 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 07:46:00 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:46:00 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:46:00 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 07:46:01 --> XSS Filtering completed
DEBUG - 2016-01-22 07:46:01 --> Unable to find validation rule: exists
DEBUG - 2016-01-22 07:46:01 --> XSS Filtering completed
DEBUG - 2016-01-22 07:46:01 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:46:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:46:01 --> URI Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Router Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Output Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Security Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Input Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:46:01 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Loader Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:46:01 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:46:01 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Session Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:46:01 --> Session routines successfully run
DEBUG - 2016-01-22 07:46:01 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Email Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Controller Class Initialized
DEBUG - 2016-01-22 07:46:01 --> Admin MX_Controller Initialized
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:46:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:46:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:46:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:46:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:46:02 --> Final output sent to browser
DEBUG - 2016-01-22 07:46:02 --> Total execution time: 0.9527
DEBUG - 2016-01-22 07:46:14 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:46:14 --> URI Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Router Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Output Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Security Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Input Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:46:14 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Loader Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:46:14 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:46:14 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Session Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:46:14 --> Session routines successfully run
DEBUG - 2016-01-22 07:46:14 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Email Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Controller Class Initialized
DEBUG - 2016-01-22 07:46:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:46:14 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 07:46:15 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:46:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:46:16 --> Final output sent to browser
DEBUG - 2016-01-22 07:46:16 --> Total execution time: 1.6521
DEBUG - 2016-01-22 07:46:23 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:46:23 --> URI Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Router Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Output Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Security Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Input Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:46:23 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Language Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Config Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Loader Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:46:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:46:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Session Class Initialized
DEBUG - 2016-01-22 07:46:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:46:24 --> Session routines successfully run
DEBUG - 2016-01-22 07:46:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Email Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Controller Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 07:46:24 --> Model Class Initialized
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:46:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:46:24 --> Final output sent to browser
DEBUG - 2016-01-22 07:46:24 --> Total execution time: 0.5701
DEBUG - 2016-01-22 07:47:02 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:47:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:47:02 --> URI Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Router Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Output Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Security Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Input Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:47:02 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Loader Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:47:02 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:47:02 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Session Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:47:02 --> Session routines successfully run
DEBUG - 2016-01-22 07:47:02 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Email Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Controller Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Property MX_Controller Initialized
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:47:02 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:02 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:47:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:47:02 --> Final output sent to browser
DEBUG - 2016-01-22 07:47:02 --> Total execution time: 0.4278
DEBUG - 2016-01-22 07:47:08 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:47:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:47:08 --> URI Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Router Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Output Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Security Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Input Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:47:08 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Loader Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:47:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:47:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Session Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:47:08 --> Session routines successfully run
DEBUG - 2016-01-22 07:47:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Email Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Controller Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:47:08 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:08 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:47:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:47:08 --> Final output sent to browser
DEBUG - 2016-01-22 07:47:08 --> Total execution time: 0.3446
DEBUG - 2016-01-22 07:47:13 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:47:13 --> URI Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Router Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Output Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Security Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Input Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:47:13 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Language Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Config Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Loader Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:47:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:47:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Session Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:47:13 --> Session routines successfully run
DEBUG - 2016-01-22 07:47:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Email Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Controller Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 07:47:13 --> Model Class Initialized
DEBUG - 2016-01-22 07:47:13 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:47:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:47:14 --> Final output sent to browser
DEBUG - 2016-01-22 07:47:14 --> Total execution time: 0.5085
DEBUG - 2016-01-22 07:54:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:42 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: string_helper
ERROR - 2016-01-22 07:54:42 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-01-22 07:54:42 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:42 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:54:42 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:42 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:54:42 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-22 07:54:42 --> Final output sent to browser
DEBUG - 2016-01-22 07:54:42 --> Total execution time: 0.1674
DEBUG - 2016-01-22 07:54:43 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:43 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:43 --> URI Class Initialized
ERROR - 2016-01-22 07:54:43 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:54:43 --> Router Class Initialized
ERROR - 2016-01-22 07:54:43 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:54:43 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:43 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:43 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:43 --> Router Class Initialized
ERROR - 2016-01-22 07:54:43 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:54:43 --> Router Class Initialized
ERROR - 2016-01-22 07:54:43 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 07:54:45 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:45 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:45 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:54:45 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 07:54:45 --> XSS Filtering completed
DEBUG - 2016-01-22 07:54:45 --> Unable to find validation rule: exists
DEBUG - 2016-01-22 07:54:45 --> XSS Filtering completed
DEBUG - 2016-01-22 07:54:45 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:45 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:45 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:54:45 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:45 --> Admin MX_Controller Initialized
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:54:45 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:54:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:54:45 --> Final output sent to browser
DEBUG - 2016-01-22 07:54:45 --> Total execution time: 0.2829
DEBUG - 2016-01-22 07:54:50 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:50 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:50 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:50 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:50 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:54:50 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:50 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:50 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:54:50 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:51 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-22 07:54:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:54:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:54:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:54:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:54:51 --> Final output sent to browser
DEBUG - 2016-01-22 07:54:51 --> Total execution time: 0.4138
DEBUG - 2016-01-22 07:54:52 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:54:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:54:52 --> URI Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Router Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Output Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Security Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Input Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:54:52 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Language Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Config Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Loader Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:54:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:54:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Session Class Initialized
DEBUG - 2016-01-22 07:54:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:54:52 --> Session routines successfully run
DEBUG - 2016-01-22 07:54:53 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:54:53 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:54:53 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:54:53 --> Email Class Initialized
DEBUG - 2016-01-22 07:54:53 --> Controller Class Initialized
DEBUG - 2016-01-22 07:54:53 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:54:53 --> Model Class Initialized
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:54:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:54:53 --> Final output sent to browser
DEBUG - 2016-01-22 07:54:53 --> Total execution time: 0.2634
DEBUG - 2016-01-22 07:55:15 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:15 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:15 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:16 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:16 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:16 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 07:55:16 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:16 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:16 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:16 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:16 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:16 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:16 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:16 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:16 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:16 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:16 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:55:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:55:16 --> Final output sent to browser
DEBUG - 2016-01-22 07:55:16 --> Total execution time: 0.2657
DEBUG - 2016-01-22 07:55:22 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:22 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:22 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:22 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:22 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:22 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:23 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-22 07:55:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:55:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:55:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:55:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:55:23 --> Final output sent to browser
DEBUG - 2016-01-22 07:55:23 --> Total execution time: 0.3778
DEBUG - 2016-01-22 07:55:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:42 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:42 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 07:55:42 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:42 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:42 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:42 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:42 --> XSS Filtering completed
DEBUG - 2016-01-22 07:55:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:42 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:42 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:42 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:42 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:55:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:55:42 --> Final output sent to browser
DEBUG - 2016-01-22 07:55:42 --> Total execution time: 0.2273
DEBUG - 2016-01-22 07:55:48 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:55:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:55:48 --> URI Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Router Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Output Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Security Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Input Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:55:48 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Language Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Config Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Loader Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:55:48 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:55:48 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Session Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:55:48 --> Session routines successfully run
DEBUG - 2016-01-22 07:55:48 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Email Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Controller Class Initialized
DEBUG - 2016-01-22 07:55:48 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/views/sections/add_section.php
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:55:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:55:48 --> Final output sent to browser
DEBUG - 2016-01-22 07:55:48 --> Total execution time: 0.3100
DEBUG - 2016-01-22 07:56:19 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:56:19 --> URI Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Router Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Output Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Security Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Input Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:56:19 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Loader Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:56:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Session Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:56:19 --> Session routines successfully run
DEBUG - 2016-01-22 07:56:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Email Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Controller Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 07:56:19 --> XSS Filtering completed
DEBUG - 2016-01-22 07:56:19 --> XSS Filtering completed
DEBUG - 2016-01-22 07:56:19 --> XSS Filtering completed
DEBUG - 2016-01-22 07:56:19 --> XSS Filtering completed
DEBUG - 2016-01-22 07:56:19 --> XSS Filtering completed
DEBUG - 2016-01-22 07:56:19 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:56:19 --> URI Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Router Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Output Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Security Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Input Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:56:19 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Loader Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:56:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Session Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:56:19 --> Session routines successfully run
DEBUG - 2016-01-22 07:56:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Email Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Controller Class Initialized
DEBUG - 2016-01-22 07:56:19 --> Sections MX_Controller Initialized
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:56:19 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:56:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:56:19 --> Final output sent to browser
DEBUG - 2016-01-22 07:56:19 --> Total execution time: 0.2447
DEBUG - 2016-01-22 07:56:52 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:56:52 --> URI Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Router Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Output Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Security Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Input Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:56:52 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Language Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Config Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Loader Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:56:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:56:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Session Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:56:52 --> Session routines successfully run
DEBUG - 2016-01-22 07:56:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Email Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Controller Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:56:52 --> Model Class Initialized
DEBUG - 2016-01-22 07:56:52 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:56:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:56:52 --> Final output sent to browser
DEBUG - 2016-01-22 07:56:52 --> Total execution time: 0.4053
DEBUG - 2016-01-22 07:57:01 --> Config Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:57:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:57:01 --> URI Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Router Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Output Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Security Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Input Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 07:57:01 --> Language Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Language Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Config Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Loader Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Helper loaded: url_helper
DEBUG - 2016-01-22 07:57:01 --> Helper loaded: form_helper
DEBUG - 2016-01-22 07:57:01 --> Database Driver Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Session Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Helper loaded: string_helper
DEBUG - 2016-01-22 07:57:01 --> Session routines successfully run
DEBUG - 2016-01-22 07:57:01 --> Form Validation Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Pagination Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Encrypt Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Email Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Controller Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> Image Lib Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 07:57:01 --> Model Class Initialized
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 07:57:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 07:57:01 --> Final output sent to browser
DEBUG - 2016-01-22 07:57:01 --> Total execution time: 0.3767
DEBUG - 2016-01-22 07:58:15 --> Config Class Initialized
DEBUG - 2016-01-22 07:58:15 --> Hooks Class Initialized
DEBUG - 2016-01-22 07:58:15 --> Utf8 Class Initialized
DEBUG - 2016-01-22 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 07:58:15 --> URI Class Initialized
DEBUG - 2016-01-22 07:58:15 --> Router Class Initialized
ERROR - 2016-01-22 07:58:15 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 08:07:41 --> Config Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:07:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:07:41 --> URI Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Router Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Output Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Security Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Input Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:07:41 --> Language Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Language Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Config Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Loader Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:07:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:07:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Session Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:07:41 --> Session routines successfully run
DEBUG - 2016-01-22 08:07:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Email Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Controller Class Initialized
DEBUG - 2016-01-22 08:07:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:09:08 --> Config Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:09:08 --> URI Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Router Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Output Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Security Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Input Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:09:08 --> Language Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Language Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Config Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Loader Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:09:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:09:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Session Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:09:08 --> Session routines successfully run
DEBUG - 2016-01-22 08:09:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Email Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Controller Class Initialized
DEBUG - 2016-01-22 08:09:08 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:09:41 --> Config Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:09:41 --> URI Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Router Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Output Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Security Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Input Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:09:41 --> Language Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Language Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Config Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Loader Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:09:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:09:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Session Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:09:41 --> Session routines successfully run
DEBUG - 2016-01-22 08:09:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Email Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Controller Class Initialized
DEBUG - 2016-01-22 08:09:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:10:09 --> Config Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:10:09 --> URI Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Router Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Output Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Security Class Initialized
DEBUG - 2016-01-22 08:10:09 --> Input Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:10:10 --> Language Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Language Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Config Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Loader Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:10:10 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:10:10 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Session Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:10:10 --> Session routines successfully run
DEBUG - 2016-01-22 08:10:10 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Email Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Controller Class Initialized
DEBUG - 2016-01-22 08:10:10 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:10:11 --> Config Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:10:11 --> URI Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Router Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Output Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Security Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Input Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:10:11 --> Language Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Language Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Config Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Loader Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:10:11 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:10:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Session Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:10:11 --> Session routines successfully run
DEBUG - 2016-01-22 08:10:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:10:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:10:12 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:10:12 --> Email Class Initialized
DEBUG - 2016-01-22 08:10:12 --> Controller Class Initialized
DEBUG - 2016-01-22 08:10:12 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:11:23 --> Config Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 08:11:23 --> URI Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Router Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Output Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Security Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Input Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 08:11:23 --> Language Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Language Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Config Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Loader Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 08:11:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 08:11:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Session Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 08:11:23 --> Session routines successfully run
DEBUG - 2016-01-22 08:11:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Email Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Controller Class Initialized
DEBUG - 2016-01-22 08:11:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 08:11:24 --> Model Class Initialized
DEBUG - 2016-01-22 08:11:24 --> Image Lib Class Initialized
ERROR - 2016-01-22 08:11:24 --> Severity: Notice  --> Undefined property: CI::$reception_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-22 09:31:30 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:30 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Output Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Security Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Input Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:31:31 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:31 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:32 --> Loader Class Initialized
DEBUG - 2016-01-22 09:31:32 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:31:32 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:31:32 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Session Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Helper loaded: string_helper
ERROR - 2016-01-22 09:31:33 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-01-22 09:31:33 --> Session routines successfully run
DEBUG - 2016-01-22 09:31:33 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Email Class Initialized
DEBUG - 2016-01-22 09:31:33 --> Controller Class Initialized
DEBUG - 2016-01-22 09:31:34 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:31:34 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:34 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:34 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:34 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:34 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Output Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Security Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Input Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:31:35 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Loader Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:31:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:31:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Session Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:31:35 --> Session routines successfully run
DEBUG - 2016-01-22 09:31:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Email Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Controller Class Initialized
DEBUG - 2016-01-22 09:31:35 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 09:31:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:31:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:31:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:31:36 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-22 09:31:36 --> Final output sent to browser
DEBUG - 2016-01-22 09:31:36 --> Total execution time: 1.0732
DEBUG - 2016-01-22 09:31:40 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:40 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:40 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:40 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:41 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:41 --> UTF-8 Support Enabled
ERROR - 2016-01-22 09:31:41 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 09:31:41 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:41 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:42 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:42 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:42 --> Router Class Initialized
ERROR - 2016-01-22 09:31:42 --> 404 Page Not Found --> 
ERROR - 2016-01-22 09:31:42 --> 404 Page Not Found --> 
ERROR - 2016-01-22 09:31:42 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 09:31:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:44 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Output Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Security Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Input Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:31:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Loader Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:31:44 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Session Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:31:44 --> Session routines successfully run
DEBUG - 2016-01-22 09:31:44 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Email Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Controller Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 09:31:44 --> XSS Filtering completed
DEBUG - 2016-01-22 09:31:44 --> Unable to find validation rule: exists
DEBUG - 2016-01-22 09:31:44 --> XSS Filtering completed
DEBUG - 2016-01-22 09:31:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:44 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Output Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Security Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Input Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:31:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Loader Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:31:44 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Session Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:31:44 --> Session routines successfully run
DEBUG - 2016-01-22 09:31:44 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Email Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Controller Class Initialized
DEBUG - 2016-01-22 09:31:44 --> Admin MX_Controller Initialized
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:31:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:45 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-22 09:31:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:31:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:31:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:31:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:31:45 --> Final output sent to browser
DEBUG - 2016-01-22 09:31:45 --> Total execution time: 0.5777
DEBUG - 2016-01-22 09:31:50 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:31:50 --> URI Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Router Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Output Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Security Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Input Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:31:50 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Language Class Initialized
DEBUG - 2016-01-22 09:31:50 --> Config Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Loader Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:31:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:31:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Session Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:31:51 --> Session routines successfully run
DEBUG - 2016-01-22 09:31:51 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Email Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Controller Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:31:51 --> Model Class Initialized
DEBUG - 2016-01-22 09:31:51 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Config Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:32:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:32:35 --> URI Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Router Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Output Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Security Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Input Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:32:35 --> Language Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Language Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Config Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Loader Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:32:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:32:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Session Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:32:35 --> Session routines successfully run
DEBUG - 2016-01-22 09:32:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Email Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Controller Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:32:35 --> Model Class Initialized
DEBUG - 2016-01-22 09:32:35 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Config Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:33:20 --> URI Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Router Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Output Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Security Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Input Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:33:20 --> Language Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Language Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Config Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Loader Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:33:20 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:33:20 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Session Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:33:20 --> Session routines successfully run
DEBUG - 2016-01-22 09:33:20 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Email Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Controller Class Initialized
DEBUG - 2016-01-22 09:33:20 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:33:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:21 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Config Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:33:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:33:22 --> URI Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Router Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Output Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Security Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Input Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:33:22 --> Language Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Language Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Config Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Loader Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:33:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:33:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Session Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:33:22 --> Session routines successfully run
DEBUG - 2016-01-22 09:33:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Email Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Controller Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:33:22 --> Model Class Initialized
DEBUG - 2016-01-22 09:33:22 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Config Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:40:21 --> URI Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Router Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Output Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Security Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Input Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:40:21 --> Language Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Language Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Config Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Loader Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:40:21 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:40:21 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Session Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:40:21 --> Session routines successfully run
DEBUG - 2016-01-22 09:40:21 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Email Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Controller Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:40:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:40:21 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Config Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:42:25 --> URI Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Router Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Output Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Security Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Input Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:42:25 --> Language Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Language Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Config Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Loader Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:42:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:42:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Session Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:42:25 --> Session routines successfully run
DEBUG - 2016-01-22 09:42:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Email Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Controller Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:42:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:42:25 --> Image Lib Class Initialized
ERROR - 2016-01-22 09:42:25 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 3
ERROR - 2016-01-22 09:42:25 --> Severity: Notice  --> Undefined variable: module C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 10
ERROR - 2016-01-22 09:42:25 --> Severity: Notice  --> Undefined variable: branches C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 71
DEBUG - 2016-01-22 09:43:03 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:43:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:43:03 --> URI Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Router Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Output Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Security Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Input Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:43:03 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Loader Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:43:03 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:43:03 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Session Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:43:03 --> Session routines successfully run
DEBUG - 2016-01-22 09:43:03 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Email Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Controller Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:43:03 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:03 --> Image Lib Class Initialized
ERROR - 2016-01-22 09:43:03 --> Severity: Notice  --> Undefined variable: module C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 10
ERROR - 2016-01-22 09:43:03 --> Severity: Notice  --> Undefined variable: branches C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 71
DEBUG - 2016-01-22 09:43:20 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:43:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:43:20 --> URI Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Router Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Output Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Security Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Input Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:43:20 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Loader Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:43:20 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:43:20 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Session Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:43:20 --> Session routines successfully run
DEBUG - 2016-01-22 09:43:20 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Email Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Controller Class Initialized
DEBUG - 2016-01-22 09:43:20 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:43:20 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:43:21 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:21 --> Image Lib Class Initialized
ERROR - 2016-01-22 09:43:21 --> Severity: Notice  --> Undefined variable: branches C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 71
DEBUG - 2016-01-22 09:43:31 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:43:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:43:31 --> URI Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Router Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Output Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Security Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Input Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:43:31 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Language Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Config Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Loader Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:43:31 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:43:31 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Session Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:43:31 --> Session routines successfully run
DEBUG - 2016-01-22 09:43:31 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Email Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Controller Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:43:31 --> Model Class Initialized
DEBUG - 2016-01-22 09:43:31 --> Image Lib Class Initialized
ERROR - 2016-01-22 09:43:31 --> Severity: Notice  --> Undefined variable: branches C:\xampp\htdocs\rents\application\modules\administration\views\reports\search\transactions.php 71
DEBUG - 2016-01-22 09:44:23 --> Config Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:44:23 --> URI Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Router Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Output Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Security Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Input Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:44:23 --> Language Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Language Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Config Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Loader Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:44:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:44:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Session Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:44:23 --> Session routines successfully run
DEBUG - 2016-01-22 09:44:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Email Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Controller Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:44:23 --> Model Class Initialized
DEBUG - 2016-01-22 09:44:23 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 09:44:23 --> Severity: Notice  --> Undefined variable: total_patients C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 43
ERROR - 2016-01-22 09:44:23 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 62
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:44:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:44:23 --> Final output sent to browser
DEBUG - 2016-01-22 09:44:23 --> Total execution time: 0.2733
DEBUG - 2016-01-22 09:45:36 --> Config Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:45:36 --> URI Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Router Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Output Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Security Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Input Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:45:36 --> Language Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Language Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Config Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Loader Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:45:36 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:45:36 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Session Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:45:36 --> Session routines successfully run
DEBUG - 2016-01-22 09:45:36 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Email Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Controller Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:45:36 --> Model Class Initialized
DEBUG - 2016-01-22 09:45:36 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 09:45:36 --> Severity: Notice  --> Undefined variable: total_patients C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 43
ERROR - 2016-01-22 09:45:36 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 62
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:45:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:45:36 --> Final output sent to browser
DEBUG - 2016-01-22 09:45:36 --> Total execution time: 0.2630
DEBUG - 2016-01-22 09:46:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:46:44 --> URI Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Router Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Output Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Security Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Input Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:46:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Language Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Config Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Loader Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:46:44 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:46:44 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Session Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:46:44 --> Session routines successfully run
DEBUG - 2016-01-22 09:46:44 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Email Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Controller Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:46:44 --> Model Class Initialized
DEBUG - 2016-01-22 09:46:44 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:46:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:46:44 --> Final output sent to browser
DEBUG - 2016-01-22 09:46:44 --> Total execution time: 0.3563
DEBUG - 2016-01-22 09:47:54 --> Config Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:47:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:47:54 --> URI Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Router Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Output Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Security Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Input Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:47:54 --> Language Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Language Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Config Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Loader Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:47:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:47:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Session Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:47:54 --> Session routines successfully run
DEBUG - 2016-01-22 09:47:54 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Email Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Controller Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:47:54 --> Model Class Initialized
DEBUG - 2016-01-22 09:47:54 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:47:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:47:54 --> Final output sent to browser
DEBUG - 2016-01-22 09:47:54 --> Total execution time: 0.2460
DEBUG - 2016-01-22 09:48:25 --> Config Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:48:25 --> URI Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Router Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Output Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Security Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Input Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:48:25 --> Language Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Language Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Config Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Loader Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:48:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:48:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Session Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:48:25 --> Session routines successfully run
DEBUG - 2016-01-22 09:48:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Email Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Controller Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:48:25 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:25 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:48:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:48:25 --> Final output sent to browser
DEBUG - 2016-01-22 09:48:25 --> Total execution time: 0.2421
DEBUG - 2016-01-22 09:48:59 --> Config Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Hooks Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Utf8 Class Initialized
DEBUG - 2016-01-22 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 09:48:59 --> URI Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Router Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Output Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Security Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Input Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 09:48:59 --> Language Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Language Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Config Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Loader Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Helper loaded: url_helper
DEBUG - 2016-01-22 09:48:59 --> Helper loaded: form_helper
DEBUG - 2016-01-22 09:48:59 --> Database Driver Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Session Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Helper loaded: string_helper
DEBUG - 2016-01-22 09:48:59 --> Session routines successfully run
DEBUG - 2016-01-22 09:48:59 --> Form Validation Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Pagination Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Encrypt Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Email Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Controller Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 09:48:59 --> Model Class Initialized
DEBUG - 2016-01-22 09:48:59 --> Image Lib Class Initialized
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 09:48:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 09:48:59 --> Final output sent to browser
DEBUG - 2016-01-22 09:48:59 --> Total execution time: 0.2456
DEBUG - 2016-01-22 10:00:57 --> Config Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:00:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:00:57 --> URI Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Router Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Output Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Security Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Input Class Initialized
DEBUG - 2016-01-22 10:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:00:57 --> Language Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Language Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Config Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Loader Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:00:58 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:00:58 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Session Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:00:58 --> Session routines successfully run
DEBUG - 2016-01-22 10:00:58 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Email Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Controller Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:00:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:00:58 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:00:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:00:58 --> Final output sent to browser
DEBUG - 2016-01-22 10:00:58 --> Total execution time: 0.2768
DEBUG - 2016-01-22 10:01:21 --> Config Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:01:21 --> URI Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Router Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Output Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Security Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Input Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:01:21 --> Language Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Language Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Config Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Loader Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:01:21 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:01:21 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Session Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:01:21 --> Session routines successfully run
DEBUG - 2016-01-22 10:01:21 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Email Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Controller Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:01:21 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:21 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:01:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:01:21 --> Final output sent to browser
DEBUG - 2016-01-22 10:01:21 --> Total execution time: 0.2891
DEBUG - 2016-01-22 10:01:49 --> Config Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:01:49 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:01:49 --> URI Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Router Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Output Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Security Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Input Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:01:49 --> Language Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Language Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Config Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Loader Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:01:49 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:01:49 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Session Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:01:49 --> Session routines successfully run
DEBUG - 2016-01-22 10:01:49 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Email Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Controller Class Initialized
DEBUG - 2016-01-22 10:01:49 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:01:49 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:49 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:01:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:01:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:01:50 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:01:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:01:50 --> Final output sent to browser
DEBUG - 2016-01-22 10:01:50 --> Total execution time: 0.3819
DEBUG - 2016-01-22 10:33:56 --> Config Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:33:56 --> URI Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Router Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Output Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Security Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Input Class Initialized
DEBUG - 2016-01-22 10:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:33:56 --> Language Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Language Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Config Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Loader Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:33:57 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:33:57 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Session Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:33:57 --> Session routines successfully run
DEBUG - 2016-01-22 10:33:57 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Email Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Controller Class Initialized
DEBUG - 2016-01-22 10:33:57 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:33:57 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:33:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:33:58 --> Model Class Initialized
DEBUG - 2016-01-22 10:33:58 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:33:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:33:58 --> Final output sent to browser
DEBUG - 2016-01-22 10:33:58 --> Total execution time: 2.8795
DEBUG - 2016-01-22 10:35:50 --> Config Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:35:50 --> URI Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Router Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Output Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Security Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Input Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:35:50 --> Language Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Language Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Config Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Loader Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:35:50 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:35:50 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Session Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:35:50 --> Session routines successfully run
DEBUG - 2016-01-22 10:35:50 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Email Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Controller Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:35:50 --> Model Class Initialized
DEBUG - 2016-01-22 10:35:50 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:35:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:35:50 --> Final output sent to browser
DEBUG - 2016-01-22 10:35:50 --> Total execution time: 0.5090
DEBUG - 2016-01-22 10:36:13 --> Config Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:36:13 --> URI Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Router Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Output Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Security Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Input Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:36:13 --> Language Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Language Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Config Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Loader Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:36:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:36:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Session Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:36:13 --> Session routines successfully run
DEBUG - 2016-01-22 10:36:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Email Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Controller Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:36:13 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:13 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:36:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:36:13 --> Final output sent to browser
DEBUG - 2016-01-22 10:36:13 --> Total execution time: 0.2934
DEBUG - 2016-01-22 10:36:55 --> Config Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:36:55 --> URI Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Router Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Output Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Security Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Input Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:36:55 --> Language Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Language Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Config Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Loader Class Initialized
DEBUG - 2016-01-22 10:36:55 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:36:55 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:36:55 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Session Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:36:56 --> Session routines successfully run
DEBUG - 2016-01-22 10:36:56 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Email Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Controller Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:36:56 --> Model Class Initialized
DEBUG - 2016-01-22 10:36:56 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:36:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:36:56 --> Final output sent to browser
DEBUG - 2016-01-22 10:36:56 --> Total execution time: 0.4078
DEBUG - 2016-01-22 10:37:30 --> Config Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:37:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:37:30 --> URI Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Router Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Output Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Security Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Input Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:37:30 --> Language Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Language Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Config Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Loader Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:37:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:37:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Session Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:37:30 --> Session routines successfully run
DEBUG - 2016-01-22 10:37:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:37:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:37:31 --> Email Class Initialized
DEBUG - 2016-01-22 10:37:31 --> Controller Class Initialized
DEBUG - 2016-01-22 10:37:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:37:31 --> Model Class Initialized
DEBUG - 2016-01-22 10:37:31 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Config Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:38:30 --> URI Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Router Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Output Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Security Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Input Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:38:30 --> Language Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Language Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Config Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Loader Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:38:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:38:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Session Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:38:30 --> Session routines successfully run
DEBUG - 2016-01-22 10:38:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Email Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Controller Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:30 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Config Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:38:32 --> URI Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Router Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Output Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Security Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Input Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:38:32 --> Language Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Language Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Config Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Loader Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:38:32 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:38:32 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Session Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:38:32 --> Session routines successfully run
DEBUG - 2016-01-22 10:38:32 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Email Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Controller Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:38:32 --> Model Class Initialized
DEBUG - 2016-01-22 10:38:32 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Config Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:48:25 --> URI Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Router Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Output Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Security Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Input Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:48:25 --> Language Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Language Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Config Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Loader Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:48:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:48:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Session Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:48:25 --> Session routines successfully run
DEBUG - 2016-01-22 10:48:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:48:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:48:26 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:48:26 --> Email Class Initialized
DEBUG - 2016-01-22 10:48:26 --> Controller Class Initialized
DEBUG - 2016-01-22 10:48:26 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:48:26 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:26 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Config Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:48:27 --> URI Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Router Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Output Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Security Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Input Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:48:27 --> Language Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Language Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Config Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Loader Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:48:27 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:48:27 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Session Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:48:27 --> Session routines successfully run
DEBUG - 2016-01-22 10:48:27 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Email Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Controller Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:48:27 --> Model Class Initialized
DEBUG - 2016-01-22 10:48:27 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Config Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:49:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:49:04 --> URI Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Router Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Output Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Security Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Input Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:49:04 --> Language Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Language Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Config Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Loader Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:49:04 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:49:04 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Session Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:49:04 --> Session routines successfully run
DEBUG - 2016-01-22 10:49:04 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:49:04 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:49:05 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:49:05 --> Email Class Initialized
DEBUG - 2016-01-22 10:49:05 --> Controller Class Initialized
DEBUG - 2016-01-22 10:49:05 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:49:05 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:05 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Config Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:49:06 --> URI Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Router Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Output Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Security Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Input Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:49:06 --> Language Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Language Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Config Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Loader Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:49:06 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:49:06 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Session Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:49:06 --> Session routines successfully run
DEBUG - 2016-01-22 10:49:06 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Email Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Controller Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:49:06 --> Model Class Initialized
DEBUG - 2016-01-22 10:49:06 --> Image Lib Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Config Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:50:39 --> URI Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Router Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Output Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Security Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Input Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:50:39 --> Language Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Language Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Config Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Loader Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:50:39 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:50:39 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Session Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:50:39 --> Session routines successfully run
DEBUG - 2016-01-22 10:50:39 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Email Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Controller Class Initialized
DEBUG - 2016-01-22 10:50:39 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:50:39 --> Model Class Initialized
DEBUG - 2016-01-22 10:50:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 10:50:39 --> Model Class Initialized
DEBUG - 2016-01-22 10:50:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:50:39 --> Model Class Initialized
DEBUG - 2016-01-22 10:50:39 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:50:39 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:50:39 --> File loaded: application/modules/administration/views/reports/all_transactions.php
ERROR - 2016-01-22 10:50:39 --> Severity: Notice  --> Undefined property: CI::$site_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-22 10:51:35 --> Config Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:51:35 --> URI Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Router Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Output Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Security Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Input Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:51:35 --> Language Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Language Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Config Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Loader Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:51:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:51:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Session Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:51:35 --> Session routines successfully run
DEBUG - 2016-01-22 10:51:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Email Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Controller Class Initialized
DEBUG - 2016-01-22 10:51:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:51:35 --> Model Class Initialized
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 10:51:35 --> Model Class Initialized
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:51:35 --> Model Class Initialized
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:51:35 --> Model Class Initialized
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:51:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
ERROR - 2016-01-22 10:51:35 --> Severity: Notice  --> Undefined property: CI::$sections_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-22 10:52:24 --> Config Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:52:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:52:24 --> URI Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Router Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Output Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Security Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Input Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:52:24 --> Language Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Language Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Config Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Loader Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:52:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:52:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Session Class Initialized
DEBUG - 2016-01-22 10:52:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:52:24 --> Session routines successfully run
DEBUG - 2016-01-22 10:52:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:52:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:52:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:52:25 --> Email Class Initialized
DEBUG - 2016-01-22 10:52:25 --> Controller Class Initialized
DEBUG - 2016-01-22 10:52:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:52:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Config Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:53:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:53:18 --> URI Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Router Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Output Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Security Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Input Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:53:18 --> Language Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Language Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Config Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Loader Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:53:18 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:53:18 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Session Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:53:18 --> Session routines successfully run
DEBUG - 2016-01-22 10:53:18 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Email Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Controller Class Initialized
DEBUG - 2016-01-22 10:53:18 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:53:18 --> Model Class Initialized
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:53:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:53:18 --> Final output sent to browser
DEBUG - 2016-01-22 10:53:18 --> Total execution time: 0.2637
DEBUG - 2016-01-22 10:55:07 --> Config Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 10:55:07 --> URI Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Router Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Output Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Security Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Input Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 10:55:07 --> Language Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Language Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Config Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Loader Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 10:55:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 10:55:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Session Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Helper loaded: string_helper
DEBUG - 2016-01-22 10:55:07 --> Session routines successfully run
DEBUG - 2016-01-22 10:55:07 --> Form Validation Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Pagination Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Encrypt Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Email Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Controller Class Initialized
DEBUG - 2016-01-22 10:55:07 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 10:55:07 --> Model Class Initialized
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 10:55:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 10:55:07 --> Final output sent to browser
DEBUG - 2016-01-22 10:55:07 --> Total execution time: 0.3803
DEBUG - 2016-01-22 11:11:13 --> Config Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:11:13 --> URI Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Router Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Output Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Security Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Input Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:11:13 --> Language Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Language Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Config Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Loader Class Initialized
DEBUG - 2016-01-22 11:11:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:11:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:11:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Session Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:11:14 --> Session routines successfully run
DEBUG - 2016-01-22 11:11:14 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Email Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Controller Class Initialized
DEBUG - 2016-01-22 11:11:14 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:11:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:11:14 --> Final output sent to browser
DEBUG - 2016-01-22 11:11:14 --> Total execution time: 0.6151
DEBUG - 2016-01-22 11:11:41 --> Config Class Initialized
DEBUG - 2016-01-22 11:11:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:11:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:11:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:11:41 --> URI Class Initialized
DEBUG - 2016-01-22 11:11:41 --> Router Class Initialized
ERROR - 2016-01-22 11:11:42 --> 404 Page Not Found --> 
DEBUG - 2016-01-22 11:12:41 --> Config Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:12:41 --> URI Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Router Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Output Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Security Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Input Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:12:41 --> Language Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Language Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Config Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Loader Class Initialized
DEBUG - 2016-01-22 11:12:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:12:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:12:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Session Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:12:42 --> Session routines successfully run
DEBUG - 2016-01-22 11:12:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Email Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Controller Class Initialized
DEBUG - 2016-01-22 11:12:42 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:12:42 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:12:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:12:42 --> Final output sent to browser
DEBUG - 2016-01-22 11:12:42 --> Total execution time: 0.2796
DEBUG - 2016-01-22 11:12:54 --> Config Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:12:54 --> URI Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Router Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Output Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Security Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Input Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:12:54 --> Language Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Language Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Config Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Loader Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:12:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:12:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Session Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:12:54 --> Session routines successfully run
DEBUG - 2016-01-22 11:12:54 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Email Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Controller Class Initialized
DEBUG - 2016-01-22 11:12:54 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:12:54 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:12:54 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:12:55 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:12:55 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:12:55 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:12:55 --> Model Class Initialized
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:12:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:12:55 --> Final output sent to browser
DEBUG - 2016-01-22 11:12:55 --> Total execution time: 0.2285
DEBUG - 2016-01-22 11:13:05 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:13:05 --> URI Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Router Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Output Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Security Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Input Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:13:05 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Loader Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:13:05 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:13:05 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Session Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:13:05 --> Session routines successfully run
DEBUG - 2016-01-22 11:13:05 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Email Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Controller Class Initialized
DEBUG - 2016-01-22 11:13:05 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:13:05 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:13:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:13:05 --> Final output sent to browser
DEBUG - 2016-01-22 11:13:05 --> Total execution time: 0.2264
DEBUG - 2016-01-22 11:13:15 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:13:15 --> URI Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Router Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Output Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Security Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Input Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:13:15 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Loader Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:13:15 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:13:15 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Session Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:13:15 --> Session routines successfully run
DEBUG - 2016-01-22 11:13:15 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Email Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Controller Class Initialized
DEBUG - 2016-01-22 11:13:15 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:13:15 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:13:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:13:15 --> Final output sent to browser
DEBUG - 2016-01-22 11:13:15 --> Total execution time: 0.2437
DEBUG - 2016-01-22 11:13:31 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:13:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:13:31 --> URI Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Router Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Output Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Security Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Input Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:13:31 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Language Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Config Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Loader Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:13:31 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:13:31 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Session Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:13:31 --> Session routines successfully run
DEBUG - 2016-01-22 11:13:31 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Email Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Controller Class Initialized
DEBUG - 2016-01-22 11:13:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:13:31 --> Model Class Initialized
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:13:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:13:31 --> Final output sent to browser
DEBUG - 2016-01-22 11:13:31 --> Total execution time: 0.2219
DEBUG - 2016-01-22 11:42:14 --> Config Class Initialized
DEBUG - 2016-01-22 11:42:14 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:42:14 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:42:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:42:15 --> URI Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Router Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Output Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Security Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Input Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:42:15 --> Language Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Language Class Initialized
DEBUG - 2016-01-22 11:42:15 --> Config Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Loader Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:42:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Config Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:42:16 --> URI Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Router Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Output Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Security Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Input Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:42:16 --> Language Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Language Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Config Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Loader Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:42:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Session Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Session Class Initialized
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:42:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:42:16 --> Session routines successfully run
DEBUG - 2016-01-22 11:42:16 --> Session routines successfully run
DEBUG - 2016-01-22 11:42:17 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Email Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Email Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Controller Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Property MX_Controller Initialized
DEBUG - 2016-01-22 11:42:17 --> Controller Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Image Lib Class Initialized
DEBUG - 2016-01-22 11:42:17 --> Image Lib Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:17 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 11:42:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 11:42:18 --> Model Class Initialized
DEBUG - 2016-01-22 11:42:19 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-22 11:42:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 11:42:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 11:42:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 11:42:19 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:42:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:42:20 --> Final output sent to browser
DEBUG - 2016-01-22 11:42:20 --> Total execution time: 6.1497
DEBUG - 2016-01-22 11:42:20 --> Final output sent to browser
DEBUG - 2016-01-22 11:42:20 --> Total execution time: 3.7971
DEBUG - 2016-01-22 11:48:09 --> Config Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:48:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:48:09 --> URI Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Router Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Output Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Security Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Input Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:48:09 --> Language Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Language Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Config Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Loader Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:48:09 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:48:09 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Session Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:48:09 --> Session routines successfully run
DEBUG - 2016-01-22 11:48:09 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Email Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Controller Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Property MX_Controller Initialized
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:48:09 --> Model Class Initialized
DEBUG - 2016-01-22 11:48:09 --> Image Lib Class Initialized
DEBUG - 2016-01-22 11:48:10 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-22 11:48:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:48:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:48:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:48:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:48:10 --> Final output sent to browser
DEBUG - 2016-01-22 11:48:10 --> Total execution time: 0.3452
DEBUG - 2016-01-22 11:52:51 --> Config Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:52:51 --> URI Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Router Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Output Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Security Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Input Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:52:51 --> Language Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Language Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Config Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Loader Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:52:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:52:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Session Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:52:51 --> Session routines successfully run
DEBUG - 2016-01-22 11:52:51 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Email Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Controller Class Initialized
DEBUG - 2016-01-22 11:52:51 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:52:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:52:52 --> DB Transaction Failure
ERROR - 2016-01-22 11:52:52 --> Query error: Unknown column 'rental_uni.rental_unit_id' in 'where clause'
DEBUG - 2016-01-22 11:52:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 11:53:13 --> Config Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:53:13 --> URI Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Router Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Output Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Security Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Input Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:53:13 --> Language Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Language Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Config Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Loader Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:53:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:53:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Session Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:53:13 --> Session routines successfully run
DEBUG - 2016-01-22 11:53:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Email Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Controller Class Initialized
DEBUG - 2016-01-22 11:53:13 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:53:13 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:13 --> DB Transaction Failure
ERROR - 2016-01-22 11:53:13 --> Query error: Unknown column 'payment_method.payment_method_name' in 'field list'
DEBUG - 2016-01-22 11:53:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 11:53:51 --> Config Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:53:51 --> URI Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Router Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Output Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Security Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Input Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:53:51 --> Language Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Language Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Config Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Loader Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:53:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:53:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Session Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:53:51 --> Session routines successfully run
DEBUG - 2016-01-22 11:53:51 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Email Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Controller Class Initialized
DEBUG - 2016-01-22 11:53:51 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:53:51 --> Model Class Initialized
DEBUG - 2016-01-22 11:53:52 --> DB Transaction Failure
ERROR - 2016-01-22 11:53:52 --> Query error: Unknown column 'payment_method.payment_method_name' in 'field list'
DEBUG - 2016-01-22 11:53:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 11:54:17 --> Config Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:54:17 --> URI Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Router Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Output Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Security Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Input Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:54:17 --> Language Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Language Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Config Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Loader Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:54:17 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:54:17 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Session Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:54:17 --> Session routines successfully run
DEBUG - 2016-01-22 11:54:17 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Email Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Controller Class Initialized
DEBUG - 2016-01-22 11:54:17 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:54:17 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:17 --> DB Transaction Failure
ERROR - 2016-01-22 11:54:17 --> Query error: Unknown column 'rental_unit.renatl_unit_name' in 'order clause'
DEBUG - 2016-01-22 11:54:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 11:54:33 --> Config Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:54:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:54:33 --> URI Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Router Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Output Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Security Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Input Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:54:33 --> Language Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Language Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Config Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Loader Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:54:33 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:54:33 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Session Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:54:33 --> Session routines successfully run
DEBUG - 2016-01-22 11:54:33 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Email Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Controller Class Initialized
DEBUG - 2016-01-22 11:54:33 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:54:33 --> Model Class Initialized
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:54:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:54:34 --> Final output sent to browser
DEBUG - 2016-01-22 11:54:34 --> Total execution time: 0.4237
DEBUG - 2016-01-22 11:55:48 --> Config Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Hooks Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Utf8 Class Initialized
DEBUG - 2016-01-22 11:55:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 11:55:48 --> URI Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Router Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Output Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Security Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Input Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 11:55:48 --> Language Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Language Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Config Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Loader Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Helper loaded: url_helper
DEBUG - 2016-01-22 11:55:48 --> Helper loaded: form_helper
DEBUG - 2016-01-22 11:55:48 --> Database Driver Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Session Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Helper loaded: string_helper
DEBUG - 2016-01-22 11:55:48 --> Session routines successfully run
DEBUG - 2016-01-22 11:55:48 --> Form Validation Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Pagination Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Encrypt Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Email Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Controller Class Initialized
DEBUG - 2016-01-22 11:55:48 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 11:55:48 --> Model Class Initialized
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 11:55:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 11:55:48 --> Final output sent to browser
DEBUG - 2016-01-22 11:55:48 --> Total execution time: 0.2510
DEBUG - 2016-01-22 12:19:09 --> Config Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:19:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:19:09 --> URI Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Router Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Output Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Security Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Input Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:19:09 --> Language Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Language Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Config Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Loader Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:19:09 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:19:09 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Session Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:19:09 --> Session routines successfully run
DEBUG - 2016-01-22 12:19:09 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Email Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Controller Class Initialized
DEBUG - 2016-01-22 12:19:09 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:19:09 --> Model Class Initialized
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:19:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:19:09 --> Final output sent to browser
DEBUG - 2016-01-22 12:19:09 --> Total execution time: 0.3562
DEBUG - 2016-01-22 12:21:37 --> Config Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:21:37 --> URI Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Router Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Output Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Security Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Input Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:21:37 --> Language Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Language Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Config Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Loader Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:21:37 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:21:37 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Session Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:21:37 --> Session routines successfully run
DEBUG - 2016-01-22 12:21:37 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Email Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Controller Class Initialized
DEBUG - 2016-01-22 12:21:37 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:21:37 --> Model Class Initialized
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:21:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:21:37 --> Final output sent to browser
DEBUG - 2016-01-22 12:21:37 --> Total execution time: 0.2840
DEBUG - 2016-01-22 12:43:31 --> Config Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:43:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:43:32 --> URI Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Router Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Output Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Security Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Input Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:43:32 --> Language Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Language Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Config Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Loader Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:43:32 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:43:32 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Session Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:43:32 --> Session routines successfully run
DEBUG - 2016-01-22 12:43:32 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Email Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Controller Class Initialized
DEBUG - 2016-01-22 12:43:32 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:43:32 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:43:32 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:43:32 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:43:32 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:43:33 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:43:33 --> Model Class Initialized
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:43:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:43:33 --> Final output sent to browser
DEBUG - 2016-01-22 12:43:33 --> Total execution time: 1.8107
DEBUG - 2016-01-22 12:43:59 --> Config Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:43:59 --> URI Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Router Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Output Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Security Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Input Class Initialized
DEBUG - 2016-01-22 12:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:43:59 --> Language Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Language Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Config Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Loader Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:44:00 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:44:00 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Session Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:44:00 --> Session routines successfully run
DEBUG - 2016-01-22 12:44:00 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Email Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Controller Class Initialized
DEBUG - 2016-01-22 12:44:00 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:44:00 --> Model Class Initialized
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:44:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:44:00 --> Final output sent to browser
DEBUG - 2016-01-22 12:44:00 --> Total execution time: 0.3234
DEBUG - 2016-01-22 12:45:38 --> Config Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:45:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:45:38 --> URI Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Router Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Output Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Security Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Input Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:45:38 --> Language Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Language Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Config Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Loader Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:45:38 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:45:38 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Session Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:45:38 --> Session routines successfully run
DEBUG - 2016-01-22 12:45:38 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Email Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Controller Class Initialized
DEBUG - 2016-01-22 12:45:38 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:45:38 --> Model Class Initialized
ERROR - 2016-01-22 12:45:39 --> Severity: Notice  --> Undefined variable: where2 C:\xampp\htdocs\rents\application\modules\administration\controllers\reports.php 128
DEBUG - 2016-01-22 12:45:39 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 12:45:39 --> Severity: Notice  --> Undefined variable: normal_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 104
DEBUG - 2016-01-22 12:45:50 --> Config Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:45:50 --> URI Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Router Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Output Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Security Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Input Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:45:50 --> Language Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Language Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Config Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Loader Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:45:50 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:45:50 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Session Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:45:50 --> Session routines successfully run
DEBUG - 2016-01-22 12:45:50 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Email Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Controller Class Initialized
DEBUG - 2016-01-22 12:45:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:45:50 --> Model Class Initialized
DEBUG - 2016-01-22 12:45:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 12:45:50 --> Severity: Notice  --> Undefined variable: normal_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 104
DEBUG - 2016-01-22 12:46:31 --> Config Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:46:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:46:31 --> URI Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Router Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Output Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Security Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Input Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:46:31 --> Language Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Language Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Config Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Loader Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:46:31 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:46:31 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Session Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:46:31 --> Session routines successfully run
DEBUG - 2016-01-22 12:46:31 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Email Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Controller Class Initialized
DEBUG - 2016-01-22 12:46:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:46:31 --> Model Class Initialized
DEBUG - 2016-01-22 12:46:31 --> DB Transaction Failure
ERROR - 2016-01-22 12:46:31 --> Query error: Not unique table/alias: 'payments'
DEBUG - 2016-01-22 12:46:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 12:47:13 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:47:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:47:14 --> URI Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Router Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Output Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Security Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Input Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:47:14 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Loader Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:47:14 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:47:14 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Session Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:47:14 --> Session routines successfully run
DEBUG - 2016-01-22 12:47:14 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Email Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Controller Class Initialized
DEBUG - 2016-01-22 12:47:14 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:47:14 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:14 --> DB Transaction Failure
ERROR - 2016-01-22 12:47:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'payments.cancel = 0' at line 3
DEBUG - 2016-01-22 12:47:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 12:47:24 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:47:24 --> URI Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Router Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Output Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Security Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Input Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:47:24 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Loader Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:47:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:47:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Session Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:47:24 --> Session routines successfully run
DEBUG - 2016-01-22 12:47:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Email Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Controller Class Initialized
DEBUG - 2016-01-22 12:47:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:47:24 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:24 --> DB Transaction Failure
ERROR - 2016-01-22 12:47:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'payments.cancel = 0' at line 3
DEBUG - 2016-01-22 12:47:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 12:47:35 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:47:35 --> URI Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Router Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Output Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Security Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Input Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:47:35 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Language Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Config Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Loader Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:47:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:47:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Session Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:47:35 --> Session routines successfully run
DEBUG - 2016-01-22 12:47:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Email Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Controller Class Initialized
DEBUG - 2016-01-22 12:47:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:47:35 --> Model Class Initialized
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:47:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:47:35 --> Final output sent to browser
DEBUG - 2016-01-22 12:47:35 --> Total execution time: 0.6935
DEBUG - 2016-01-22 12:57:19 --> Config Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 12:57:19 --> URI Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Router Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Output Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Security Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Input Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 12:57:19 --> Language Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Language Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Config Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Loader Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 12:57:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 12:57:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Session Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 12:57:19 --> Session routines successfully run
DEBUG - 2016-01-22 12:57:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Email Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Controller Class Initialized
DEBUG - 2016-01-22 12:57:19 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 12:57:19 --> Model Class Initialized
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 12:57:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 12:57:19 --> Final output sent to browser
DEBUG - 2016-01-22 12:57:19 --> Total execution time: 0.3657
DEBUG - 2016-01-22 13:02:34 --> Config Class Initialized
DEBUG - 2016-01-22 13:02:34 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:02:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:02:35 --> URI Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Router Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Output Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Security Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Input Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:02:35 --> Language Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Language Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Config Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Loader Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:02:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:02:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Session Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:02:35 --> Session routines successfully run
DEBUG - 2016-01-22 13:02:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Email Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Controller Class Initialized
DEBUG - 2016-01-22 13:02:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:02:35 --> Model Class Initialized
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:02:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:02:35 --> Final output sent to browser
DEBUG - 2016-01-22 13:02:35 --> Total execution time: 0.3113
DEBUG - 2016-01-22 13:03:48 --> Config Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:03:48 --> URI Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Router Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Output Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Security Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Input Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:03:48 --> Language Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Language Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Config Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Loader Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:03:48 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:03:48 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Session Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:03:48 --> Session routines successfully run
DEBUG - 2016-01-22 13:03:48 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Email Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Controller Class Initialized
DEBUG - 2016-01-22 13:03:48 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:03:48 --> Model Class Initialized
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:03:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:03:48 --> Final output sent to browser
DEBUG - 2016-01-22 13:03:48 --> Total execution time: 0.2813
DEBUG - 2016-01-22 13:04:50 --> Config Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:04:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:04:50 --> URI Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Router Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Output Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Security Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Input Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:04:50 --> Language Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Language Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Config Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Loader Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:04:50 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:04:50 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Session Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:04:50 --> Session routines successfully run
DEBUG - 2016-01-22 13:04:50 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Email Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Controller Class Initialized
DEBUG - 2016-01-22 13:04:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:04:50 --> Model Class Initialized
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:04:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:04:50 --> Final output sent to browser
DEBUG - 2016-01-22 13:04:50 --> Total execution time: 0.3664
DEBUG - 2016-01-22 13:13:22 --> Config Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:13:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:13:22 --> URI Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Router Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Output Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Security Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Input Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:13:22 --> Language Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Language Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Config Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Loader Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:13:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:13:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Session Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:13:22 --> Session routines successfully run
DEBUG - 2016-01-22 13:13:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Email Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Controller Class Initialized
DEBUG - 2016-01-22 13:13:22 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:13:22 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:13:22 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
ERROR - 2016-01-22 13:13:22 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_transactions.php 27
ERROR - 2016-01-22 13:13:22 --> Severity: Notice  --> Undefined property: CI::$personnel_model C:\xampp\htdocs\rents\application\libraries\MX\Controller.php 58
DEBUG - 2016-01-22 13:13:45 --> Config Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:13:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:13:45 --> URI Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Router Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Output Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Security Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Input Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:13:45 --> Language Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Language Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Config Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Loader Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:13:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:13:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Session Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:13:45 --> Session routines successfully run
DEBUG - 2016-01-22 13:13:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Email Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Controller Class Initialized
DEBUG - 2016-01-22 13:13:45 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:13:45 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:13:45 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:13:45 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:13:46 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:13:46 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:13:46 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:13:46 --> Model Class Initialized
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
ERROR - 2016-01-22 13:13:46 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_transactions.php 27
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:13:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:13:46 --> Final output sent to browser
DEBUG - 2016-01-22 13:13:46 --> Total execution time: 0.6928
DEBUG - 2016-01-22 13:14:42 --> Config Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:14:42 --> URI Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Router Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Output Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Security Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Input Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:14:42 --> Language Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Language Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Config Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Loader Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:14:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:14:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Session Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:14:42 --> Session routines successfully run
DEBUG - 2016-01-22 13:14:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Email Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Controller Class Initialized
DEBUG - 2016-01-22 13:14:42 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:14:42 --> Model Class Initialized
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
ERROR - 2016-01-22 13:14:42 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_transactions.php 27
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:14:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:14:42 --> Final output sent to browser
DEBUG - 2016-01-22 13:14:42 --> Total execution time: 0.3974
DEBUG - 2016-01-22 13:15:38 --> Config Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:15:38 --> URI Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Router Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Output Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Security Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Input Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:15:38 --> Language Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Language Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Config Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Loader Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:15:38 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:15:38 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Session Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:15:38 --> Session routines successfully run
DEBUG - 2016-01-22 13:15:38 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Email Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Controller Class Initialized
DEBUG - 2016-01-22 13:15:38 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:15:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:15:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:15:38 --> Final output sent to browser
DEBUG - 2016-01-22 13:15:38 --> Total execution time: 0.3497
DEBUG - 2016-01-22 13:16:40 --> Config Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:16:40 --> URI Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Router Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Output Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Security Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Input Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:16:40 --> Language Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Language Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Config Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Loader Class Initialized
DEBUG - 2016-01-22 13:16:40 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:16:40 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:16:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Session Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:16:41 --> Session routines successfully run
DEBUG - 2016-01-22 13:16:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Email Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Controller Class Initialized
DEBUG - 2016-01-22 13:16:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:16:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:16:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:16:41 --> Final output sent to browser
DEBUG - 2016-01-22 13:16:41 --> Total execution time: 0.3683
DEBUG - 2016-01-22 13:19:16 --> Config Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:19:16 --> URI Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Router Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Output Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Security Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Input Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:19:16 --> Language Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Language Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Config Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Loader Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:19:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:19:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Session Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:19:16 --> Session routines successfully run
DEBUG - 2016-01-22 13:19:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Email Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Controller Class Initialized
DEBUG - 2016-01-22 13:19:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:19:16 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:19:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:19:16 --> Final output sent to browser
DEBUG - 2016-01-22 13:19:16 --> Total execution time: 0.3417
DEBUG - 2016-01-22 13:19:38 --> Config Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:19:38 --> URI Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Router Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Output Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Security Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Input Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:19:38 --> Language Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Language Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Config Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Loader Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:19:38 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:19:38 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Session Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:19:38 --> Session routines successfully run
DEBUG - 2016-01-22 13:19:38 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Email Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Controller Class Initialized
DEBUG - 2016-01-22 13:19:38 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:19:38 --> Model Class Initialized
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:19:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:19:38 --> Final output sent to browser
DEBUG - 2016-01-22 13:19:38 --> Total execution time: 0.2526
DEBUG - 2016-01-22 13:20:03 --> Config Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:20:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:20:03 --> URI Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Router Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Output Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Security Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Input Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:20:03 --> Language Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Language Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Config Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Loader Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:20:03 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:20:03 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Session Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:20:03 --> Session routines successfully run
DEBUG - 2016-01-22 13:20:03 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Email Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Controller Class Initialized
DEBUG - 2016-01-22 13:20:03 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:20:03 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:20:03 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:20:04 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:20:04 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:20:04 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:20:04 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:20:04 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:20:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:20:04 --> Final output sent to browser
DEBUG - 2016-01-22 13:20:04 --> Total execution time: 0.6444
DEBUG - 2016-01-22 13:20:23 --> Config Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:20:23 --> URI Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Router Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Output Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Security Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Input Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:20:23 --> Language Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Language Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Config Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Loader Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:20:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:20:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Session Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:20:23 --> Session routines successfully run
DEBUG - 2016-01-22 13:20:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Email Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Controller Class Initialized
DEBUG - 2016-01-22 13:20:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:20:23 --> Model Class Initialized
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:20:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:20:23 --> Final output sent to browser
DEBUG - 2016-01-22 13:20:23 --> Total execution time: 0.2813
DEBUG - 2016-01-22 13:22:41 --> Config Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:22:41 --> URI Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Router Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Output Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Security Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Input Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:22:41 --> Language Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Language Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Config Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Loader Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:22:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:22:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Session Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:22:41 --> Session routines successfully run
DEBUG - 2016-01-22 13:22:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Email Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Controller Class Initialized
DEBUG - 2016-01-22 13:22:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:22:41 --> Model Class Initialized
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:22:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:22:41 --> Final output sent to browser
DEBUG - 2016-01-22 13:22:41 --> Total execution time: 0.3143
DEBUG - 2016-01-22 13:33:54 --> Config Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 13:33:54 --> URI Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Router Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Output Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Security Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Input Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 13:33:54 --> Language Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Language Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Config Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Loader Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 13:33:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 13:33:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Session Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Helper loaded: string_helper
DEBUG - 2016-01-22 13:33:54 --> Session routines successfully run
DEBUG - 2016-01-22 13:33:54 --> Form Validation Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Pagination Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Encrypt Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Email Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Controller Class Initialized
DEBUG - 2016-01-22 13:33:54 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 13:33:54 --> Model Class Initialized
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 13:33:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 13:33:54 --> Final output sent to browser
DEBUG - 2016-01-22 13:33:54 --> Total execution time: 0.3682
DEBUG - 2016-01-22 14:12:05 --> Config Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:12:06 --> URI Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Router Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Output Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Security Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Input Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:12:06 --> Language Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Language Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Config Class Initialized
DEBUG - 2016-01-22 14:12:06 --> Loader Class Initialized
DEBUG - 2016-01-22 14:12:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:12:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:12:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Session Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:12:08 --> Session routines successfully run
DEBUG - 2016-01-22 14:12:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Email Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Controller Class Initialized
DEBUG - 2016-01-22 14:12:08 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:12:08 --> Model Class Initialized
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 14:12:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 14:12:10 --> Final output sent to browser
DEBUG - 2016-01-22 14:12:10 --> Total execution time: 5.9516
DEBUG - 2016-01-22 14:26:38 --> Config Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:26:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:26:38 --> URI Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Router Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Output Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Security Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Input Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:26:38 --> Language Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Language Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Config Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Loader Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:26:38 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:26:38 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Session Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:26:38 --> Session routines successfully run
DEBUG - 2016-01-22 14:26:38 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Email Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Controller Class Initialized
DEBUG - 2016-01-22 14:26:38 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:26:38 --> Model Class Initialized
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 14:26:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 14:26:38 --> Final output sent to browser
DEBUG - 2016-01-22 14:26:38 --> Total execution time: 0.5238
DEBUG - 2016-01-22 14:27:35 --> Config Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:27:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:27:35 --> URI Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Router Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Output Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Security Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Input Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:27:35 --> Language Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Language Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Config Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Loader Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:27:35 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:27:35 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Session Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:27:35 --> Session routines successfully run
DEBUG - 2016-01-22 14:27:35 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Email Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Controller Class Initialized
DEBUG - 2016-01-22 14:27:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:27:35 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Config Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:27:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:27:56 --> URI Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Router Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Output Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Security Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Input Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:27:56 --> Language Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Language Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Config Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Loader Class Initialized
DEBUG - 2016-01-22 14:27:56 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:27:56 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:27:57 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Session Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:27:57 --> Session routines successfully run
DEBUG - 2016-01-22 14:27:57 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Email Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Controller Class Initialized
DEBUG - 2016-01-22 14:27:57 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:27:57 --> Model Class Initialized
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 14:27:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 14:27:57 --> Final output sent to browser
DEBUG - 2016-01-22 14:27:57 --> Total execution time: 0.2419
DEBUG - 2016-01-22 14:59:00 --> Config Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:59:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:59:00 --> URI Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Router Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Output Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Security Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Input Class Initialized
DEBUG - 2016-01-22 14:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:59:00 --> Language Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Language Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Config Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Loader Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:59:01 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:59:01 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Session Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:59:01 --> Session routines successfully run
DEBUG - 2016-01-22 14:59:01 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Email Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Controller Class Initialized
DEBUG - 2016-01-22 14:59:01 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:59:01 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:02 --> Image Lib Class Initialized
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 14:59:02 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 14:59:02 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 14:59:02 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 14:59:02 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 14:59:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 14:59:02 --> Final output sent to browser
DEBUG - 2016-01-22 14:59:02 --> Total execution time: 1.7776
DEBUG - 2016-01-22 14:59:34 --> Config Class Initialized
DEBUG - 2016-01-22 14:59:34 --> Hooks Class Initialized
DEBUG - 2016-01-22 14:59:34 --> Utf8 Class Initialized
DEBUG - 2016-01-22 14:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 14:59:34 --> URI Class Initialized
DEBUG - 2016-01-22 14:59:34 --> Router Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Output Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Security Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Input Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 14:59:36 --> Language Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Language Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Config Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Loader Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Helper loaded: url_helper
DEBUG - 2016-01-22 14:59:36 --> Helper loaded: form_helper
DEBUG - 2016-01-22 14:59:36 --> Database Driver Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Session Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Helper loaded: string_helper
DEBUG - 2016-01-22 14:59:36 --> Session routines successfully run
DEBUG - 2016-01-22 14:59:36 --> Form Validation Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Pagination Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Encrypt Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Email Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Controller Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> Image Lib Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 14:59:36 --> Model Class Initialized
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 14:59:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 14:59:36 --> Final output sent to browser
DEBUG - 2016-01-22 14:59:36 --> Total execution time: 2.0210
DEBUG - 2016-01-22 15:02:51 --> Config Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:02:51 --> URI Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Router Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Output Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Security Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Input Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 15:02:51 --> Language Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Language Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Config Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Loader Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 15:02:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 15:02:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Session Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Helper loaded: string_helper
DEBUG - 2016-01-22 15:02:51 --> Session routines successfully run
DEBUG - 2016-01-22 15:02:51 --> Form Validation Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Pagination Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Encrypt Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Email Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Controller Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> Image Lib Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 15:02:51 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 15:02:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 15:02:51 --> Final output sent to browser
DEBUG - 2016-01-22 15:02:51 --> Total execution time: 0.7030
DEBUG - 2016-01-22 15:02:55 --> Config Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:02:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:02:55 --> URI Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Router Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Output Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Security Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Input Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 15:02:55 --> Language Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Language Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Config Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Loader Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Helper loaded: url_helper
DEBUG - 2016-01-22 15:02:55 --> Helper loaded: form_helper
DEBUG - 2016-01-22 15:02:55 --> Database Driver Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Session Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Helper loaded: string_helper
DEBUG - 2016-01-22 15:02:55 --> Session routines successfully run
DEBUG - 2016-01-22 15:02:55 --> Form Validation Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Pagination Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Encrypt Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Email Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Controller Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> Image Lib Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 15:02:55 --> Model Class Initialized
DEBUG - 2016-01-22 15:02:55 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 15:02:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 15:02:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 15:02:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 15:02:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 15:02:56 --> Final output sent to browser
DEBUG - 2016-01-22 15:02:56 --> Total execution time: 0.9253
DEBUG - 2016-01-22 15:03:33 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:03:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:03:33 --> URI Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Router Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Output Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Security Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Input Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 15:03:33 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Loader Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Helper loaded: url_helper
DEBUG - 2016-01-22 15:03:33 --> Helper loaded: form_helper
DEBUG - 2016-01-22 15:03:33 --> Database Driver Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Session Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Helper loaded: string_helper
DEBUG - 2016-01-22 15:03:33 --> Session routines successfully run
DEBUG - 2016-01-22 15:03:33 --> Form Validation Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Pagination Class Initialized
DEBUG - 2016-01-22 15:03:33 --> Encrypt Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Email Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Controller Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Image Lib Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 15:03:34 --> XSS Filtering completed
DEBUG - 2016-01-22 15:03:34 --> XSS Filtering completed
DEBUG - 2016-01-22 15:03:34 --> XSS Filtering completed
DEBUG - 2016-01-22 15:03:34 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:03:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:03:34 --> URI Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Router Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Output Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Security Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Input Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 15:03:34 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Loader Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Helper loaded: url_helper
DEBUG - 2016-01-22 15:03:34 --> Helper loaded: form_helper
DEBUG - 2016-01-22 15:03:34 --> Database Driver Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Session Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Helper loaded: string_helper
DEBUG - 2016-01-22 15:03:34 --> Session routines successfully run
DEBUG - 2016-01-22 15:03:34 --> Form Validation Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Pagination Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Encrypt Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Email Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Controller Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> Image Lib Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:34 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 15:03:34 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 15:03:35 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 15:03:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 15:03:35 --> Final output sent to browser
DEBUG - 2016-01-22 15:03:35 --> Total execution time: 0.3590
DEBUG - 2016-01-22 15:03:57 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:03:57 --> URI Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Router Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Output Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Security Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Input Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 15:03:57 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Language Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Config Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Loader Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Helper loaded: url_helper
DEBUG - 2016-01-22 15:03:57 --> Helper loaded: form_helper
DEBUG - 2016-01-22 15:03:57 --> Database Driver Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Session Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Helper loaded: string_helper
DEBUG - 2016-01-22 15:03:57 --> Session routines successfully run
DEBUG - 2016-01-22 15:03:57 --> Form Validation Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Pagination Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Encrypt Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Email Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Controller Class Initialized
DEBUG - 2016-01-22 15:03:57 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 15:03:57 --> Model Class Initialized
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 15:03:57 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 15:03:58 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 15:03:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 15:03:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 15:03:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 15:03:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 15:03:58 --> Final output sent to browser
DEBUG - 2016-01-22 15:03:58 --> Total execution time: 0.4636
DEBUG - 2016-01-22 15:59:42 --> Config Class Initialized
DEBUG - 2016-01-22 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-01-22 15:59:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 15:59:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 15:59:43 --> URI Class Initialized
DEBUG - 2016-01-22 15:59:43 --> Router Class Initialized
DEBUG - 2016-01-22 16:00:03 --> Config Class Initialized
DEBUG - 2016-01-22 16:00:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:00:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:00:03 --> URI Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Router Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Output Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Security Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Input Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:00:04 --> Language Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Language Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Config Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Loader Class Initialized
DEBUG - 2016-01-22 16:00:04 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:00:04 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:00:04 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Session Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:00:05 --> Session routines successfully run
DEBUG - 2016-01-22 16:00:05 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Email Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Controller Class Initialized
DEBUG - 2016-01-22 16:00:05 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:00:05 --> Model Class Initialized
DEBUG - 2016-01-22 16:00:06 --> DB Transaction Failure
ERROR - 2016-01-22 16:00:06 --> Query error: Unknown column 'ASC' in 'order clause'
DEBUG - 2016-01-22 16:00:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-22 16:01:03 --> Config Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:01:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:01:03 --> URI Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Router Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Output Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Security Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Input Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:01:03 --> Language Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Language Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Config Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Loader Class Initialized
DEBUG - 2016-01-22 16:01:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:01:04 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:01:04 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Session Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:01:04 --> Session routines successfully run
DEBUG - 2016-01-22 16:01:04 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Email Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Controller Class Initialized
DEBUG - 2016-01-22 16:01:04 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:01:04 --> Model Class Initialized
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: module C:\xampp\htdocs\rents\application\modules\administration\controllers\reports.php 235
DEBUG - 2016-01-22 16:01:04 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: active_leases C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 34
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: inactive_leases C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 38
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 67
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: total_expenses C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 71
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: total_expenses C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 75
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 75
ERROR - 2016-01-22 16:01:04 --> Severity: Notice  --> Undefined variable: payment_methods C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 95
DEBUG - 2016-01-22 16:01:25 --> Config Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:01:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:01:25 --> URI Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Router Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Output Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Security Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Input Class Initialized
DEBUG - 2016-01-22 16:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:01:25 --> Language Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Config Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:01:46 --> URI Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Router Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Output Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Security Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Input Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:01:46 --> Language Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Language Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Config Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Loader Class Initialized
DEBUG - 2016-01-22 16:01:46 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:01:46 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:01:46 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Session Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:01:47 --> Session routines successfully run
DEBUG - 2016-01-22 16:01:47 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Email Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Controller Class Initialized
DEBUG - 2016-01-22 16:01:47 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:01:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:01:47 --> File loaded: application/modules/administration/views/reports/search/transactions.php
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: active_leases C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 34
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: inactive_leases C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 38
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 67
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: total_expenses C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 71
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: total_expenses C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 75
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: total_payments C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 75
ERROR - 2016-01-22 16:01:47 --> Severity: Notice  --> Undefined variable: payment_methods C:\xampp\htdocs\rents\application\modules\administration\views\reports\transaction_statistics.php 95
DEBUG - 2016-01-22 16:02:24 --> Config Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:02:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:02:24 --> URI Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Router Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Output Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Security Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Input Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:02:24 --> Language Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Language Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Config Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Loader Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:02:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:02:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Session Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:02:24 --> Session routines successfully run
DEBUG - 2016-01-22 16:02:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Email Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Controller Class Initialized
DEBUG - 2016-01-22 16:02:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:02:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:02:24 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 16:02:24 --> Severity: Notice  --> Undefined property: stdClass::$property_name C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 48
DEBUG - 2016-01-22 16:03:54 --> Config Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:03:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:03:54 --> URI Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Router Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Output Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Security Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Input Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:03:54 --> Language Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Language Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Config Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Loader Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:03:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:03:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Session Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:03:54 --> Session routines successfully run
DEBUG - 2016-01-22 16:03:54 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Email Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Controller Class Initialized
DEBUG - 2016-01-22 16:03:54 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:03:54 --> Model Class Initialized
DEBUG - 2016-01-22 16:03:54 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:04:12 --> Config Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:04:12 --> URI Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Router Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Output Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Security Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Input Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:04:12 --> Language Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Language Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Config Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Loader Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:04:12 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:04:12 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Session Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:04:12 --> Session routines successfully run
DEBUG - 2016-01-22 16:04:12 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Email Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Controller Class Initialized
DEBUG - 2016-01-22 16:04:12 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:04:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:04:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:04:12 --> Final output sent to browser
DEBUG - 2016-01-22 16:04:12 --> Total execution time: 0.3565
DEBUG - 2016-01-22 16:04:59 --> Config Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:04:59 --> URI Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Router Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Output Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Security Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Input Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:04:59 --> Language Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Language Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Config Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Loader Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:04:59 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:04:59 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Session Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:04:59 --> Session routines successfully run
DEBUG - 2016-01-22 16:04:59 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Email Class Initialized
DEBUG - 2016-01-22 16:04:59 --> Controller Class Initialized
DEBUG - 2016-01-22 16:05:00 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:05:00 --> Model Class Initialized
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:05:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:05:00 --> Final output sent to browser
DEBUG - 2016-01-22 16:05:00 --> Total execution time: 0.2278
DEBUG - 2016-01-22 16:07:12 --> Config Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:07:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:07:12 --> URI Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Router Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Output Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Security Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Input Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:07:12 --> Language Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Language Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Config Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Loader Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:07:12 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:07:12 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Session Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:07:12 --> Session routines successfully run
DEBUG - 2016-01-22 16:07:12 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Email Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Controller Class Initialized
DEBUG - 2016-01-22 16:07:12 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:07:12 --> Model Class Initialized
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:07:12 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:07:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:07:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:07:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:07:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:07:13 --> Final output sent to browser
DEBUG - 2016-01-22 16:07:13 --> Total execution time: 0.4359
DEBUG - 2016-01-22 16:11:34 --> Config Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:11:34 --> URI Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Router Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Output Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Security Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Input Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:11:34 --> Language Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Language Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Config Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Loader Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:11:34 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:11:34 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Session Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:11:34 --> Session routines successfully run
DEBUG - 2016-01-22 16:11:34 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Email Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Controller Class Initialized
DEBUG - 2016-01-22 16:11:34 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:11:34 --> Model Class Initialized
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:11:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:11:34 --> Final output sent to browser
DEBUG - 2016-01-22 16:11:34 --> Total execution time: 0.2686
DEBUG - 2016-01-22 16:12:30 --> Config Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:12:30 --> URI Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Router Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Output Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Security Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Input Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:12:30 --> Language Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Language Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Config Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Loader Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:12:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:12:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Session Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:12:30 --> Session routines successfully run
DEBUG - 2016-01-22 16:12:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Email Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Controller Class Initialized
DEBUG - 2016-01-22 16:12:30 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:12:30 --> Model Class Initialized
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:12:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:12:30 --> Final output sent to browser
DEBUG - 2016-01-22 16:12:30 --> Total execution time: 0.2339
DEBUG - 2016-01-22 16:13:06 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:13:06 --> URI Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Router Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Output Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Security Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Input Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:13:06 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Loader Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:13:06 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:13:06 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Session Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:13:06 --> Session routines successfully run
DEBUG - 2016-01-22 16:13:06 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Email Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Controller Class Initialized
DEBUG - 2016-01-22 16:13:06 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:13:06 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:13:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:13:06 --> Final output sent to browser
DEBUG - 2016-01-22 16:13:06 --> Total execution time: 0.3992
DEBUG - 2016-01-22 16:13:19 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:13:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:13:19 --> URI Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Router Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Output Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Security Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Input Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:13:19 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Loader Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:13:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:13:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Session Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:13:19 --> Session routines successfully run
DEBUG - 2016-01-22 16:13:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Email Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Controller Class Initialized
DEBUG - 2016-01-22 16:13:19 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:13:19 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:13:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:13:20 --> Final output sent to browser
DEBUG - 2016-01-22 16:13:20 --> Total execution time: 0.3060
DEBUG - 2016-01-22 16:13:44 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:13:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:13:44 --> URI Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Router Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Output Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Security Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Input Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:13:44 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Language Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Config Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Loader Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:13:44 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:13:44 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Session Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:13:44 --> Session routines successfully run
DEBUG - 2016-01-22 16:13:44 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Email Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Controller Class Initialized
DEBUG - 2016-01-22 16:13:44 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:13:44 --> Model Class Initialized
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:13:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:13:44 --> Final output sent to browser
DEBUG - 2016-01-22 16:13:44 --> Total execution time: 0.2290
DEBUG - 2016-01-22 16:14:45 --> Config Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:14:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:14:45 --> URI Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Router Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Output Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Security Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Input Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:14:45 --> Language Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Language Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Config Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Loader Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:14:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:14:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Session Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:14:45 --> Session routines successfully run
DEBUG - 2016-01-22 16:14:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Email Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Controller Class Initialized
DEBUG - 2016-01-22 16:14:45 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:14:45 --> Model Class Initialized
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:14:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:14:45 --> Final output sent to browser
DEBUG - 2016-01-22 16:14:45 --> Total execution time: 0.3074
DEBUG - 2016-01-22 16:18:47 --> Config Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:18:47 --> URI Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Router Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Output Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Security Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Input Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:18:47 --> Language Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Language Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Config Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Loader Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:18:47 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:18:47 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Session Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:18:47 --> Session routines successfully run
DEBUG - 2016-01-22 16:18:47 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Email Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Controller Class Initialized
DEBUG - 2016-01-22 16:18:47 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:18:47 --> Model Class Initialized
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:18:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:18:47 --> Final output sent to browser
DEBUG - 2016-01-22 16:18:47 --> Total execution time: 0.2803
DEBUG - 2016-01-22 16:19:24 --> Config Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:19:24 --> URI Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Router Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Output Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Security Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Input Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:19:24 --> Language Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Language Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Config Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Loader Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:19:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:19:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Session Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:19:24 --> Session routines successfully run
DEBUG - 2016-01-22 16:19:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Email Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Controller Class Initialized
DEBUG - 2016-01-22 16:19:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:19:25 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:19:25 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:19:25 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:19:25 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:19:25 --> Model Class Initialized
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:19:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:19:25 --> Final output sent to browser
DEBUG - 2016-01-22 16:19:25 --> Total execution time: 0.2528
DEBUG - 2016-01-22 16:23:28 --> Config Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:23:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:23:28 --> URI Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Router Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Output Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Security Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Input Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:23:28 --> Language Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Language Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Config Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Loader Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:23:28 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:23:28 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Session Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:23:28 --> Session routines successfully run
DEBUG - 2016-01-22 16:23:28 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Email Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Controller Class Initialized
DEBUG - 2016-01-22 16:23:28 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:23:29 --> Model Class Initialized
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:23:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:23:29 --> Final output sent to browser
DEBUG - 2016-01-22 16:23:29 --> Total execution time: 0.2446
DEBUG - 2016-01-22 16:24:16 --> Config Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 16:24:16 --> URI Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Router Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Output Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Security Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Input Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 16:24:16 --> Language Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Language Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Config Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Loader Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 16:24:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 16:24:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Session Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 16:24:16 --> Session routines successfully run
DEBUG - 2016-01-22 16:24:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Email Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Controller Class Initialized
DEBUG - 2016-01-22 16:24:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 16:24:16 --> Model Class Initialized
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 16:24:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 16:24:17 --> Final output sent to browser
DEBUG - 2016-01-22 16:24:17 --> Total execution time: 0.2321
DEBUG - 2016-01-22 17:36:29 --> Config Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:36:30 --> URI Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Router Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Output Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Security Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Input Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:36:30 --> Language Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Language Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Config Class Initialized
DEBUG - 2016-01-22 17:36:30 --> Loader Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:36:31 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:36:31 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Session Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:36:31 --> Session routines successfully run
DEBUG - 2016-01-22 17:36:31 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Email Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Controller Class Initialized
DEBUG - 2016-01-22 17:36:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:36:31 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:36:31 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:36:32 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:32 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:36:32 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:36:32 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:36:32 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:36:32 --> Model Class Initialized
DEBUG - 2016-01-22 17:36:33 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:36:33 --> Severity: Notice  --> Undefined property: stdClass::$arrears_bf C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 64
ERROR - 2016-01-22 17:36:33 --> Severity: Notice  --> Undefined property: CI::$accounts_model C:\xampp\htdocs\rents\system\core\Model.php 52
DEBUG - 2016-01-22 17:40:00 --> Config Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:40:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:40:00 --> URI Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Router Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Output Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Security Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Input Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:40:00 --> Language Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Language Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Config Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Loader Class Initialized
DEBUG - 2016-01-22 17:40:00 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:40:00 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:40:01 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Session Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:40:01 --> Session routines successfully run
DEBUG - 2016-01-22 17:40:01 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Email Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Controller Class Initialized
DEBUG - 2016-01-22 17:40:01 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:40:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:40:01 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:40:01 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 58
ERROR - 2016-01-22 17:40:01 --> Severity: Notice  --> Undefined property: CI::$accounts_model C:\xampp\htdocs\rents\system\core\Model.php 52
DEBUG - 2016-01-22 17:41:00 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:00 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:41:00 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:41:00 --> URI Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Router Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Output Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Security Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Input Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:41:01 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Loader Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:41:01 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:41:01 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Session Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:41:01 --> Session routines successfully run
DEBUG - 2016-01-22 17:41:01 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Email Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Controller Class Initialized
DEBUG - 2016-01-22 17:41:01 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:41:01 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:01 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:41:01 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 58
ERROR - 2016-01-22 17:41:01 --> Severity: Notice  --> Undefined property: CI::$accounts_model C:\xampp\htdocs\rents\system\core\Model.php 52
DEBUG - 2016-01-22 17:41:16 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:41:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:41:16 --> URI Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Router Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Output Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Security Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Input Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:41:16 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Loader Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:41:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:41:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Session Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:41:16 --> Session routines successfully run
DEBUG - 2016-01-22 17:41:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Email Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Controller Class Initialized
DEBUG - 2016-01-22 17:41:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:41:16 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:16 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:41:17 --> Severity: Notice  --> Undefined property: CI::$accounts_model C:\xampp\htdocs\rents\system\core\Model.php 52
DEBUG - 2016-01-22 17:41:41 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:41:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:41:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:41:41 --> URI Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Router Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Output Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Security Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Input Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:41:42 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Language Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Config Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Loader Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:41:42 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:41:42 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Session Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:41:42 --> Session routines successfully run
DEBUG - 2016-01-22 17:41:42 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Email Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Controller Class Initialized
DEBUG - 2016-01-22 17:41:42 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 17:41:42 --> Model Class Initialized
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:41:42 --> Severity: Notice  --> Undefined variable: receipt_number C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 87
ERROR - 2016-01-22 17:41:42 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 88
ERROR - 2016-01-22 17:41:42 --> Severity: Notice  --> Undefined variable: arreas_cf C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 89
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 17:41:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 17:41:42 --> Final output sent to browser
DEBUG - 2016-01-22 17:41:42 --> Total execution time: 0.6320
DEBUG - 2016-01-22 17:51:27 --> Config Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 17:51:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 17:51:27 --> URI Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Router Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Output Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Security Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Input Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 17:51:27 --> Language Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Language Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Config Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Loader Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Helper loaded: url_helper
DEBUG - 2016-01-22 17:51:27 --> Helper loaded: form_helper
DEBUG - 2016-01-22 17:51:27 --> Database Driver Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Session Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Helper loaded: string_helper
DEBUG - 2016-01-22 17:51:27 --> Session routines successfully run
DEBUG - 2016-01-22 17:51:27 --> Form Validation Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Pagination Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Encrypt Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Email Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Controller Class Initialized
DEBUG - 2016-01-22 17:51:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 17:51:27 --> Model Class Initialized
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 17:51:27 --> Severity: Notice  --> Undefined variable: receipt_number C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 88
ERROR - 2016-01-22 17:51:27 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 89
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 17:51:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 17:51:27 --> Final output sent to browser
DEBUG - 2016-01-22 17:51:27 --> Total execution time: 0.4183
DEBUG - 2016-01-22 18:05:04 --> Config Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:05:04 --> URI Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Router Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Output Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Security Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Input Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:05:04 --> Language Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Language Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Config Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Loader Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:05:04 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:05:04 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Session Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:05:04 --> Session routines successfully run
DEBUG - 2016-01-22 18:05:04 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Email Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Controller Class Initialized
DEBUG - 2016-01-22 18:05:04 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 18:05:05 --> Severity: Notice  --> Use of undefined constant items - assumed 'items' C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 117
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:05:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:05:05 --> Final output sent to browser
DEBUG - 2016-01-22 18:05:05 --> Total execution time: 0.3400
DEBUG - 2016-01-22 18:05:51 --> Config Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:05:51 --> URI Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Router Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Output Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Security Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Input Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:05:51 --> Language Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Language Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Config Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Loader Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:05:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:05:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Session Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:05:51 --> Session routines successfully run
DEBUG - 2016-01-22 18:05:51 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Email Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Controller Class Initialized
DEBUG - 2016-01-22 18:05:51 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:05:51 --> Model Class Initialized
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 18:05:51 --> Severity: Notice  --> Use of undefined constant items - assumed 'items' C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 119
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:05:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:05:51 --> Final output sent to browser
DEBUG - 2016-01-22 18:05:51 --> Total execution time: 0.3490
DEBUG - 2016-01-22 18:06:23 --> Config Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:06:23 --> URI Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Router Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Output Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Security Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Input Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:06:23 --> Language Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Language Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Config Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Loader Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:06:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:06:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Session Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:06:23 --> Session routines successfully run
DEBUG - 2016-01-22 18:06:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Email Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Controller Class Initialized
DEBUG - 2016-01-22 18:06:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 18:06:23 --> Severity: Notice  --> Use of undefined constant current_items - assumed 'current_items' C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 119
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:06:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:06:23 --> Final output sent to browser
DEBUG - 2016-01-22 18:06:23 --> Total execution time: 0.4309
DEBUG - 2016-01-22 18:07:27 --> Config Class Initialized
DEBUG - 2016-01-22 18:07:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:07:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:07:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:07:27 --> URI Class Initialized
DEBUG - 2016-01-22 18:07:27 --> Router Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Output Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Security Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Input Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:07:28 --> Language Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Language Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Config Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Loader Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:07:28 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:07:28 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Session Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:07:28 --> Session routines successfully run
DEBUG - 2016-01-22 18:07:28 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Email Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Controller Class Initialized
DEBUG - 2016-01-22 18:07:28 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:07:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:07:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:07:28 --> Final output sent to browser
DEBUG - 2016-01-22 18:07:28 --> Total execution time: 0.2791
DEBUG - 2016-01-22 18:09:43 --> Config Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:09:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:09:43 --> URI Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Router Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Output Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Security Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Input Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:09:43 --> Language Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Language Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Config Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Loader Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:09:43 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:09:43 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Session Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:09:43 --> Session routines successfully run
DEBUG - 2016-01-22 18:09:43 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Email Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Controller Class Initialized
DEBUG - 2016-01-22 18:09:43 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:09:43 --> Model Class Initialized
DEBUG - 2016-01-22 18:09:43 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:09:44 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:09:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:09:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:09:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:09:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:09:44 --> Final output sent to browser
DEBUG - 2016-01-22 18:09:44 --> Total execution time: 0.7300
DEBUG - 2016-01-22 18:10:06 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:10:06 --> URI Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Router Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Output Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Security Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Input Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:10:06 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Loader Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:10:06 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:10:06 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Session Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:10:06 --> Session routines successfully run
DEBUG - 2016-01-22 18:10:06 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Email Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Controller Class Initialized
DEBUG - 2016-01-22 18:10:06 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:10:06 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:10:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:10:06 --> Final output sent to browser
DEBUG - 2016-01-22 18:10:06 --> Total execution time: 0.2718
DEBUG - 2016-01-22 18:10:27 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:10:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:10:27 --> URI Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Router Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Output Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Security Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Input Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:10:27 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Loader Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:10:27 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:10:27 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Session Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:10:27 --> Session routines successfully run
DEBUG - 2016-01-22 18:10:27 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Email Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Controller Class Initialized
DEBUG - 2016-01-22 18:10:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:10:27 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:10:27 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:10:27 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:10:27 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:10:27 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:10:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:10:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:10:28 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:10:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:10:28 --> Final output sent to browser
DEBUG - 2016-01-22 18:10:28 --> Total execution time: 0.2671
DEBUG - 2016-01-22 18:10:57 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:57 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:10:57 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:10:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:10:58 --> URI Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Router Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Output Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Security Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Input Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:10:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Config Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Loader Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:10:58 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:10:58 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Session Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:10:58 --> Session routines successfully run
DEBUG - 2016-01-22 18:10:58 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Email Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Controller Class Initialized
DEBUG - 2016-01-22 18:10:58 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:10:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 18:10:58 --> Severity: Notice  --> Undefined variable: receipt_number C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 100
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:10:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:10:58 --> Final output sent to browser
DEBUG - 2016-01-22 18:10:58 --> Total execution time: 0.2719
DEBUG - 2016-01-22 18:11:30 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:11:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:11:30 --> URI Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Router Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Output Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Security Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Input Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:11:30 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Loader Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:11:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:11:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Session Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:11:30 --> Session routines successfully run
DEBUG - 2016-01-22 18:11:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Email Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Controller Class Initialized
DEBUG - 2016-01-22 18:11:30 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:11:30 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:11:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:11:30 --> Final output sent to browser
DEBUG - 2016-01-22 18:11:30 --> Total execution time: 0.2586
DEBUG - 2016-01-22 18:11:47 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:11:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:11:47 --> URI Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Router Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Output Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Security Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Input Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:11:47 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Loader Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:11:47 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:11:47 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Session Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:11:47 --> Session routines successfully run
DEBUG - 2016-01-22 18:11:47 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Email Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Controller Class Initialized
DEBUG - 2016-01-22 18:11:47 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:11:47 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-22 18:11:47 --> Severity: Notice  --> Undefined variable: receipt_number C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 100
ERROR - 2016-01-22 18:11:47 --> Severity: Notice  --> Undefined variable: receipt_number C:\xampp\htdocs\rents\application\modules\administration\views\reports\all_defaulters.php 100
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:11:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:11:47 --> Final output sent to browser
DEBUG - 2016-01-22 18:11:47 --> Total execution time: 0.3373
DEBUG - 2016-01-22 18:11:58 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:11:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:11:58 --> URI Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Router Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Output Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Security Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Input Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:11:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Config Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Loader Class Initialized
DEBUG - 2016-01-22 18:11:58 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:11:59 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:11:59 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Session Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:11:59 --> Session routines successfully run
DEBUG - 2016-01-22 18:11:59 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Email Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Controller Class Initialized
DEBUG - 2016-01-22 18:11:59 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:11:59 --> Model Class Initialized
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:11:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:11:59 --> Final output sent to browser
DEBUG - 2016-01-22 18:11:59 --> Total execution time: 0.2674
DEBUG - 2016-01-22 18:12:12 --> Config Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:12:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:12:12 --> URI Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Router Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Output Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Security Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Input Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:12:12 --> Language Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Language Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Config Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Loader Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:12:12 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:12:12 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Session Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:12:12 --> Session routines successfully run
DEBUG - 2016-01-22 18:12:12 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Email Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Controller Class Initialized
DEBUG - 2016-01-22 18:12:12 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:12:12 --> Model Class Initialized
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:12:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:12:12 --> Final output sent to browser
DEBUG - 2016-01-22 18:12:12 --> Total execution time: 0.3011
DEBUG - 2016-01-22 18:13:07 --> Config Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:13:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:13:07 --> URI Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Router Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Output Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Security Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Input Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:13:07 --> Language Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Language Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Config Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Loader Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:13:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:13:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Session Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:13:07 --> Session routines successfully run
DEBUG - 2016-01-22 18:13:07 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Email Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Controller Class Initialized
DEBUG - 2016-01-22 18:13:07 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:13:07 --> Model Class Initialized
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:13:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:13:07 --> Final output sent to browser
DEBUG - 2016-01-22 18:13:07 --> Total execution time: 0.2820
DEBUG - 2016-01-22 18:14:31 --> Config Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:14:31 --> URI Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Router Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Output Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Security Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Input Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:14:31 --> Language Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Language Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Config Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Loader Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:14:31 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:14:31 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Session Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:14:31 --> Session routines successfully run
DEBUG - 2016-01-22 18:14:31 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Email Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Controller Class Initialized
DEBUG - 2016-01-22 18:14:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:14:31 --> Model Class Initialized
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:14:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:14:31 --> Final output sent to browser
DEBUG - 2016-01-22 18:14:31 --> Total execution time: 0.2768
DEBUG - 2016-01-22 18:16:07 --> Config Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:16:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:16:07 --> URI Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Router Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Output Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Security Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Input Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:16:07 --> Language Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Language Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Config Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Loader Class Initialized
DEBUG - 2016-01-22 18:16:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:16:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:16:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Session Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:16:08 --> Session routines successfully run
DEBUG - 2016-01-22 18:16:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Email Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Controller Class Initialized
DEBUG - 2016-01-22 18:16:08 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 18:16:08 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> Image Lib Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:16:09 --> Model Class Initialized
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 42
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 42
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 42
ERROR - 2016-01-22 18:16:09 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:16:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:16:09 --> Final output sent to browser
DEBUG - 2016-01-22 18:16:09 --> Total execution time: 2.1979
DEBUG - 2016-01-22 18:16:25 --> Config Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:16:25 --> URI Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Router Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Output Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Security Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Input Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:16:25 --> Language Class Initialized
DEBUG - 2016-01-22 18:16:25 --> Language Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Config Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Loader Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:16:26 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:16:26 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Session Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:16:26 --> Session routines successfully run
DEBUG - 2016-01-22 18:16:26 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Email Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Controller Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> Image Lib Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:16:26 --> Model Class Initialized
ERROR - 2016-01-22 18:16:26 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\payments.php 14
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:16:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:16:26 --> Final output sent to browser
DEBUG - 2016-01-22 18:16:26 --> Total execution time: 0.5090
DEBUG - 2016-01-22 18:17:55 --> Config Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:17:55 --> URI Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Router Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Output Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Security Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Input Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:17:55 --> Language Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Language Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Config Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Loader Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:17:55 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:17:55 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Session Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:17:55 --> Session routines successfully run
DEBUG - 2016-01-22 18:17:55 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Email Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Controller Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> Image Lib Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:17:55 --> Model Class Initialized
ERROR - 2016-01-22 18:17:55 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:17:55 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:17:55 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:17:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:17:55 --> Final output sent to browser
DEBUG - 2016-01-22 18:17:55 --> Total execution time: 0.4511
DEBUG - 2016-01-22 18:18:04 --> Config Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:18:04 --> URI Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Router Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Output Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Security Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Input Class Initialized
DEBUG - 2016-01-22 18:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:18:04 --> Language Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Language Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Config Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Loader Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:18:05 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:18:05 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Session Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:18:05 --> Session routines successfully run
DEBUG - 2016-01-22 18:18:05 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Email Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Controller Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> Image Lib Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:18:05 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:18:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:18:05 --> Final output sent to browser
DEBUG - 2016-01-22 18:18:05 --> Total execution time: 0.4011
DEBUG - 2016-01-22 18:18:50 --> Config Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:18:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:18:50 --> URI Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Router Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Output Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Security Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Input Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:18:50 --> Language Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Language Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Config Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Loader Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:18:50 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:18:50 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Session Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:18:50 --> Session routines successfully run
DEBUG - 2016-01-22 18:18:50 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Email Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Controller Class Initialized
DEBUG - 2016-01-22 18:18:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:18:50 --> Model Class Initialized
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:18:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:18:50 --> Final output sent to browser
DEBUG - 2016-01-22 18:18:50 --> Total execution time: 0.3596
DEBUG - 2016-01-22 18:19:20 --> Config Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:19:20 --> URI Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Router Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Output Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Security Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Input Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:19:20 --> Language Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Language Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Config Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Loader Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:19:20 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:19:20 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Session Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:19:20 --> Session routines successfully run
DEBUG - 2016-01-22 18:19:20 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Email Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Controller Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> Image Lib Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:19:20 --> Model Class Initialized
ERROR - 2016-01-22 18:19:20 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:19:20 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 18:19:20 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:19:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:19:20 --> Final output sent to browser
DEBUG - 2016-01-22 18:19:20 --> Total execution time: 0.4084
DEBUG - 2016-01-22 18:19:24 --> Config Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:19:24 --> URI Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Router Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Output Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Security Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Input Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:19:24 --> Language Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Language Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Config Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Loader Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:19:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:19:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Session Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:19:24 --> Session routines successfully run
DEBUG - 2016-01-22 18:19:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Email Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Controller Class Initialized
DEBUG - 2016-01-22 18:19:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:19:24 --> Model Class Initialized
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:19:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:19:24 --> Final output sent to browser
DEBUG - 2016-01-22 18:19:24 --> Total execution time: 0.3234
DEBUG - 2016-01-22 18:20:09 --> Config Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:20:09 --> URI Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Router Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Output Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Security Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Input Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:20:09 --> Language Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Language Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Config Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Loader Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:20:09 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:20:09 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Session Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:20:09 --> Session routines successfully run
DEBUG - 2016-01-22 18:20:09 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Email Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Controller Class Initialized
DEBUG - 2016-01-22 18:20:09 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:20:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:20:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:20:09 --> Final output sent to browser
DEBUG - 2016-01-22 18:20:09 --> Total execution time: 0.2806
DEBUG - 2016-01-22 18:45:07 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:07 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:07 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:07 --> No URI present. Default controller set.
DEBUG - 2016-01-22 18:45:08 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:08 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:08 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:09 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:09 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:09 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:09 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:09 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:09 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 18:45:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:45:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:09 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:10 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:10 --> No URI present. Default controller set.
DEBUG - 2016-01-22 18:45:10 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:10 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:10 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:10 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:11 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Auth MX_Controller Initialized
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:11 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:11 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:11 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:11 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:11 --> Admin MX_Controller Initialized
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 18:45:11 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:12 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-22 18:45:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:45:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:45:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:45:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:45:12 --> Final output sent to browser
DEBUG - 2016-01-22 18:45:12 --> Total execution time: 1.5098
DEBUG - 2016-01-22 18:45:26 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:26 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:26 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:26 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:26 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:26 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:26 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:26 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:45:26 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:26 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:45:27 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:45:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:45:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:45:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:45:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:45:27 --> Final output sent to browser
DEBUG - 2016-01-22 18:45:27 --> Total execution time: 0.9252
DEBUG - 2016-01-22 18:45:45 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:45 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:45 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:45 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:46 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:46 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:46 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:46 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:46 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:45:46 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:45:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:45:46 --> Final output sent to browser
DEBUG - 2016-01-22 18:45:46 --> Total execution time: 0.2390
DEBUG - 2016-01-22 18:45:58 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:45:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:45:58 --> URI Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Router Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Output Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Security Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Input Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:45:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Language Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Config Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Loader Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:45:58 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:45:58 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Session Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:45:58 --> Session routines successfully run
DEBUG - 2016-01-22 18:45:58 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Email Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Controller Class Initialized
DEBUG - 2016-01-22 18:45:58 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:45:58 --> Model Class Initialized
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:45:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:45:58 --> Final output sent to browser
DEBUG - 2016-01-22 18:45:58 --> Total execution time: 0.3098
DEBUG - 2016-01-22 18:47:03 --> Config Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:47:03 --> URI Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Router Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Output Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Security Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Input Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:47:03 --> Language Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Language Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Config Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Loader Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:47:03 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:47:03 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Session Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:47:03 --> Session routines successfully run
DEBUG - 2016-01-22 18:47:03 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Email Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Controller Class Initialized
DEBUG - 2016-01-22 18:47:03 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:47:03 --> Model Class Initialized
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:47:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:47:03 --> Final output sent to browser
DEBUG - 2016-01-22 18:47:03 --> Total execution time: 0.2407
DEBUG - 2016-01-22 18:49:45 --> Config Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:49:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:49:45 --> URI Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Router Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Output Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Security Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Input Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:49:45 --> Language Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Language Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Config Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Loader Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:49:45 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:49:45 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Session Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:49:45 --> Session routines successfully run
DEBUG - 2016-01-22 18:49:45 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Email Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Controller Class Initialized
DEBUG - 2016-01-22 18:49:45 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:49:45 --> Model Class Initialized
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:49:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:49:45 --> Final output sent to browser
DEBUG - 2016-01-22 18:49:45 --> Total execution time: 0.2758
DEBUG - 2016-01-22 18:50:13 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:50:13 --> URI Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Router Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Output Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Security Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Input Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:50:13 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Loader Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:50:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:50:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Session Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:50:13 --> Session routines successfully run
DEBUG - 2016-01-22 18:50:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Email Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Controller Class Initialized
DEBUG - 2016-01-22 18:50:13 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:50:13 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:50:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:50:13 --> Final output sent to browser
DEBUG - 2016-01-22 18:50:13 --> Total execution time: 0.2320
DEBUG - 2016-01-22 18:50:16 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:50:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:50:16 --> URI Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Router Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Output Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Security Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Input Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:50:16 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Loader Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:50:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:50:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Session Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:50:16 --> Session routines successfully run
DEBUG - 2016-01-22 18:50:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Email Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Controller Class Initialized
DEBUG - 2016-01-22 18:50:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:50:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:50:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:50:16 --> Final output sent to browser
DEBUG - 2016-01-22 18:50:16 --> Total execution time: 0.2289
DEBUG - 2016-01-22 18:50:41 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:50:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:50:41 --> URI Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Router Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Output Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Security Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Input Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:50:41 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Language Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Config Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Loader Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:50:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:50:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Session Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:50:41 --> Session routines successfully run
DEBUG - 2016-01-22 18:50:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Email Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Controller Class Initialized
DEBUG - 2016-01-22 18:50:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:50:41 --> Model Class Initialized
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:50:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:50:41 --> Final output sent to browser
DEBUG - 2016-01-22 18:50:41 --> Total execution time: 0.2504
DEBUG - 2016-01-22 18:51:15 --> Config Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:51:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:51:15 --> URI Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Router Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Output Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Security Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Input Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:51:15 --> Language Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Language Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Config Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Loader Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:51:15 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:51:15 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Session Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:51:15 --> Session routines successfully run
DEBUG - 2016-01-22 18:51:15 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:51:15 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:51:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:51:16 --> Email Class Initialized
DEBUG - 2016-01-22 18:51:16 --> Controller Class Initialized
DEBUG - 2016-01-22 18:51:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:51:16 --> Model Class Initialized
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:51:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:51:16 --> Final output sent to browser
DEBUG - 2016-01-22 18:51:16 --> Total execution time: 0.2610
DEBUG - 2016-01-22 18:52:22 --> Config Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:52:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:52:22 --> URI Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Router Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Output Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Security Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Input Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:52:22 --> Language Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Language Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Config Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Loader Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:52:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:52:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Session Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:52:22 --> Session routines successfully run
DEBUG - 2016-01-22 18:52:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Email Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Controller Class Initialized
DEBUG - 2016-01-22 18:52:22 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:52:22 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:52:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:52:22 --> Final output sent to browser
DEBUG - 2016-01-22 18:52:22 --> Total execution time: 0.2851
DEBUG - 2016-01-22 18:52:25 --> Config Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:52:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:52:25 --> URI Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Router Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Output Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Security Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Input Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:52:25 --> Language Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Language Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Config Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Loader Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:52:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:52:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Session Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:52:25 --> Session routines successfully run
DEBUG - 2016-01-22 18:52:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Email Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Controller Class Initialized
DEBUG - 2016-01-22 18:52:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:52:25 --> Model Class Initialized
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:52:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:52:25 --> Final output sent to browser
DEBUG - 2016-01-22 18:52:25 --> Total execution time: 0.2995
DEBUG - 2016-01-22 18:53:23 --> Config Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:53:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:53:23 --> URI Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Router Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Output Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Security Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Input Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:53:23 --> Language Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Language Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Config Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Loader Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:53:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:53:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Session Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:53:23 --> Session routines successfully run
DEBUG - 2016-01-22 18:53:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Email Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Controller Class Initialized
DEBUG - 2016-01-22 18:53:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:53:23 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:53:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:53:23 --> Final output sent to browser
DEBUG - 2016-01-22 18:53:23 --> Total execution time: 0.2518
DEBUG - 2016-01-22 18:53:55 --> Config Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Hooks Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Utf8 Class Initialized
DEBUG - 2016-01-22 18:53:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 18:53:55 --> URI Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Router Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Output Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Security Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Input Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 18:53:55 --> Language Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Language Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Config Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Loader Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Helper loaded: url_helper
DEBUG - 2016-01-22 18:53:55 --> Helper loaded: form_helper
DEBUG - 2016-01-22 18:53:55 --> Database Driver Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Session Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Helper loaded: string_helper
DEBUG - 2016-01-22 18:53:55 --> Session routines successfully run
DEBUG - 2016-01-22 18:53:55 --> Form Validation Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Pagination Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Encrypt Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Email Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Controller Class Initialized
DEBUG - 2016-01-22 18:53:55 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 18:53:55 --> Model Class Initialized
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 18:53:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 18:53:55 --> Final output sent to browser
DEBUG - 2016-01-22 18:53:55 --> Total execution time: 0.3257
DEBUG - 2016-01-22 19:00:16 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:00:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:00:16 --> URI Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Router Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Output Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Security Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Input Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:00:16 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Loader Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:00:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:00:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Session Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:00:16 --> Session routines successfully run
DEBUG - 2016-01-22 19:00:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Email Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Controller Class Initialized
DEBUG - 2016-01-22 19:00:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:00:16 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:00:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:00:22 --> URI Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Router Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Output Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Security Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Input Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:00:22 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Loader Class Initialized
DEBUG - 2016-01-22 19:00:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:00:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:00:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Session Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:00:23 --> Session routines successfully run
DEBUG - 2016-01-22 19:00:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Email Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Controller Class Initialized
DEBUG - 2016-01-22 19:00:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:00:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:00:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:00:23 --> Final output sent to browser
DEBUG - 2016-01-22 19:00:23 --> Total execution time: 0.2315
DEBUG - 2016-01-22 19:00:54 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:00:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:00:54 --> URI Class Initialized
DEBUG - 2016-01-22 19:00:54 --> Router Class Initialized
DEBUG - 2016-01-22 19:00:54 --> Output Class Initialized
DEBUG - 2016-01-22 19:00:54 --> Security Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Input Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:00:55 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Language Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Config Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Loader Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:00:55 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:00:55 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Session Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:00:55 --> Session routines successfully run
DEBUG - 2016-01-22 19:00:55 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Email Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Controller Class Initialized
DEBUG - 2016-01-22 19:00:55 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:00:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:00:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:00:55 --> Final output sent to browser
DEBUG - 2016-01-22 19:00:55 --> Total execution time: 0.2725
DEBUG - 2016-01-22 19:01:20 --> Config Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:01:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:01:20 --> URI Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Router Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Output Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Security Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Input Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:01:20 --> Language Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Language Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Config Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Loader Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:01:20 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:01:20 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Session Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:01:20 --> Session routines successfully run
DEBUG - 2016-01-22 19:01:20 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Email Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Controller Class Initialized
DEBUG - 2016-01-22 19:01:20 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:01:20 --> Model Class Initialized
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:01:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:01:20 --> Final output sent to browser
DEBUG - 2016-01-22 19:01:20 --> Total execution time: 0.3062
DEBUG - 2016-01-22 19:04:13 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:04:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:04:13 --> URI Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Router Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Output Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Security Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Input Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:04:13 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Loader Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:04:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:04:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Session Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:04:13 --> Session routines successfully run
DEBUG - 2016-01-22 19:04:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:04:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:04:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:04:14 --> Email Class Initialized
DEBUG - 2016-01-22 19:04:14 --> Controller Class Initialized
DEBUG - 2016-01-22 19:04:14 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:04:14 --> Model Class Initialized
ERROR - 2016-01-22 19:04:14 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:04:14 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:04:14 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:04:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:04:14 --> Final output sent to browser
DEBUG - 2016-01-22 19:04:14 --> Total execution time: 0.7297
DEBUG - 2016-01-22 19:04:19 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:04:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:04:19 --> URI Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Router Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Output Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Security Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Input Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:04:19 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Loader Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:04:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:04:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Session Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:04:19 --> Session routines successfully run
DEBUG - 2016-01-22 19:04:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Email Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Controller Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:04:19 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:04:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:04:19 --> Final output sent to browser
DEBUG - 2016-01-22 19:04:19 --> Total execution time: 0.3331
DEBUG - 2016-01-22 19:04:39 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:04:39 --> URI Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Router Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Output Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Security Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Input Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:04:39 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Loader Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:04:39 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Session Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:04:39 --> Session routines successfully run
DEBUG - 2016-01-22 19:04:39 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Email Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Controller Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 19:04:39 --> XSS Filtering completed
DEBUG - 2016-01-22 19:04:39 --> XSS Filtering completed
DEBUG - 2016-01-22 19:04:39 --> XSS Filtering completed
DEBUG - 2016-01-22 19:04:39 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:04:39 --> URI Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Router Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Output Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Security Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Input Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:04:39 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Language Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Config Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Loader Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:04:39 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Session Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:04:39 --> Session routines successfully run
DEBUG - 2016-01-22 19:04:39 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Email Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Controller Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:04:39 --> Model Class Initialized
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:04:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:04:39 --> Final output sent to browser
DEBUG - 2016-01-22 19:04:39 --> Total execution time: 0.2739
DEBUG - 2016-01-22 19:05:03 --> Config Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:05:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:05:03 --> URI Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Router Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Output Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Security Class Initialized
DEBUG - 2016-01-22 19:05:03 --> Input Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:05:04 --> Language Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Language Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Config Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Loader Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:05:04 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:05:04 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Session Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:05:04 --> Session routines successfully run
DEBUG - 2016-01-22 19:05:04 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Email Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Controller Class Initialized
DEBUG - 2016-01-22 19:05:04 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:05:04 --> Model Class Initialized
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:05:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:05:04 --> Final output sent to browser
DEBUG - 2016-01-22 19:05:04 --> Total execution time: 0.2761
DEBUG - 2016-01-22 19:06:08 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:06:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:06:08 --> URI Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Router Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Output Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Security Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Input Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:06:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Loader Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:06:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:06:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Session Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:06:08 --> Session routines successfully run
DEBUG - 2016-01-22 19:06:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Email Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Controller Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:06:08 --> Model Class Initialized
ERROR - 2016-01-22 19:06:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:06:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:06:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:06:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:06:08 --> Final output sent to browser
DEBUG - 2016-01-22 19:06:08 --> Total execution time: 0.2978
DEBUG - 2016-01-22 19:06:11 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:06:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:06:11 --> URI Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Router Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Output Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Security Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Input Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:06:11 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Loader Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:06:11 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:06:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Session Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:06:11 --> Session routines successfully run
DEBUG - 2016-01-22 19:06:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Email Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Controller Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:06:11 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:06:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:06:11 --> Final output sent to browser
DEBUG - 2016-01-22 19:06:11 --> Total execution time: 0.2688
DEBUG - 2016-01-22 19:06:23 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:06:23 --> URI Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Router Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Output Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Security Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Input Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:06:23 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Language Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Config Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Loader Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:06:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:06:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Session Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:06:23 --> Session routines successfully run
DEBUG - 2016-01-22 19:06:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Email Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Controller Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:06:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:06:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:06:23 --> Final output sent to browser
DEBUG - 2016-01-22 19:06:23 --> Total execution time: 0.3107
DEBUG - 2016-01-22 19:07:07 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:07 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:07 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:07 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:07 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 19:07:07 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:07 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:07 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:07 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:07 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:07 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:08 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:07:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:07:08 --> Final output sent to browser
DEBUG - 2016-01-22 19:07:08 --> Total execution time: 0.2728
DEBUG - 2016-01-22 19:07:14 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:14 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:14 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:14 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:14 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:14 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:14 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:14 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:07:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:07:14 --> Final output sent to browser
DEBUG - 2016-01-22 19:07:14 --> Total execution time: 0.2736
DEBUG - 2016-01-22 19:07:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:52 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:52 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 19:07:52 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:52 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:52 --> XSS Filtering completed
DEBUG - 2016-01-22 19:07:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:52 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:52 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:07:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:07:52 --> Final output sent to browser
DEBUG - 2016-01-22 19:07:52 --> Total execution time: 0.2741
DEBUG - 2016-01-22 19:07:56 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:07:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:07:56 --> URI Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Router Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Output Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Security Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Input Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:07:56 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Language Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Config Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Loader Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:07:56 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:07:56 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Session Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:07:56 --> Session routines successfully run
DEBUG - 2016-01-22 19:07:56 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Email Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Controller Class Initialized
DEBUG - 2016-01-22 19:07:56 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:07:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:07:57 --> Model Class Initialized
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:07:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:07:57 --> Final output sent to browser
DEBUG - 2016-01-22 19:07:57 --> Total execution time: 0.2315
DEBUG - 2016-01-22 19:11:14 --> Config Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:11:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:11:14 --> URI Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Router Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Output Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Security Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Input Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:11:14 --> Language Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Language Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Config Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Loader Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:11:14 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:11:14 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Session Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:11:14 --> Session routines successfully run
DEBUG - 2016-01-22 19:11:14 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Email Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Controller Class Initialized
DEBUG - 2016-01-22 19:11:14 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:11:14 --> Model Class Initialized
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:11:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:11:14 --> Final output sent to browser
DEBUG - 2016-01-22 19:11:14 --> Total execution time: 0.4859
DEBUG - 2016-01-22 19:17:33 --> Config Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:17:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:17:33 --> URI Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Router Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Output Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Security Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Input Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:17:33 --> Language Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Language Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Config Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Loader Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:17:33 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:17:33 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Session Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:17:33 --> Session routines successfully run
DEBUG - 2016-01-22 19:17:33 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Email Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Controller Class Initialized
DEBUG - 2016-01-22 19:17:33 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:17:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:17:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:17:33 --> Final output sent to browser
DEBUG - 2016-01-22 19:17:33 --> Total execution time: 0.2503
DEBUG - 2016-01-22 19:32:29 --> Config Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:32:29 --> URI Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Router Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Output Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Security Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Input Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:32:29 --> Language Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Language Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Config Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Loader Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:32:29 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:32:29 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Session Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:32:29 --> Session routines successfully run
DEBUG - 2016-01-22 19:32:29 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Email Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Controller Class Initialized
DEBUG - 2016-01-22 19:32:29 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:32:29 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:07 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:07 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:07 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:07 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:07 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:07 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:16 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:16 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:16 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:16 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:16 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:27 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:27 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:27 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:27 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:27 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:27 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:33:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:33:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:33:27 --> Final output sent to browser
DEBUG - 2016-01-22 19:33:27 --> Total execution time: 0.3354
DEBUG - 2016-01-22 19:33:30 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:30 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:30 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:30 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:30 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:33:30 --> Model Class Initialized
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 871
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 871
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 872
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 872
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 873
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 873
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 874
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 874
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 875
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 875
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 876
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 876
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 877
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 877
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 878
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 878
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 879
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 879
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 881
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 881
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 882
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 882
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 883
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 883
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 884
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 884
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 885
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 885
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 886
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 886
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 887
ERROR - 2016-01-22 19:33:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 887
DEBUG - 2016-01-22 19:33:31 --> DB Transaction Failure
ERROR - 2016-01-22 19:33:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-22 19:33:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-22 19:33:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\core\Common.php 441
DEBUG - 2016-01-22 19:33:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:52 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:52 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:52 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:33:52 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:33:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:33:52 --> Final output sent to browser
DEBUG - 2016-01-22 19:33:52 --> Total execution time: 0.2460
DEBUG - 2016-01-22 19:33:54 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:33:54 --> URI Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Router Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Output Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Security Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Input Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:33:54 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Language Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Config Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Loader Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:33:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:33:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:33:54 --> Session Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:33:55 --> Session routines successfully run
DEBUG - 2016-01-22 19:33:55 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Email Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Controller Class Initialized
DEBUG - 2016-01-22 19:33:55 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
DEBUG - 2016-01-22 19:33:55 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:33:55 --> Model Class Initialized
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 871
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 871
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 872
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 872
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 873
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 873
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 874
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 874
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 875
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 875
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 876
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 876
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 877
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 877
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 878
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 878
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 879
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 879
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 881
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 881
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 882
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 882
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 883
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 883
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 884
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 884
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 885
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 885
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 886
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 886
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Undefined variable: leases_row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 887
ERROR - 2016-01-22 19:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 887
DEBUG - 2016-01-22 19:33:55 --> DB Transaction Failure
ERROR - 2016-01-22 19:33:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3
DEBUG - 2016-01-22 19:33:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-22 19:33:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\core\Common.php 441
DEBUG - 2016-01-22 19:34:09 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:34:09 --> URI Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Router Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Output Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Security Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Input Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:34:09 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Loader Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:34:09 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:34:09 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Session Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:34:09 --> Session routines successfully run
DEBUG - 2016-01-22 19:34:09 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Email Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Controller Class Initialized
DEBUG - 2016-01-22 19:34:09 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:09 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:34:09 --> Model Class Initialized
ERROR - 2016-01-22 19:34:10 --> Severity: Notice  --> Undefined variable: total_amount_paid C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 966
ERROR - 2016-01-22 19:34:10 --> Severity: Notice  --> Undefined variable: total_amount_paid C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 966
ERROR - 2016-01-22 19:34:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 180
ERROR - 2016-01-22 19:34:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 181
DEBUG - 2016-01-22 19:34:10 --> Final output sent to browser
DEBUG - 2016-01-22 19:34:10 --> Total execution time: 0.2166
DEBUG - 2016-01-22 19:34:37 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:34:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:34:37 --> URI Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Router Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Output Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Security Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Input Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:34:37 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Loader Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:34:37 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:34:37 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Session Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:34:37 --> Session routines successfully run
DEBUG - 2016-01-22 19:34:37 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Email Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Controller Class Initialized
DEBUG - 2016-01-22 19:34:37 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:34:37 --> Model Class Initialized
ERROR - 2016-01-22 19:34:37 --> Severity: Notice  --> Undefined variable: total_paid_amount C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 945
ERROR - 2016-01-22 19:34:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 180
ERROR - 2016-01-22 19:34:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 181
DEBUG - 2016-01-22 19:34:37 --> Final output sent to browser
DEBUG - 2016-01-22 19:34:37 --> Total execution time: 0.2142
DEBUG - 2016-01-22 19:34:56 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:34:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:34:56 --> URI Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Router Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Output Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Security Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Input Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:34:56 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Language Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Config Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Loader Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:34:56 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:34:56 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Session Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:34:56 --> Session routines successfully run
DEBUG - 2016-01-22 19:34:56 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Email Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Controller Class Initialized
DEBUG - 2016-01-22 19:34:56 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
DEBUG - 2016-01-22 19:34:56 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:34:56 --> Model Class Initialized
ERROR - 2016-01-22 19:34:56 --> Severity: Notice  --> Undefined variable: total_paid_amount C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 945
ERROR - 2016-01-22 19:34:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 180
ERROR - 2016-01-22 19:34:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 181
DEBUG - 2016-01-22 19:34:56 --> Final output sent to browser
DEBUG - 2016-01-22 19:34:56 --> Total execution time: 0.2233
DEBUG - 2016-01-22 19:35:41 --> Config Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:35:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:35:41 --> URI Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Router Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Output Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Security Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Input Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:35:41 --> Language Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Language Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Config Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Loader Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:35:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:35:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Session Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:35:41 --> Session routines successfully run
DEBUG - 2016-01-22 19:35:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Email Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Controller Class Initialized
DEBUG - 2016-01-22 19:35:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
DEBUG - 2016-01-22 19:35:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:35:41 --> Model Class Initialized
ERROR - 2016-01-22 19:35:41 --> Severity: Notice  --> Undefined variable: total_paid_amount C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 945
ERROR - 2016-01-22 19:35:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 180
ERROR - 2016-01-22 19:35:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 181
DEBUG - 2016-01-22 19:35:42 --> Final output sent to browser
DEBUG - 2016-01-22 19:35:42 --> Total execution time: 0.2129
DEBUG - 2016-01-22 19:36:17 --> Config Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:36:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:36:17 --> URI Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Router Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Output Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Security Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Input Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:36:17 --> Language Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Language Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Config Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Loader Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:36:17 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:36:17 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Session Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:36:17 --> Session routines successfully run
DEBUG - 2016-01-22 19:36:17 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Email Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Controller Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:36:17 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:17 --> Final output sent to browser
DEBUG - 2016-01-22 19:36:17 --> Total execution time: 0.2055
DEBUG - 2016-01-22 19:36:24 --> Config Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:36:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:36:24 --> URI Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Router Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Output Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Security Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Input Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:36:24 --> Language Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Language Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Config Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Loader Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:36:24 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:36:24 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Session Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:36:24 --> Session routines successfully run
DEBUG - 2016-01-22 19:36:24 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Email Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Controller Class Initialized
DEBUG - 2016-01-22 19:36:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:36:24 --> Model Class Initialized
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:36:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:36:24 --> Final output sent to browser
DEBUG - 2016-01-22 19:36:24 --> Total execution time: 0.2789
DEBUG - 2016-01-22 19:38:18 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:38:18 --> URI Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Router Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Output Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Security Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Input Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:38:18 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Loader Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:38:18 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:38:18 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Session Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:38:18 --> Session routines successfully run
DEBUG - 2016-01-22 19:38:18 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Email Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Controller Class Initialized
DEBUG - 2016-01-22 19:38:18 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:38:18 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:38:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:38:18 --> Final output sent to browser
DEBUG - 2016-01-22 19:38:18 --> Total execution time: 0.2479
DEBUG - 2016-01-22 19:38:27 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:38:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:38:27 --> URI Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Router Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Output Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Security Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Input Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:38:27 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Loader Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:38:27 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:38:27 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Session Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:38:27 --> Session routines successfully run
DEBUG - 2016-01-22 19:38:27 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Email Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Controller Class Initialized
DEBUG - 2016-01-22 19:38:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:38:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:38:27 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:38:28 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:38:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:38:28 --> Final output sent to browser
DEBUG - 2016-01-22 19:38:28 --> Total execution time: 0.2422
DEBUG - 2016-01-22 19:38:30 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:38:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:38:30 --> URI Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Router Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Output Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Security Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Input Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:38:30 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Language Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Config Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Loader Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:38:30 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:38:30 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Session Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:38:30 --> Session routines successfully run
DEBUG - 2016-01-22 19:38:30 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Email Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Controller Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:38:30 --> Model Class Initialized
DEBUG - 2016-01-22 19:38:30 --> Final output sent to browser
DEBUG - 2016-01-22 19:38:30 --> Total execution time: 0.4513
DEBUG - 2016-01-22 19:39:23 --> Config Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:39:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:39:23 --> URI Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Router Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Output Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Security Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Input Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:39:23 --> Language Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Language Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Config Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Loader Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:39:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:39:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Session Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:39:23 --> Session routines successfully run
DEBUG - 2016-01-22 19:39:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Email Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Controller Class Initialized
DEBUG - 2016-01-22 19:39:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:39:23 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:39:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:39:23 --> Final output sent to browser
DEBUG - 2016-01-22 19:39:23 --> Total execution time: 0.2478
DEBUG - 2016-01-22 19:39:25 --> Config Class Initialized
DEBUG - 2016-01-22 19:39:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:39:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:39:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:39:25 --> URI Class Initialized
DEBUG - 2016-01-22 19:39:25 --> Router Class Initialized
DEBUG - 2016-01-22 19:39:25 --> Output Class Initialized
DEBUG - 2016-01-22 19:39:25 --> Security Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Input Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:39:26 --> Language Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Language Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Config Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Loader Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:39:26 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:39:26 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Session Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:39:26 --> Session routines successfully run
DEBUG - 2016-01-22 19:39:26 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Email Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Controller Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:39:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:39:26 --> Final output sent to browser
DEBUG - 2016-01-22 19:39:26 --> Total execution time: 1.0463
DEBUG - 2016-01-22 19:41:25 --> Config Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:41:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:41:25 --> URI Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Router Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Output Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Security Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Input Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:41:25 --> Language Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Language Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Config Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Loader Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:41:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:41:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Session Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:41:25 --> Session routines successfully run
DEBUG - 2016-01-22 19:41:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Email Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Controller Class Initialized
DEBUG - 2016-01-22 19:41:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:41:25 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:41:26 --> Model Class Initialized
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:41:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:41:26 --> Final output sent to browser
DEBUG - 2016-01-22 19:41:26 --> Total execution time: 0.3146
DEBUG - 2016-01-22 19:47:36 --> Config Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:47:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:47:36 --> URI Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Router Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Output Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Security Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Input Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:47:36 --> Language Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Language Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Config Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Loader Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:47:36 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:47:36 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Session Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:47:36 --> Session routines successfully run
DEBUG - 2016-01-22 19:47:36 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Email Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Controller Class Initialized
DEBUG - 2016-01-22 19:47:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:47:36 --> Model Class Initialized
DEBUG - 2016-01-22 19:47:36 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 19:47:37 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 19:47:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:47:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:47:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:47:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:47:37 --> Final output sent to browser
DEBUG - 2016-01-22 19:47:37 --> Total execution time: 0.2953
DEBUG - 2016-01-22 19:48:08 --> Config Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:48:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:48:08 --> URI Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Router Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Output Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Security Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Input Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:48:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Language Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Config Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Loader Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:48:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:48:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Session Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:48:08 --> Session routines successfully run
DEBUG - 2016-01-22 19:48:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Email Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Controller Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:48:08 --> Model Class Initialized
DEBUG - 2016-01-22 19:48:08 --> Final output sent to browser
DEBUG - 2016-01-22 19:48:08 --> Total execution time: 0.2319
DEBUG - 2016-01-22 19:58:33 --> Config Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Hooks Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Utf8 Class Initialized
DEBUG - 2016-01-22 19:58:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 19:58:33 --> URI Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Router Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Output Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Security Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Input Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 19:58:33 --> Language Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Language Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Config Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Loader Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Helper loaded: url_helper
DEBUG - 2016-01-22 19:58:33 --> Helper loaded: form_helper
DEBUG - 2016-01-22 19:58:33 --> Database Driver Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Session Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Helper loaded: string_helper
DEBUG - 2016-01-22 19:58:33 --> Session routines successfully run
DEBUG - 2016-01-22 19:58:33 --> Form Validation Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Pagination Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Encrypt Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Email Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Controller Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> Image Lib Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 19:58:33 --> Model Class Initialized
ERROR - 2016-01-22 19:58:33 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:58:33 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 19:58:33 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 19:58:33 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 19:58:33 --> Final output sent to browser
DEBUG - 2016-01-22 19:58:33 --> Total execution time: 0.5214
DEBUG - 2016-01-22 20:36:06 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:36:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:36:06 --> URI Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Router Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Output Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Security Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Input Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:36:06 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Loader Class Initialized
DEBUG - 2016-01-22 20:36:06 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:36:07 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:36:07 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Session Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:36:07 --> Session routines successfully run
DEBUG - 2016-01-22 20:36:07 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Email Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Controller Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> Image Lib Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:36:07 --> Model Class Initialized
ERROR - 2016-01-22 20:36:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 20:36:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 20:36:08 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:36:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:36:08 --> Final output sent to browser
DEBUG - 2016-01-22 20:36:08 --> Total execution time: 2.3415
DEBUG - 2016-01-22 20:36:25 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:36:25 --> URI Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Router Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Output Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Security Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Input Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:36:25 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Loader Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:36:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:36:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Session Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:36:25 --> Session routines successfully run
DEBUG - 2016-01-22 20:36:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Email Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Controller Class Initialized
DEBUG - 2016-01-22 20:36:25 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 20:36:25 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:36:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:36:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:36:26 --> Final output sent to browser
DEBUG - 2016-01-22 20:36:26 --> Total execution time: 0.6573
DEBUG - 2016-01-22 20:36:52 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:36:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:36:52 --> URI Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Router Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Output Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Security Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Input Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:36:52 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Language Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Config Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Loader Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:36:52 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:36:52 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Session Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:36:52 --> Session routines successfully run
DEBUG - 2016-01-22 20:36:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Email Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Controller Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> Image Lib Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:36:52 --> Model Class Initialized
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:36:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:36:52 --> Final output sent to browser
DEBUG - 2016-01-22 20:36:52 --> Total execution time: 0.4691
DEBUG - 2016-01-22 20:37:23 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:37:23 --> URI Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Router Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Output Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Security Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Input Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:37:23 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Loader Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:37:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Session Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:37:23 --> Session routines successfully run
DEBUG - 2016-01-22 20:37:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Email Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Controller Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Image Lib Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-22 20:37:23 --> XSS Filtering completed
DEBUG - 2016-01-22 20:37:23 --> XSS Filtering completed
DEBUG - 2016-01-22 20:37:23 --> XSS Filtering completed
DEBUG - 2016-01-22 20:37:23 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:37:23 --> URI Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Router Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Output Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Security Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Input Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:37:23 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Loader Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:37:23 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Session Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:37:23 --> Session routines successfully run
DEBUG - 2016-01-22 20:37:23 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Email Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Controller Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:37:23 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:23 --> Image Lib Class Initialized
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 20:37:24 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 20:37:24 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 20:37:24 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:37:24 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:37:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:37:24 --> Final output sent to browser
DEBUG - 2016-01-22 20:37:24 --> Total execution time: 0.2734
DEBUG - 2016-01-22 20:37:26 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:37:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:37:26 --> URI Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Router Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Output Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Security Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Input Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:37:26 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Language Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Config Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Loader Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:37:26 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:37:26 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Session Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:37:26 --> Session routines successfully run
DEBUG - 2016-01-22 20:37:26 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Email Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Controller Class Initialized
DEBUG - 2016-01-22 20:37:26 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:26 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:37:26 --> Model Class Initialized
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:37:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:37:27 --> Final output sent to browser
DEBUG - 2016-01-22 20:37:27 --> Total execution time: 0.3112
DEBUG - 2016-01-22 20:45:44 --> Config Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Hooks Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Utf8 Class Initialized
DEBUG - 2016-01-22 20:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 20:45:44 --> URI Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Router Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Output Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Security Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Input Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 20:45:44 --> Language Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Language Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Config Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Loader Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Helper loaded: url_helper
DEBUG - 2016-01-22 20:45:44 --> Helper loaded: form_helper
DEBUG - 2016-01-22 20:45:44 --> Database Driver Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Session Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Helper loaded: string_helper
DEBUG - 2016-01-22 20:45:44 --> Session routines successfully run
DEBUG - 2016-01-22 20:45:44 --> Form Validation Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Pagination Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Encrypt Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Email Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Controller Class Initialized
DEBUG - 2016-01-22 20:45:44 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 20:45:44 --> Model Class Initialized
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 20:45:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 20:45:44 --> Final output sent to browser
DEBUG - 2016-01-22 20:45:44 --> Total execution time: 0.4358
DEBUG - 2016-01-22 21:03:13 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:03:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:03:13 --> URI Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Router Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Output Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Security Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Input Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:03:13 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Loader Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:03:13 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:03:13 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Session Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:03:13 --> Session routines successfully run
DEBUG - 2016-01-22 21:03:13 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Email Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Controller Class Initialized
DEBUG - 2016-01-22 21:03:13 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:03:13 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:03:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:03:13 --> Final output sent to browser
DEBUG - 2016-01-22 21:03:13 --> Total execution time: 0.5160
DEBUG - 2016-01-22 21:03:35 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:35 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:03:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:03:36 --> URI Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Router Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Output Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Security Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Input Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:03:36 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Loader Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:03:36 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:03:36 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Session Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:03:36 --> Session routines successfully run
DEBUG - 2016-01-22 21:03:36 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Email Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Controller Class Initialized
DEBUG - 2016-01-22 21:03:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:03:36 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:03:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:03:36 --> Final output sent to browser
DEBUG - 2016-01-22 21:03:36 --> Total execution time: 0.3781
DEBUG - 2016-01-22 21:03:40 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:40 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:03:40 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:03:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:03:40 --> URI Class Initialized
DEBUG - 2016-01-22 21:03:40 --> Router Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Output Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Security Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Input Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:03:41 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Language Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Config Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Loader Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:03:41 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:03:41 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Session Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:03:41 --> Session routines successfully run
DEBUG - 2016-01-22 21:03:41 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Email Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Controller Class Initialized
DEBUG - 2016-01-22 21:03:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
DEBUG - 2016-01-22 21:03:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:03:41 --> Model Class Initialized
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 567
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 568
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 570
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 571
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 572
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 573
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 574
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 575
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 576
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 577
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 578
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Undefined variable: row C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php 579
ERROR - 2016-01-22 21:03:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 180
ERROR - 2016-01-22 21:03:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\application\libraries\Excel.php 181
DEBUG - 2016-01-22 21:03:41 --> Final output sent to browser
DEBUG - 2016-01-22 21:03:41 --> Total execution time: 1.2175
DEBUG - 2016-01-22 21:04:45 --> Config Class Initialized
DEBUG - 2016-01-22 21:04:45 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:04:45 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:04:45 --> URI Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Router Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Output Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Security Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Input Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:04:46 --> Language Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Language Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Config Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Loader Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:04:46 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:04:46 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Session Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:04:46 --> Session routines successfully run
DEBUG - 2016-01-22 21:04:46 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Email Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Controller Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:04:46 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:46 --> Final output sent to browser
DEBUG - 2016-01-22 21:04:46 --> Total execution time: 0.2711
DEBUG - 2016-01-22 21:04:53 --> Config Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:04:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:04:54 --> URI Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Router Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Output Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Security Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Input Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:04:54 --> Language Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Language Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Config Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Loader Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:04:54 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:04:54 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Session Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:04:54 --> Session routines successfully run
DEBUG - 2016-01-22 21:04:54 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Email Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Controller Class Initialized
DEBUG - 2016-01-22 21:04:54 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:04:54 --> Model Class Initialized
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:04:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:04:54 --> Final output sent to browser
DEBUG - 2016-01-22 21:04:54 --> Total execution time: 1.3051
DEBUG - 2016-01-22 21:07:19 --> Config Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:07:19 --> URI Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Router Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Output Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Security Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Input Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:07:19 --> Language Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Language Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Config Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Loader Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:07:19 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:07:19 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Session Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:07:19 --> Session routines successfully run
DEBUG - 2016-01-22 21:07:19 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Email Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Controller Class Initialized
DEBUG - 2016-01-22 21:07:19 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:07:19 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:07:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:07:19 --> Final output sent to browser
DEBUG - 2016-01-22 21:07:19 --> Total execution time: 0.2749
DEBUG - 2016-01-22 21:07:21 --> Config Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:07:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:07:22 --> URI Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Router Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Output Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Security Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Input Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:07:22 --> Language Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Language Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Config Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Loader Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:07:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:07:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Session Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:07:22 --> Session routines successfully run
DEBUG - 2016-01-22 21:07:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Email Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Controller Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Reports MX_Controller Initialized
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:07:22 --> Model Class Initialized
DEBUG - 2016-01-22 21:07:22 --> Final output sent to browser
DEBUG - 2016-01-22 21:07:22 --> Total execution time: 0.7599
DEBUG - 2016-01-22 21:38:11 --> Config Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:38:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:38:11 --> URI Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Router Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Output Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Security Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Input Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:38:11 --> Language Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Language Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Config Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Loader Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:38:11 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:38:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Session Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:38:11 --> Session routines successfully run
DEBUG - 2016-01-22 21:38:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Email Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Controller Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> Image Lib Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:38:11 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:12 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 21:38:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:38:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:38:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:38:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:38:12 --> Final output sent to browser
DEBUG - 2016-01-22 21:38:12 --> Total execution time: 0.5727
DEBUG - 2016-01-22 21:38:51 --> Config Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:38:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:38:51 --> URI Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Router Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Output Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Security Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Input Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:38:51 --> Language Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Language Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Config Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Loader Class Initialized
DEBUG - 2016-01-22 21:38:51 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:38:51 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:38:51 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Session Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:38:52 --> Session routines successfully run
DEBUG - 2016-01-22 21:38:52 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Email Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Controller Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> Image Lib Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:38:52 --> Model Class Initialized
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:38:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:38:52 --> Final output sent to browser
DEBUG - 2016-01-22 21:38:52 --> Total execution time: 1.3256
DEBUG - 2016-01-22 21:39:25 --> Config Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:39:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:39:25 --> URI Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Router Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Output Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Security Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Input Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:39:25 --> Language Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Language Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Config Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Loader Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:39:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:39:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Session Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:39:25 --> Session routines successfully run
DEBUG - 2016-01-22 21:39:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Email Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Controller Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> Image Lib Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:39:25 --> Model Class Initialized
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:39:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:39:25 --> Final output sent to browser
DEBUG - 2016-01-22 21:39:25 --> Total execution time: 0.5865
DEBUG - 2016-01-22 21:40:39 --> Config Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Hooks Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Utf8 Class Initialized
DEBUG - 2016-01-22 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 21:40:39 --> URI Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Router Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Output Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Security Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Input Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 21:40:39 --> Language Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Language Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Config Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Loader Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Helper loaded: url_helper
DEBUG - 2016-01-22 21:40:39 --> Helper loaded: form_helper
DEBUG - 2016-01-22 21:40:39 --> Database Driver Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Session Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Helper loaded: string_helper
DEBUG - 2016-01-22 21:40:39 --> Session routines successfully run
DEBUG - 2016-01-22 21:40:39 --> Form Validation Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Pagination Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Encrypt Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Email Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Controller Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> Image Lib Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 21:40:39 --> Model Class Initialized
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 21:40:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 21:40:39 --> Final output sent to browser
DEBUG - 2016-01-22 21:40:39 --> Total execution time: 0.2734
DEBUG - 2016-01-22 22:00:02 --> Config Class Initialized
DEBUG - 2016-01-22 22:00:02 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:00:02 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:00:02 --> URI Class Initialized
DEBUG - 2016-01-22 22:00:02 --> Router Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Output Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Security Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Input Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:00:03 --> Language Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Language Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Config Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Loader Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:00:03 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:00:03 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Session Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:00:03 --> Session routines successfully run
DEBUG - 2016-01-22 22:00:03 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Email Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Controller Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:00:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:00:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Config Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:01:15 --> URI Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Router Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Output Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Security Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Input Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:01:15 --> Language Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Language Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Config Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Loader Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:01:15 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:01:15 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Session Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:01:15 --> Session routines successfully run
DEBUG - 2016-01-22 22:01:15 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:01:15 --> Email Class Initialized
DEBUG - 2016-01-22 22:01:16 --> Controller Class Initialized
DEBUG - 2016-01-22 22:01:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:01:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:01:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Config Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:02:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:02:03 --> URI Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Router Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Output Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Security Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Input Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:02:03 --> Language Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Language Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Config Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Loader Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:02:03 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:02:03 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Session Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:02:03 --> Session routines successfully run
DEBUG - 2016-01-22 22:02:03 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Email Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Controller Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:02:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:02:03 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Config Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:03:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:03:16 --> URI Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Router Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Output Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Security Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Input Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:03:16 --> Language Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Language Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Config Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Loader Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:03:16 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:03:16 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Session Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:03:16 --> Session routines successfully run
DEBUG - 2016-01-22 22:03:16 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Email Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Controller Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:03:16 --> Model Class Initialized
ERROR - 2016-01-22 22:03:16 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 22:03:16 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-01-22 22:03:16 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\lease_details.php 15
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:03:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:03:16 --> Final output sent to browser
DEBUG - 2016-01-22 22:03:16 --> Total execution time: 0.3750
DEBUG - 2016-01-22 22:03:25 --> Config Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:03:25 --> URI Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Router Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Output Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Security Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Input Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:03:25 --> Language Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Language Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Config Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Loader Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:03:25 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:03:25 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Session Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:03:25 --> Session routines successfully run
DEBUG - 2016-01-22 22:03:25 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Email Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Controller Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:03:25 --> Model Class Initialized
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:03:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:03:25 --> Final output sent to browser
DEBUG - 2016-01-22 22:03:25 --> Total execution time: 0.2608
DEBUG - 2016-01-22 22:08:21 --> Config Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:08:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:08:21 --> URI Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Router Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Output Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Security Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Input Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:08:21 --> Language Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Language Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Config Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Loader Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:08:21 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:08:21 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Session Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:08:21 --> Session routines successfully run
DEBUG - 2016-01-22 22:08:21 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Email Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Controller Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:08:21 --> Model Class Initialized
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:08:21 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:08:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:08:22 --> Final output sent to browser
DEBUG - 2016-01-22 22:08:22 --> Total execution time: 0.3074
DEBUG - 2016-01-22 22:09:11 --> Config Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:09:11 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:09:11 --> URI Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Router Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Output Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Security Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Input Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:09:11 --> Language Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Language Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Config Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Loader Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:09:11 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:09:11 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Session Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:09:11 --> Session routines successfully run
DEBUG - 2016-01-22 22:09:11 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Email Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Controller Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:09:11 --> Model Class Initialized
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:09:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:09:11 --> Final output sent to browser
DEBUG - 2016-01-22 22:09:11 --> Total execution time: 0.3672
DEBUG - 2016-01-22 22:10:56 --> Config Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:10:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:10:56 --> URI Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Router Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Output Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Security Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Input Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:10:56 --> Language Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Language Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Config Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Loader Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:10:56 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:10:56 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Session Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:10:56 --> Session routines successfully run
DEBUG - 2016-01-22 22:10:56 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Email Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Controller Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:56 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:10:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:10:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:10:57 --> Final output sent to browser
DEBUG - 2016-01-22 22:10:57 --> Total execution time: 0.3236
DEBUG - 2016-01-22 22:11:56 --> Config Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:11:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:11:56 --> URI Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Router Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Output Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Security Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Input Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:11:56 --> Language Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Language Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Config Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Loader Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:11:56 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:11:56 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Session Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:11:56 --> Session routines successfully run
DEBUG - 2016-01-22 22:11:56 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Email Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Controller Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:56 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:11:56 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:11:57 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:11:57 --> Model Class Initialized
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:11:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:11:57 --> Final output sent to browser
DEBUG - 2016-01-22 22:11:57 --> Total execution time: 0.3058
DEBUG - 2016-01-22 22:14:08 --> Config Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:14:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:14:08 --> URI Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Router Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Output Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Security Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Input Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:14:08 --> Language Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Language Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Config Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Loader Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:14:08 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:14:08 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Session Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:14:08 --> Session routines successfully run
DEBUG - 2016-01-22 22:14:08 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Email Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Controller Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:14:08 --> Model Class Initialized
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:14:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:14:08 --> Final output sent to browser
DEBUG - 2016-01-22 22:14:08 --> Total execution time: 0.3397
DEBUG - 2016-01-22 22:16:37 --> Config Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:16:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:16:37 --> URI Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Router Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Output Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Security Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Input Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:16:37 --> Language Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Language Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Config Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Loader Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:16:37 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:16:37 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Session Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:16:37 --> Session routines successfully run
DEBUG - 2016-01-22 22:16:37 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Email Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Controller Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:16:37 --> Model Class Initialized
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:16:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:16:37 --> Final output sent to browser
DEBUG - 2016-01-22 22:16:37 --> Total execution time: 0.2691
DEBUG - 2016-01-22 22:17:20 --> Config Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:17:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:17:20 --> URI Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Router Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Output Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Security Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Input Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:17:20 --> Language Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Language Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Config Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Loader Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:17:20 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:17:20 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Session Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:17:20 --> Session routines successfully run
DEBUG - 2016-01-22 22:17:20 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Email Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Controller Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:17:20 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:17:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:17:20 --> Final output sent to browser
DEBUG - 2016-01-22 22:17:20 --> Total execution time: 0.3030
DEBUG - 2016-01-22 22:17:47 --> Config Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:17:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:17:47 --> URI Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Router Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Output Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Security Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Input Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:17:47 --> Language Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Language Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Config Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Loader Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:17:47 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:17:47 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Session Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:17:47 --> Session routines successfully run
DEBUG - 2016-01-22 22:17:47 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Email Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Controller Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:17:47 --> Model Class Initialized
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:17:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:17:47 --> Final output sent to browser
DEBUG - 2016-01-22 22:17:47 --> Total execution time: 0.2824
DEBUG - 2016-01-22 22:44:22 --> Config Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:44:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:44:22 --> URI Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Router Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Output Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Security Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Input Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:44:22 --> Language Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Language Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Config Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Loader Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:44:22 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:44:22 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Session Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:44:22 --> Session routines successfully run
DEBUG - 2016-01-22 22:44:22 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Email Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Controller Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:44:22 --> Model Class Initialized
DEBUG - 2016-01-22 22:44:23 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:44:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:44:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:44:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:44:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:44:23 --> Final output sent to browser
DEBUG - 2016-01-22 22:44:23 --> Total execution time: 0.4677
DEBUG - 2016-01-22 22:45:37 --> Config Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Hooks Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Utf8 Class Initialized
DEBUG - 2016-01-22 22:45:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-22 22:45:37 --> URI Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Router Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Output Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Security Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Input Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-22 22:45:37 --> Language Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Language Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Config Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Loader Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Helper loaded: url_helper
DEBUG - 2016-01-22 22:45:37 --> Helper loaded: form_helper
DEBUG - 2016-01-22 22:45:37 --> Database Driver Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Session Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Helper loaded: string_helper
DEBUG - 2016-01-22 22:45:37 --> Session routines successfully run
DEBUG - 2016-01-22 22:45:37 --> Form Validation Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Pagination Class Initialized
DEBUG - 2016-01-22 22:45:37 --> Encrypt Class Initialized
DEBUG - 2016-01-22 22:45:38 --> Email Class Initialized
DEBUG - 2016-01-22 22:45:38 --> Controller Class Initialized
DEBUG - 2016-01-22 22:45:38 --> Accounts MX_Controller Initialized
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> Image Lib Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-22 22:45:38 --> Model Class Initialized
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-22 22:45:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-22 22:45:38 --> Final output sent to browser
DEBUG - 2016-01-22 22:45:38 --> Total execution time: 0.2787
