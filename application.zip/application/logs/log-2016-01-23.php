<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-23 08:19:18 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:18 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:19 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:19 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:20 --> Router Class Initialized
DEBUG - 2016-01-23 08:19:21 --> No URI present. Default controller set.
DEBUG - 2016-01-23 08:19:21 --> Output Class Initialized
DEBUG - 2016-01-23 08:19:22 --> Security Class Initialized
DEBUG - 2016-01-23 08:19:22 --> Input Class Initialized
DEBUG - 2016-01-23 08:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:19:22 --> Language Class Initialized
DEBUG - 2016-01-23 08:19:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:19:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:24 --> Loader Class Initialized
DEBUG - 2016-01-23 08:19:25 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:19:25 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:19:27 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:19:32 --> Session Class Initialized
DEBUG - 2016-01-23 08:19:32 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:19:32 --> A session cookie was not found.
DEBUG - 2016-01-23 08:19:33 --> Session routines successfully run
DEBUG - 2016-01-23 08:19:33 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:19:34 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:19:34 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:19:35 --> Email Class Initialized
DEBUG - 2016-01-23 08:19:35 --> Controller Class Initialized
DEBUG - 2016-01-23 08:19:35 --> Auth MX_Controller Initialized
DEBUG - 2016-01-23 08:19:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 08:19:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:19:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:36 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:36 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:36 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Router Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Output Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Security Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Input Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:19:37 --> Language Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Language Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Loader Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:19:37 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:19:37 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Session Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:19:37 --> Session routines successfully run
DEBUG - 2016-01-23 08:19:37 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Email Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Controller Class Initialized
DEBUG - 2016-01-23 08:19:37 --> Auth MX_Controller Initialized
DEBUG - 2016-01-23 08:19:37 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 08:19:37 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:19:37 --> Model Class Initialized
DEBUG - 2016-01-23 08:19:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:19:41 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-23 08:19:41 --> Final output sent to browser
DEBUG - 2016-01-23 08:19:41 --> Total execution time: 4.3115
DEBUG - 2016-01-23 08:19:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:58 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:58 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Router Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Router Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:58 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Router Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:19:58 --> URI Class Initialized
DEBUG - 2016-01-23 08:19:58 --> Router Class Initialized
ERROR - 2016-01-23 08:19:58 --> 404 Page Not Found --> 
ERROR - 2016-01-23 08:19:58 --> 404 Page Not Found --> 
ERROR - 2016-01-23 08:19:58 --> 404 Page Not Found --> 
ERROR - 2016-01-23 08:19:58 --> 404 Page Not Found --> 
DEBUG - 2016-01-23 08:20:18 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:20:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:20:18 --> URI Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Router Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Output Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Security Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Input Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:20:18 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Loader Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:20:18 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:20:18 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Session Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:20:18 --> Session routines successfully run
DEBUG - 2016-01-23 08:20:18 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Email Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Controller Class Initialized
DEBUG - 2016-01-23 08:20:18 --> Auth MX_Controller Initialized
DEBUG - 2016-01-23 08:20:18 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 08:20:18 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:20:18 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-23 08:20:19 --> XSS Filtering completed
DEBUG - 2016-01-23 08:20:19 --> Unable to find validation rule: exists
DEBUG - 2016-01-23 08:20:19 --> XSS Filtering completed
DEBUG - 2016-01-23 08:20:19 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:19 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:20:19 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:20:19 --> URI Class Initialized
DEBUG - 2016-01-23 08:20:19 --> Router Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Output Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Security Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Input Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:20:20 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Loader Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:20:20 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:20:20 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Session Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:20:20 --> Session routines successfully run
DEBUG - 2016-01-23 08:20:20 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Email Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Controller Class Initialized
DEBUG - 2016-01-23 08:20:20 --> Admin MX_Controller Initialized
DEBUG - 2016-01-23 08:20:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:20:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 08:20:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:20:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:20:21 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:20:21 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 08:20:22 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:22 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-23 08:20:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:20:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:20:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:20:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:20:23 --> Final output sent to browser
DEBUG - 2016-01-23 08:20:23 --> Total execution time: 3.9125
DEBUG - 2016-01-23 08:20:45 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:20:45 --> URI Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Router Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Output Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Security Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Input Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:20:45 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Language Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Config Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Loader Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:20:45 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:20:45 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Session Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:20:45 --> Session routines successfully run
DEBUG - 2016-01-23 08:20:45 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Email Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Controller Class Initialized
DEBUG - 2016-01-23 08:20:45 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:45 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:20:45 --> Model Class Initialized
DEBUG - 2016-01-23 08:20:49 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:20:49 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:20:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:20:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:20:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:20:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:20:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:20:50 --> Final output sent to browser
DEBUG - 2016-01-23 08:20:50 --> Total execution time: 5.3482
DEBUG - 2016-01-23 08:27:07 --> Config Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:27:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:27:07 --> URI Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Router Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Output Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Security Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Input Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:27:07 --> Language Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Language Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Config Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Loader Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:27:07 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:27:07 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Session Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:27:07 --> Session routines successfully run
DEBUG - 2016-01-23 08:27:07 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Email Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Controller Class Initialized
DEBUG - 2016-01-23 08:27:07 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:27:07 --> Model Class Initialized
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:27:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:27:07 --> Final output sent to browser
DEBUG - 2016-01-23 08:27:07 --> Total execution time: 0.2756
DEBUG - 2016-01-23 08:30:01 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:30:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:30:01 --> URI Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Router Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Output Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Security Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Input Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:30:01 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Loader Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:30:01 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:30:01 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Session Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:30:01 --> Session routines successfully run
DEBUG - 2016-01-23 08:30:01 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Email Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Controller Class Initialized
DEBUG - 2016-01-23 08:30:01 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:30:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:30:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:30:01 --> Final output sent to browser
DEBUG - 2016-01-23 08:30:01 --> Total execution time: 0.2964
DEBUG - 2016-01-23 08:30:29 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:30:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:30:29 --> URI Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Router Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Output Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Security Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Input Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:30:29 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Loader Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:30:29 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:30:29 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Session Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:30:29 --> Session routines successfully run
DEBUG - 2016-01-23 08:30:29 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Email Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Controller Class Initialized
DEBUG - 2016-01-23 08:30:29 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:30:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:30:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:30:29 --> Final output sent to browser
DEBUG - 2016-01-23 08:30:29 --> Total execution time: 0.2647
DEBUG - 2016-01-23 08:30:52 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:30:52 --> URI Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Router Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Output Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Security Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Input Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:30:52 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Language Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Config Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Loader Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:30:52 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:30:52 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Session Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:30:52 --> Session routines successfully run
DEBUG - 2016-01-23 08:30:52 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Email Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Controller Class Initialized
DEBUG - 2016-01-23 08:30:52 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:30:52 --> Model Class Initialized
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:30:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:30:53 --> Final output sent to browser
DEBUG - 2016-01-23 08:30:53 --> Total execution time: 0.3288
DEBUG - 2016-01-23 08:31:03 --> Config Class Initialized
DEBUG - 2016-01-23 08:31:03 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:31:03 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:31:03 --> URI Class Initialized
DEBUG - 2016-01-23 08:31:03 --> Router Class Initialized
ERROR - 2016-01-23 08:31:03 --> 404 Page Not Found --> 
DEBUG - 2016-01-23 08:31:27 --> Config Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:31:27 --> URI Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Router Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Output Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Security Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Input Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:31:27 --> Language Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Language Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Config Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Loader Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:31:27 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:31:27 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Session Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:31:27 --> Session routines successfully run
DEBUG - 2016-01-23 08:31:27 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Email Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Controller Class Initialized
DEBUG - 2016-01-23 08:31:27 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:31:27 --> Model Class Initialized
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:31:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:31:27 --> Final output sent to browser
DEBUG - 2016-01-23 08:31:27 --> Total execution time: 0.2705
DEBUG - 2016-01-23 08:31:31 --> Config Class Initialized
DEBUG - 2016-01-23 08:31:31 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:31:31 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:31:31 --> URI Class Initialized
DEBUG - 2016-01-23 08:31:31 --> Router Class Initialized
ERROR - 2016-01-23 08:31:31 --> 404 Page Not Found --> 
DEBUG - 2016-01-23 08:32:05 --> Config Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:32:05 --> URI Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Router Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Output Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Security Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Input Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:32:05 --> Language Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Language Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Config Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Loader Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:32:05 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:32:05 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Session Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:32:05 --> Session routines successfully run
DEBUG - 2016-01-23 08:32:05 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Email Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Controller Class Initialized
DEBUG - 2016-01-23 08:32:05 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:32:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:32:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:32:05 --> Final output sent to browser
DEBUG - 2016-01-23 08:32:05 --> Total execution time: 0.2891
DEBUG - 2016-01-23 08:32:09 --> Config Class Initialized
DEBUG - 2016-01-23 08:32:09 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:32:09 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:32:09 --> URI Class Initialized
DEBUG - 2016-01-23 08:32:09 --> Router Class Initialized
ERROR - 2016-01-23 08:32:09 --> 404 Page Not Found --> 
DEBUG - 2016-01-23 08:33:01 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:33:01 --> URI Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Router Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Output Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Security Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Input Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:33:01 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Loader Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:33:01 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:33:01 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Session Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:33:01 --> Session routines successfully run
DEBUG - 2016-01-23 08:33:01 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Email Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Controller Class Initialized
DEBUG - 2016-01-23 08:33:01 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:33:01 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:33:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:33:01 --> Final output sent to browser
DEBUG - 2016-01-23 08:33:01 --> Total execution time: 0.8756
DEBUG - 2016-01-23 08:33:05 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:33:05 --> URI Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Router Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Output Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Security Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Input Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:33:05 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Loader Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:33:05 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:33:05 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Session Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:33:05 --> Session routines successfully run
DEBUG - 2016-01-23 08:33:05 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Email Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Controller Class Initialized
DEBUG - 2016-01-23 08:33:05 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:33:05 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:05 --> DB Transaction Failure
ERROR - 2016-01-23 08:33:05 --> Query error: Table 'rents.propperty' doesn't exist
DEBUG - 2016-01-23 08:33:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-23 08:33:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:33:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:33:23 --> URI Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Router Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Output Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Security Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Input Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:33:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Loader Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:33:23 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:33:23 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Session Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:33:23 --> Session routines successfully run
DEBUG - 2016-01-23 08:33:23 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Email Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Controller Class Initialized
DEBUG - 2016-01-23 08:33:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:33:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:33:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:33:23 --> Final output sent to browser
DEBUG - 2016-01-23 08:33:23 --> Total execution time: 0.3237
DEBUG - 2016-01-23 08:33:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:33:36 --> URI Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Router Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Output Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Security Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Input Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:33:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Loader Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:33:36 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:33:36 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Session Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:33:36 --> Session routines successfully run
DEBUG - 2016-01-23 08:33:36 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Email Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Controller Class Initialized
DEBUG - 2016-01-23 08:33:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:33:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:33:36 --> DB Transaction Failure
ERROR - 2016-01-23 08:33:36 --> Query error: Unknown column 'property.property_id1' in 'where clause'
DEBUG - 2016-01-23 08:33:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-23 08:34:35 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:35 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:34:35 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:34:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:34:35 --> URI Class Initialized
DEBUG - 2016-01-23 08:34:35 --> Router Class Initialized
DEBUG - 2016-01-23 08:34:35 --> Output Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Security Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Input Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:34:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Loader Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:34:36 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:34:36 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Session Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:34:36 --> Session routines successfully run
DEBUG - 2016-01-23 08:34:36 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Email Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Controller Class Initialized
DEBUG - 2016-01-23 08:34:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:34:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:36 --> DB Transaction Failure
ERROR - 2016-01-23 08:34:36 --> Query error: Unknown column 'property.property_id1' in 'where clause'
DEBUG - 2016-01-23 08:34:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-23 08:34:43 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:34:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:34:43 --> URI Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Router Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Output Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Security Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Input Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:34:43 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Loader Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:34:43 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:34:43 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Session Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:34:43 --> Session routines successfully run
DEBUG - 2016-01-23 08:34:43 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Email Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Controller Class Initialized
DEBUG - 2016-01-23 08:34:43 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:34:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:43 --> DB Transaction Failure
ERROR - 2016-01-23 08:34:43 --> Query error: Unknown column 'property.property_id1' in 'where clause'
DEBUG - 2016-01-23 08:34:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-23 08:34:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:34:48 --> URI Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Router Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Output Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Security Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Input Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:34:48 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Language Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Config Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Loader Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:34:48 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:34:48 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Session Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:34:48 --> Session routines successfully run
DEBUG - 2016-01-23 08:34:48 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Email Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Controller Class Initialized
DEBUG - 2016-01-23 08:34:48 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:34:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:34:48 --> DB Transaction Failure
ERROR - 2016-01-23 08:34:48 --> Query error: Unknown column 'property.property_id1' in 'where clause'
DEBUG - 2016-01-23 08:34:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-23 08:35:53 --> Config Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:35:53 --> URI Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Router Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Output Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Security Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Input Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:35:53 --> Language Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Language Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Config Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Loader Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:35:53 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:35:53 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Session Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:35:53 --> Session routines successfully run
DEBUG - 2016-01-23 08:35:53 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Email Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Controller Class Initialized
DEBUG - 2016-01-23 08:35:53 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:35:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:35:53 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:35:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:35:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:35:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:35:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:35:54 --> Final output sent to browser
DEBUG - 2016-01-23 08:35:54 --> Total execution time: 0.2956
DEBUG - 2016-01-23 08:35:59 --> Config Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:35:59 --> URI Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Router Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Output Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Security Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Input Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:35:59 --> Language Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Language Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Config Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Loader Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:35:59 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:35:59 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Session Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:35:59 --> Session routines successfully run
DEBUG - 2016-01-23 08:35:59 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Email Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Controller Class Initialized
DEBUG - 2016-01-23 08:35:59 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:35:59 --> Model Class Initialized
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:35:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:35:59 --> Final output sent to browser
DEBUG - 2016-01-23 08:35:59 --> Total execution time: 0.2880
DEBUG - 2016-01-23 08:36:44 --> Config Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:36:44 --> URI Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Router Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Output Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Security Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Input Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:36:44 --> Language Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Language Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Config Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Loader Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:36:44 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:36:44 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Session Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:36:44 --> Session routines successfully run
DEBUG - 2016-01-23 08:36:44 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Email Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Controller Class Initialized
DEBUG - 2016-01-23 08:36:44 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:36:44 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:36:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:36:44 --> Final output sent to browser
DEBUG - 2016-01-23 08:36:44 --> Total execution time: 0.3960
DEBUG - 2016-01-23 08:36:50 --> Config Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:36:50 --> URI Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Router Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Output Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Security Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Input Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:36:50 --> Language Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Language Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Config Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Loader Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:36:50 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:36:50 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Session Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:36:50 --> Session routines successfully run
DEBUG - 2016-01-23 08:36:50 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Email Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Controller Class Initialized
DEBUG - 2016-01-23 08:36:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:36:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:36:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:36:50 --> Final output sent to browser
DEBUG - 2016-01-23 08:36:50 --> Total execution time: 0.2870
DEBUG - 2016-01-23 08:43:29 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:43:29 --> URI Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Router Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Output Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Security Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Input Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:43:29 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Loader Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:43:29 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:43:29 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Session Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:43:29 --> Session routines successfully run
DEBUG - 2016-01-23 08:43:29 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Email Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Controller Class Initialized
DEBUG - 2016-01-23 08:43:29 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:43:29 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:43:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:43:29 --> Final output sent to browser
DEBUG - 2016-01-23 08:43:29 --> Total execution time: 0.2641
DEBUG - 2016-01-23 08:43:34 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:43:34 --> URI Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Router Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Output Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Security Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Input Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:43:34 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Loader Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:43:34 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:43:34 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Session Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:43:34 --> Session routines successfully run
DEBUG - 2016-01-23 08:43:34 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Email Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Controller Class Initialized
DEBUG - 2016-01-23 08:43:34 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:43:34 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:43:34 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:43:35 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:43:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:43:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:43:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:43:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:43:35 --> Final output sent to browser
DEBUG - 2016-01-23 08:43:35 --> Total execution time: 0.2698
DEBUG - 2016-01-23 08:43:48 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:43:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:43:48 --> URI Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Router Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Output Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Security Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Input Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:43:48 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Language Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Config Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Loader Class Initialized
DEBUG - 2016-01-23 08:43:48 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:43:48 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:43:48 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Session Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:43:49 --> Session routines successfully run
DEBUG - 2016-01-23 08:43:49 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Email Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Controller Class Initialized
DEBUG - 2016-01-23 08:43:49 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:43:49 --> Model Class Initialized
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:43:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:43:49 --> Final output sent to browser
DEBUG - 2016-01-23 08:43:49 --> Total execution time: 0.3035
DEBUG - 2016-01-23 08:44:08 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:44:08 --> URI Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Router Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Output Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Security Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Input Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:44:08 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Loader Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:44:08 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:44:08 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Session Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:44:08 --> Session routines successfully run
DEBUG - 2016-01-23 08:44:08 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Email Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Controller Class Initialized
DEBUG - 2016-01-23 08:44:08 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:44:08 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:44:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:44:08 --> Final output sent to browser
DEBUG - 2016-01-23 08:44:08 --> Total execution time: 0.4106
DEBUG - 2016-01-23 08:44:15 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:44:15 --> URI Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Router Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Output Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Security Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Input Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:44:15 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Loader Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:44:15 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:44:15 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Session Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:44:15 --> Session routines successfully run
DEBUG - 2016-01-23 08:44:15 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Email Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Controller Class Initialized
DEBUG - 2016-01-23 08:44:15 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:44:15 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:44:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:44:15 --> Final output sent to browser
DEBUG - 2016-01-23 08:44:15 --> Total execution time: 0.2689
DEBUG - 2016-01-23 08:44:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:44:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:44:23 --> URI Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Router Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Output Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Security Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Input Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:44:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:44:23 --> Loader Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:44:24 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:44:24 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Session Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:44:24 --> Session routines successfully run
DEBUG - 2016-01-23 08:44:24 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Email Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Controller Class Initialized
DEBUG - 2016-01-23 08:44:24 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:44:24 --> Model Class Initialized
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 3 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: month C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: this_year C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 3 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: month C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: this_year C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 3 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: month C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: this_year C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 2 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Warning  --> Missing argument 3 for Accounts_model::get_months_amount(), called in C:\xampp\htdocs\rents\application\modules\administration\models\reports_model.php on line 1278 and defined C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 39
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: month C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
ERROR - 2016-01-23 08:44:24 --> Severity: Notice  --> Undefined variable: this_year C:\xampp\htdocs\rents\application\modules\accounts\models\accounts_model.php 44
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:44:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:44:24 --> Final output sent to browser
DEBUG - 2016-01-23 08:44:24 --> Total execution time: 0.3815
DEBUG - 2016-01-23 08:51:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:51:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:51:36 --> URI Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Router Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Output Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Security Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Input Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:51:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Language Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Config Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Loader Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:51:36 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:51:36 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Session Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:51:36 --> Session routines successfully run
DEBUG - 2016-01-23 08:51:36 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Email Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Controller Class Initialized
DEBUG - 2016-01-23 08:51:36 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:51:36 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:51:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:51:36 --> Final output sent to browser
DEBUG - 2016-01-23 08:51:36 --> Total execution time: 0.3622
DEBUG - 2016-01-23 08:51:46 --> Config Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:51:46 --> URI Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Router Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Output Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Security Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Input Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:51:46 --> Language Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Language Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Config Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Loader Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:51:46 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:51:46 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Session Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:51:46 --> Session routines successfully run
DEBUG - 2016-01-23 08:51:46 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Email Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Controller Class Initialized
DEBUG - 2016-01-23 08:51:46 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:51:46 --> Model Class Initialized
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:51:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:51:46 --> Final output sent to browser
DEBUG - 2016-01-23 08:51:46 --> Total execution time: 0.2571
DEBUG - 2016-01-23 08:52:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:52:58 --> URI Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Router Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Output Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Security Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Input Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:52:58 --> Language Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Language Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Config Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Loader Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:52:58 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:52:58 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Session Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:52:58 --> Session routines successfully run
DEBUG - 2016-01-23 08:52:58 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Email Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Controller Class Initialized
DEBUG - 2016-01-23 08:52:58 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:52:58 --> Model Class Initialized
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:52:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:52:58 --> Final output sent to browser
DEBUG - 2016-01-23 08:52:58 --> Total execution time: 0.2344
DEBUG - 2016-01-23 08:57:06 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:57:06 --> URI Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Router Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Output Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Security Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Input Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:57:06 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Loader Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:57:06 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:57:06 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Session Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:57:06 --> Session routines successfully run
DEBUG - 2016-01-23 08:57:06 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Email Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Controller Class Initialized
DEBUG - 2016-01-23 08:57:06 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:57:06 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:57:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:57:06 --> Final output sent to browser
DEBUG - 2016-01-23 08:57:06 --> Total execution time: 0.2589
DEBUG - 2016-01-23 08:57:15 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:15 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:57:15 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:57:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:57:15 --> URI Class Initialized
DEBUG - 2016-01-23 08:57:15 --> Router Class Initialized
ERROR - 2016-01-23 08:57:15 --> 404 Page Not Found --> 
DEBUG - 2016-01-23 08:57:43 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:57:43 --> URI Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Router Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Output Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Security Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Input Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:57:43 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Loader Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:57:43 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:57:43 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Session Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:57:43 --> Session routines successfully run
DEBUG - 2016-01-23 08:57:43 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Email Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Controller Class Initialized
DEBUG - 2016-01-23 08:57:43 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:57:43 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:57:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:57:43 --> Final output sent to browser
DEBUG - 2016-01-23 08:57:43 --> Total execution time: 0.2609
DEBUG - 2016-01-23 08:57:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:57:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:57:47 --> URI Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Router Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Output Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Security Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Input Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:57:47 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Language Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Loader Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:57:47 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:57:47 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Session Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:57:47 --> Session routines successfully run
DEBUG - 2016-01-23 08:57:47 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Email Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Controller Class Initialized
DEBUG - 2016-01-23 08:57:47 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:57:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:57:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:57:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:57:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:57:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:57:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:57:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:57:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:57:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:57:48 --> Final output sent to browser
DEBUG - 2016-01-23 08:57:48 --> Total execution time: 0.2585
DEBUG - 2016-01-23 08:58:19 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:19 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:19 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:19 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:20 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:20 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:20 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:20 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:20 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:20 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:20 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:20 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:20 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:20 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:20 --> Total execution time: 0.3074
DEBUG - 2016-01-23 08:58:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:23 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:23 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:23 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:23 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:23 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:23 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:23 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:23 --> Total execution time: 0.2573
DEBUG - 2016-01-23 08:58:35 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:35 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:35 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:35 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:35 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:35 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:35 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:35 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:35 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:35 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:35 --> Total execution time: 0.2449
DEBUG - 2016-01-23 08:58:38 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:38 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:38 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:38 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:38 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:38 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:38 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:38 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:38 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:38 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:38 --> Total execution time: 0.2349
DEBUG - 2016-01-23 08:58:41 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:41 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:41 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:41 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:41 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:41 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:41 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:41 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:41 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:41 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:41 --> Total execution time: 0.2635
DEBUG - 2016-01-23 08:58:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:47 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:47 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:47 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:47 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:47 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:47 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:47 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:47 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:47 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:47 --> Total execution time: 0.2410
DEBUG - 2016-01-23 08:58:50 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:58:50 --> URI Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Router Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Output Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Security Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Input Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:58:50 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Language Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Config Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Loader Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:58:50 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:58:50 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Session Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:58:50 --> Session routines successfully run
DEBUG - 2016-01-23 08:58:50 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Email Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Controller Class Initialized
DEBUG - 2016-01-23 08:58:50 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:58:50 --> Model Class Initialized
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:58:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:58:50 --> Final output sent to browser
DEBUG - 2016-01-23 08:58:50 --> Total execution time: 0.3001
DEBUG - 2016-01-23 08:59:47 --> Config Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:59:47 --> URI Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Router Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Output Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Security Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Input Class Initialized
DEBUG - 2016-01-23 08:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:59:47 --> Language Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Language Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Config Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Loader Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:59:48 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:59:48 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Session Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:59:48 --> Session routines successfully run
DEBUG - 2016-01-23 08:59:48 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Email Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Controller Class Initialized
DEBUG - 2016-01-23 08:59:48 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:59:48 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:59:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:59:48 --> Final output sent to browser
DEBUG - 2016-01-23 08:59:48 --> Total execution time: 0.2671
DEBUG - 2016-01-23 08:59:53 --> Config Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Hooks Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Utf8 Class Initialized
DEBUG - 2016-01-23 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 08:59:53 --> URI Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Router Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Output Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Security Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Input Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 08:59:53 --> Language Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Language Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Config Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Loader Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Helper loaded: url_helper
DEBUG - 2016-01-23 08:59:53 --> Helper loaded: form_helper
DEBUG - 2016-01-23 08:59:53 --> Database Driver Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Session Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Helper loaded: string_helper
DEBUG - 2016-01-23 08:59:53 --> Session routines successfully run
DEBUG - 2016-01-23 08:59:53 --> Form Validation Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Pagination Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Encrypt Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Email Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Controller Class Initialized
DEBUG - 2016-01-23 08:59:53 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 08:59:53 --> Model Class Initialized
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 08:59:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 08:59:53 --> Final output sent to browser
DEBUG - 2016-01-23 08:59:53 --> Total execution time: 0.2410
DEBUG - 2016-01-23 09:00:23 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:00:23 --> URI Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Router Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Output Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Security Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Input Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:00:23 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Loader Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:00:23 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:00:23 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Session Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:00:23 --> Session routines successfully run
DEBUG - 2016-01-23 09:00:23 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Email Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Controller Class Initialized
DEBUG - 2016-01-23 09:00:23 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:00:23 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:00:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:00:23 --> Final output sent to browser
DEBUG - 2016-01-23 09:00:23 --> Total execution time: 0.2400
DEBUG - 2016-01-23 09:00:29 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:00:29 --> URI Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Router Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Output Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Security Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Input Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:00:29 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Loader Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:00:29 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:00:29 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Session Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:00:29 --> Session routines successfully run
DEBUG - 2016-01-23 09:00:29 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Email Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Controller Class Initialized
DEBUG - 2016-01-23 09:00:29 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:00:29 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:00:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:00:29 --> Final output sent to browser
DEBUG - 2016-01-23 09:00:29 --> Total execution time: 0.2338
DEBUG - 2016-01-23 09:00:31 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:00:31 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:00:31 --> URI Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Router Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Output Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Security Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Input Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:00:31 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Loader Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:00:31 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:00:31 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Session Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:00:31 --> Session routines successfully run
DEBUG - 2016-01-23 09:00:31 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Email Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Controller Class Initialized
DEBUG - 2016-01-23 09:00:31 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:00:31 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/administration/views/reports/search/transactions.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/administration/views/reports/transaction_statistics.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/administration/views/reports/all_transactions.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:00:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:00:31 --> Final output sent to browser
DEBUG - 2016-01-23 09:00:31 --> Total execution time: 0.2695
DEBUG - 2016-01-23 09:00:39 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:00:39 --> URI Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Router Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Output Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Security Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Input Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:00:39 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Loader Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:00:39 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:00:39 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Session Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:00:39 --> Session routines successfully run
DEBUG - 2016-01-23 09:00:39 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Email Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Controller Class Initialized
DEBUG - 2016-01-23 09:00:39 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:39 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:00:39 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:00:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:00:40 --> Final output sent to browser
DEBUG - 2016-01-23 09:00:40 --> Total execution time: 0.2352
DEBUG - 2016-01-23 09:00:43 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:00:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:00:43 --> URI Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Router Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Output Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Security Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Input Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:00:43 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Language Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Config Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Loader Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:00:43 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:00:43 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Session Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:00:43 --> Session routines successfully run
DEBUG - 2016-01-23 09:00:43 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Email Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Controller Class Initialized
DEBUG - 2016-01-23 09:00:43 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:00:43 --> Model Class Initialized
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:00:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:00:43 --> Final output sent to browser
DEBUG - 2016-01-23 09:00:43 --> Total execution time: 0.2322
DEBUG - 2016-01-23 09:01:03 --> Config Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:01:03 --> URI Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Router Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Output Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Security Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Input Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:01:03 --> Language Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Language Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Config Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Loader Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:01:03 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:01:03 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Session Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:01:03 --> Session routines successfully run
DEBUG - 2016-01-23 09:01:03 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Email Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Controller Class Initialized
DEBUG - 2016-01-23 09:01:03 --> Reports MX_Controller Initialized
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-01-23 09:01:03 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:01:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:01:03 --> Final output sent to browser
DEBUG - 2016-01-23 09:01:03 --> Total execution time: 0.2368
DEBUG - 2016-01-23 09:01:16 --> Config Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:01:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:01:16 --> URI Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Router Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Output Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Security Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Input Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:01:16 --> Language Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Language Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Config Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Loader Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:01:16 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:01:16 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Session Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:01:16 --> Session routines successfully run
DEBUG - 2016-01-23 09:01:16 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Email Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Controller Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:16 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-23 09:01:16 --> Model Class Initialized
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:01:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:01:17 --> Final output sent to browser
DEBUG - 2016-01-23 09:01:17 --> Total execution time: 0.8308
DEBUG - 2016-01-23 09:49:25 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:25 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:49:25 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:49:25 --> URI Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Router Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Output Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Security Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Input Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:49:26 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Loader Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:49:26 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:49:26 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Session Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:49:26 --> Session routines successfully run
DEBUG - 2016-01-23 09:49:26 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Email Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Controller Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Property MX_Controller Initialized
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:49:26 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:26 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:49:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:49:26 --> Final output sent to browser
DEBUG - 2016-01-23 09:49:26 --> Total execution time: 1.4669
DEBUG - 2016-01-23 09:49:32 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:49:32 --> URI Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Router Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Output Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Security Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Input Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:49:32 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Loader Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:49:32 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:49:32 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Session Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:49:32 --> Session routines successfully run
DEBUG - 2016-01-23 09:49:32 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Email Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Controller Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-23 09:49:32 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:32 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:49:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:49:32 --> Final output sent to browser
DEBUG - 2016-01-23 09:49:32 --> Total execution time: 0.4585
DEBUG - 2016-01-23 09:49:35 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:49:35 --> URI Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Router Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Output Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Security Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Input Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:49:35 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Loader Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:49:35 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:49:35 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Session Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:49:35 --> Session routines successfully run
DEBUG - 2016-01-23 09:49:35 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Email Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Controller Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-23 09:49:35 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:49:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:49:35 --> Final output sent to browser
DEBUG - 2016-01-23 09:49:35 --> Total execution time: 0.3178
DEBUG - 2016-01-23 09:49:42 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:49:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:49:42 --> URI Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Router Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Output Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Security Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Input Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:49:42 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Loader Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:49:42 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Session Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:49:42 --> Session routines successfully run
DEBUG - 2016-01-23 09:49:42 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Email Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Controller Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-23 09:49:42 --> XSS Filtering completed
DEBUG - 2016-01-23 09:49:42 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Hooks Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Utf8 Class Initialized
DEBUG - 2016-01-23 09:49:42 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 09:49:42 --> URI Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Router Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Output Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Security Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Input Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 09:49:42 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Language Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Config Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Loader Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: url_helper
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: form_helper
DEBUG - 2016-01-23 09:49:42 --> Database Driver Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Session Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Helper loaded: string_helper
DEBUG - 2016-01-23 09:49:42 --> Session routines successfully run
DEBUG - 2016-01-23 09:49:42 --> Form Validation Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Pagination Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Encrypt Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Email Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Controller Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> Image Lib Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-23 09:49:42 --> Model Class Initialized
ERROR - 2016-01-23 09:49:42 --> Severity: Notice  --> Undefined property: stdClass::$arreas_bf C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\leases\view_lease.php 52
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-23 09:49:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-23 09:49:42 --> Final output sent to browser
DEBUG - 2016-01-23 09:49:42 --> Total execution time: 0.4102
DEBUG - 2016-01-23 18:02:14 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:15 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:15 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:15 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:16 --> Router Class Initialized
DEBUG - 2016-01-23 18:02:17 --> No URI present. Default controller set.
DEBUG - 2016-01-23 18:02:17 --> Output Class Initialized
DEBUG - 2016-01-23 18:02:17 --> Security Class Initialized
DEBUG - 2016-01-23 18:02:17 --> Input Class Initialized
DEBUG - 2016-01-23 18:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 18:02:17 --> Language Class Initialized
DEBUG - 2016-01-23 18:02:18 --> Language Class Initialized
DEBUG - 2016-01-23 18:02:18 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:18 --> Loader Class Initialized
DEBUG - 2016-01-23 18:02:19 --> Helper loaded: url_helper
DEBUG - 2016-01-23 18:02:19 --> Helper loaded: form_helper
DEBUG - 2016-01-23 18:02:20 --> Database Driver Class Initialized
DEBUG - 2016-01-23 18:02:22 --> Session Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Helper loaded: string_helper
ERROR - 2016-01-23 18:02:23 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-01-23 18:02:23 --> Session routines successfully run
DEBUG - 2016-01-23 18:02:23 --> Form Validation Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Pagination Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Encrypt Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Email Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Controller Class Initialized
DEBUG - 2016-01-23 18:02:23 --> Auth MX_Controller Initialized
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:24 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Router Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Output Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Security Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Input Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-23 18:02:24 --> Language Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Language Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Loader Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Helper loaded: url_helper
DEBUG - 2016-01-23 18:02:24 --> Helper loaded: form_helper
DEBUG - 2016-01-23 18:02:24 --> Database Driver Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Session Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Helper loaded: string_helper
DEBUG - 2016-01-23 18:02:24 --> Session routines successfully run
DEBUG - 2016-01-23 18:02:24 --> Form Validation Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Pagination Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Encrypt Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Email Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Controller Class Initialized
DEBUG - 2016-01-23 18:02:24 --> Auth MX_Controller Initialized
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-23 18:02:24 --> Model Class Initialized
DEBUG - 2016-01-23 18:02:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-23 18:02:26 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-23 18:02:26 --> Final output sent to browser
DEBUG - 2016-01-23 18:02:26 --> Total execution time: 1.5050
DEBUG - 2016-01-23 18:02:44 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:44 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:44 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Router Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Router Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:44 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Config Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Hooks Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Utf8 Class Initialized
DEBUG - 2016-01-23 18:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-23 18:02:44 --> URI Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Router Class Initialized
DEBUG - 2016-01-23 18:02:44 --> Router Class Initialized
ERROR - 2016-01-23 18:02:44 --> 404 Page Not Found --> 
ERROR - 2016-01-23 18:02:44 --> 404 Page Not Found --> 
ERROR - 2016-01-23 18:02:44 --> 404 Page Not Found --> 
ERROR - 2016-01-23 18:02:44 --> 404 Page Not Found --> 
