<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-04-05 10:56:50 --> Config Class Initialized
DEBUG - 2016-04-05 10:56:50 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:56:50 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:56:50 --> URI Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Router Class Initialized
DEBUG - 2016-04-05 10:56:51 --> No URI present. Default controller set.
DEBUG - 2016-04-05 10:56:51 --> Output Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Security Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Input Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:56:51 --> Language Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Language Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Config Class Initialized
DEBUG - 2016-04-05 10:56:51 --> Loader Class Initialized
DEBUG - 2016-04-05 10:56:52 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:56:52 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:56:52 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:56:57 --> Session Class Initialized
DEBUG - 2016-04-05 10:56:57 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:56:57 --> A session cookie was not found.
DEBUG - 2016-04-05 10:56:58 --> Session routines successfully run
DEBUG - 2016-04-05 10:56:58 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Email Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Controller Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Auth MX_Controller Initialized
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Config Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:56:58 --> URI Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Router Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Output Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Security Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Input Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:56:58 --> Language Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Language Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Config Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Loader Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:56:58 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:56:58 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Session Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:56:58 --> Session routines successfully run
DEBUG - 2016-04-05 10:56:58 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Email Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Controller Class Initialized
DEBUG - 2016-04-05 10:56:58 --> Auth MX_Controller Initialized
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:56:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:56:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:56:58 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:57:00 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-04-05 10:57:00 --> Final output sent to browser
DEBUG - 2016-04-05 10:57:00 --> Total execution time: 2.0597
DEBUG - 2016-04-05 10:57:07 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:07 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:07 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:07 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:07 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:07 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Router Class Initialized
ERROR - 2016-04-05 10:57:07 --> 404 Page Not Found --> 
ERROR - 2016-04-05 10:57:07 --> 404 Page Not Found --> 
ERROR - 2016-04-05 10:57:07 --> 404 Page Not Found --> 
DEBUG - 2016-04-05 10:57:07 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:07 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:07 --> Router Class Initialized
ERROR - 2016-04-05 10:57:07 --> 404 Page Not Found --> 
DEBUG - 2016-04-05 10:57:15 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:15 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Output Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Security Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Input Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:57:15 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Loader Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:57:15 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:57:15 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Session Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:57:15 --> Session routines successfully run
DEBUG - 2016-04-05 10:57:15 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Email Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Controller Class Initialized
DEBUG - 2016-04-05 10:57:15 --> Auth MX_Controller Initialized
DEBUG - 2016-04-05 10:57:15 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:57:15 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:57:15 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-04-05 10:57:16 --> XSS Filtering completed
DEBUG - 2016-04-05 10:57:16 --> Unable to find validation rule: exists
DEBUG - 2016-04-05 10:57:16 --> XSS Filtering completed
DEBUG - 2016-04-05 10:57:16 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:16 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Output Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Security Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Input Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:57:16 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Loader Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:57:16 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:57:16 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Session Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:57:16 --> Session routines successfully run
DEBUG - 2016-04-05 10:57:16 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Email Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Controller Class Initialized
DEBUG - 2016-04-05 10:57:16 --> Admin MX_Controller Initialized
DEBUG - 2016-04-05 10:57:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:57:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:57:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:57:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:57:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:57:17 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:57:17 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:17 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-04-05 10:57:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:57:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:57:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:57:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:57:18 --> Final output sent to browser
DEBUG - 2016-04-05 10:57:18 --> Total execution time: 2.1405
DEBUG - 2016-04-05 10:57:45 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:45 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:45 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:45 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:45 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Output Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Security Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Input Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:57:46 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Loader Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:57:46 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:57:46 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Session Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:57:46 --> Session routines successfully run
DEBUG - 2016-04-05 10:57:46 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Email Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Controller Class Initialized
DEBUG - 2016-04-05 10:57:46 --> Messaging MX_Controller Initialized
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:46 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-04-05 10:57:46 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:47 --> File loaded: application/modules/messaging/views/sms/unsent_messages.php
DEBUG - 2016-04-05 10:57:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:57:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:57:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:57:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:57:47 --> Final output sent to browser
DEBUG - 2016-04-05 10:57:47 --> Total execution time: 1.2830
DEBUG - 2016-04-05 10:57:55 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:57:55 --> URI Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Router Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Output Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Security Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Input Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:57:55 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Language Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Config Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Loader Class Initialized
DEBUG - 2016-04-05 10:57:55 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:57:55 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:57:56 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Session Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:57:56 --> Session routines successfully run
DEBUG - 2016-04-05 10:57:56 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Email Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Controller Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Messaging MX_Controller Initialized
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/messaging/models/messaging_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-04-05 10:57:56 --> Model Class Initialized
DEBUG - 2016-04-05 10:57:56 --> Final output sent to browser
DEBUG - 2016-04-05 10:57:56 --> Total execution time: 0.2811
DEBUG - 2016-04-05 10:58:16 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:16 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:16 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:16 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:16 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:16 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:16 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:16 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:16 --> Sections MX_Controller Initialized
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:16 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:17 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2016-04-05 10:58:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:58:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:58:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:58:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:58:17 --> Final output sent to browser
DEBUG - 2016-04-05 10:58:17 --> Total execution time: 1.1277
DEBUG - 2016-04-05 10:58:20 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:20 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:20 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:20 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:20 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:21 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:21 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:21 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:58:21 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Image Lib Class Initialized
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:58:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:58:21 --> Final output sent to browser
DEBUG - 2016-04-05 10:58:21 --> Total execution time: 0.9031
DEBUG - 2016-04-05 10:58:21 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:21 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:21 --> Router Class Initialized
ERROR - 2016-04-05 10:58:21 --> 404 Page Not Found --> 
DEBUG - 2016-04-05 10:58:36 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:36 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:36 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:36 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:36 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:36 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:36 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:36 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:58:36 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:36 --> Image Lib Class Initialized
ERROR - 2016-04-05 10:58:36 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 275 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:58:36 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 277 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2016-04-05 10:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\helpers\url_helper.php 543
DEBUG - 2016-04-05 10:58:45 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:45 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:45 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:45 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:45 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:45 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:45 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:58:45 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Image Lib Class Initialized
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:58:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:58:45 --> Final output sent to browser
DEBUG - 2016-04-05 10:58:45 --> Total execution time: 0.2470
DEBUG - 2016-04-05 10:58:45 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:45 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:45 --> Router Class Initialized
ERROR - 2016-04-05 10:58:45 --> 404 Page Not Found --> 
DEBUG - 2016-04-05 10:58:47 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:47 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:47 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:47 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:47 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:47 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:48 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:48 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:48 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:48 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:48 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:58:48 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:48 --> Image Lib Class Initialized
ERROR - 2016-04-05 10:58:48 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 275 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:58:48 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 277 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:58:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2016-04-05 10:58:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\helpers\url_helper.php 543
DEBUG - 2016-04-05 10:58:53 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:53 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:53 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:53 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:53 --> Router Class Initialized
DEBUG - 2016-04-05 10:58:53 --> Output Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Security Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Input Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:58:54 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Language Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Loader Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:58:54 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:58:54 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Session Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:58:54 --> Session routines successfully run
DEBUG - 2016-04-05 10:58:54 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Email Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Controller Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:58:54 --> Model Class Initialized
DEBUG - 2016-04-05 10:58:54 --> Image Lib Class Initialized
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/views/branches/all_branches.php
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:58:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:58:54 --> Final output sent to browser
DEBUG - 2016-04-05 10:58:54 --> Total execution time: 0.9504
DEBUG - 2016-04-05 10:58:55 --> Config Class Initialized
DEBUG - 2016-04-05 10:58:55 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:58:55 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:58:55 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:58:55 --> URI Class Initialized
DEBUG - 2016-04-05 10:58:55 --> Router Class Initialized
ERROR - 2016-04-05 10:58:55 --> 404 Page Not Found --> 
DEBUG - 2016-04-05 10:59:05 --> Config Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:59:05 --> URI Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Router Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Output Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Security Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Input Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:59:05 --> Language Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Language Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Config Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Loader Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:59:05 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:59:05 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Session Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:59:05 --> Session routines successfully run
DEBUG - 2016-04-05 10:59:05 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Email Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Controller Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:59:05 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:05 --> Image Lib Class Initialized
ERROR - 2016-04-05 10:59:05 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 275 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:59:05 --> Severity: Warning  --> Missing argument 2 for File_model::delete_file(), called in C:\xampp\htdocs\rents\application\modules\admin\controllers\branches.php on line 277 and defined C:\xampp\htdocs\rents\application\modules\admin\models\file_model.php 225
ERROR - 2016-04-05 10:59:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2016-04-05 10:59:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\helpers\url_helper.php 543
DEBUG - 2016-04-05 10:59:09 --> Config Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Hooks Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Utf8 Class Initialized
DEBUG - 2016-04-05 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 10:59:09 --> URI Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Router Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Output Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Security Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Input Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 10:59:09 --> Language Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Language Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Config Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Loader Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Helper loaded: url_helper
DEBUG - 2016-04-05 10:59:09 --> Helper loaded: form_helper
DEBUG - 2016-04-05 10:59:09 --> Database Driver Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Session Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Helper loaded: string_helper
DEBUG - 2016-04-05 10:59:09 --> Session routines successfully run
DEBUG - 2016-04-05 10:59:09 --> Form Validation Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Pagination Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Encrypt Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Email Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Controller Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Branches MX_Controller Initialized
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2016-04-05 10:59:09 --> Model Class Initialized
DEBUG - 2016-04-05 10:59:09 --> Image Lib Class Initialized
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/views/branches/all_branches.php
ERROR - 2016-04-05 10:59:09 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 10:59:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 10:59:10 --> Final output sent to browser
DEBUG - 2016-04-05 10:59:10 --> Total execution time: 0.2640
DEBUG - 2016-04-05 11:01:18 --> Config Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Hooks Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Utf8 Class Initialized
DEBUG - 2016-04-05 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2016-04-05 11:01:18 --> URI Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Router Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Output Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Security Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Input Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-04-05 11:01:18 --> Language Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Language Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Config Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Loader Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Helper loaded: url_helper
DEBUG - 2016-04-05 11:01:18 --> Helper loaded: form_helper
DEBUG - 2016-04-05 11:01:18 --> Database Driver Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Session Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Helper loaded: string_helper
DEBUG - 2016-04-05 11:01:18 --> Session routines successfully run
DEBUG - 2016-04-05 11:01:18 --> Form Validation Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Pagination Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Encrypt Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Email Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Controller Class Initialized
DEBUG - 2016-04-05 11:01:18 --> Admin MX_Controller Initialized
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-04-05 11:01:18 --> Model Class Initialized
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/views/configuration.php
ERROR - 2016-04-05 11:01:18 --> Severity: Notice  --> Undefined variable: company_name C:\xampp\htdocs\rents\application\modules\admin\views\includes\header.php 4
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-04-05 11:01:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-04-05 11:01:19 --> Final output sent to browser
DEBUG - 2016-04-05 11:01:19 --> Total execution time: 0.4427
