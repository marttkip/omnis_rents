<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-30 08:46:23 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:23 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:23 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:24 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:24 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:24 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:25 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:25 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:26 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:26 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:28 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:30 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:30 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:30 --> A session cookie was not found.
DEBUG - 2015-12-30 08:46:30 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:31 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:31 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:31 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:31 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:31 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:31 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:32 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:32 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:32 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:32 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:32 --> A session cookie was not found.
DEBUG - 2015-12-30 08:46:32 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:32 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:32 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:32 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:33 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:46:33 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-30 08:46:33 --> Final output sent to browser
DEBUG - 2015-12-30 08:46:33 --> Total execution time: 1.0835
DEBUG - 2015-12-30 08:46:36 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:36 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:36 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:36 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:36 --> Router Class Initialized
ERROR - 2015-12-30 08:46:36 --> 404 Page Not Found --> 
ERROR - 2015-12-30 08:46:36 --> 404 Page Not Found --> 
ERROR - 2015-12-30 08:46:36 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 08:46:39 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:39 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:40 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:40 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:40 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:40 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:40 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:40 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 08:46:40 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:40 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:40 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-30 08:46:40 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:40 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:40 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:40 --> XSS Filtering completed
DEBUG - 2015-12-30 08:46:40 --> Unable to find validation rule: exists
DEBUG - 2015-12-30 08:46:40 --> XSS Filtering completed
DEBUG - 2015-12-30 08:46:42 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:42 --> URI Class Initialized
ERROR - 2015-12-30 08:46:42 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 08:46:42 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:42 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:42 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:42 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:42 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:42 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:42 --> Admin MX_Controller Initialized
DEBUG - 2015-12-30 08:46:42 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:46:42 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:42 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:42 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:46:42 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:46:43 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:43 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:46:43 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:43 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:43 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-30 08:46:43 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:46:43 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:46:43 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:46:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:46:43 --> Final output sent to browser
DEBUG - 2015-12-30 08:46:43 --> Total execution time: 1.1901
DEBUG - 2015-12-30 08:46:44 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:44 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:44 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-30 08:46:44 --> XSS Filtering completed
DEBUG - 2015-12-30 08:46:44 --> Unable to find validation rule: exists
DEBUG - 2015-12-30 08:46:44 --> XSS Filtering completed
DEBUG - 2015-12-30 08:46:44 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:46:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:46:44 --> URI Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Router Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Output Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Security Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Input Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:46:44 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Language Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Config Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Loader Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:46:44 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:46:44 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Session Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:46:44 --> Session routines successfully run
DEBUG - 2015-12-30 08:46:44 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Email Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Controller Class Initialized
DEBUG - 2015-12-30 08:46:44 --> Admin MX_Controller Initialized
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:46:44 --> Model Class Initialized
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:46:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:46:44 --> Final output sent to browser
DEBUG - 2015-12-30 08:46:44 --> Total execution time: 0.2977
DEBUG - 2015-12-30 08:47:00 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:47:00 --> URI Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Router Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Output Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Security Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Input Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:47:00 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Loader Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:47:00 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:47:00 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Session Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:47:00 --> Session routines successfully run
DEBUG - 2015-12-30 08:47:00 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Email Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Controller Class Initialized
DEBUG - 2015-12-30 08:47:00 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:00 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:47:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:01 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-30 08:47:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:47:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:47:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:47:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:47:01 --> Final output sent to browser
DEBUG - 2015-12-30 08:47:01 --> Total execution time: 0.4482
DEBUG - 2015-12-30 08:47:04 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:47:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:47:04 --> URI Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Router Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Output Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Security Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Input Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:47:04 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Loader Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:47:04 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:47:04 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Session Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:47:04 --> Session routines successfully run
DEBUG - 2015-12-30 08:47:04 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Email Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Controller Class Initialized
DEBUG - 2015-12-30 08:47:04 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:47:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:04 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 08:47:04 --> Final output sent to browser
DEBUG - 2015-12-30 08:47:04 --> Total execution time: 0.3144
DEBUG - 2015-12-30 08:47:56 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:47:56 --> URI Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Router Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Output Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Security Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Input Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:47:56 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Loader Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:47:56 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:47:56 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Session Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:47:56 --> Session routines successfully run
DEBUG - 2015-12-30 08:47:56 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Email Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Controller Class Initialized
DEBUG - 2015-12-30 08:47:56 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:47:56 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:47:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:47:56 --> Final output sent to browser
DEBUG - 2015-12-30 08:47:56 --> Total execution time: 0.2574
DEBUG - 2015-12-30 08:47:58 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:47:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:47:58 --> URI Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Router Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Output Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Security Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Input Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:47:58 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Language Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Config Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Loader Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:47:58 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:47:58 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Session Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:47:58 --> Session routines successfully run
DEBUG - 2015-12-30 08:47:58 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Email Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Controller Class Initialized
DEBUG - 2015-12-30 08:47:58 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:47:58 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:47:59 --> Model Class Initialized
DEBUG - 2015-12-30 08:47:59 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 08:47:59 --> Final output sent to browser
DEBUG - 2015-12-30 08:47:59 --> Total execution time: 0.3343
DEBUG - 2015-12-30 08:48:19 --> Config Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:48:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:48:19 --> URI Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Router Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Output Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Security Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Input Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:48:19 --> Language Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Language Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Config Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Loader Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:48:19 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:48:19 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Session Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:48:19 --> Session routines successfully run
DEBUG - 2015-12-30 08:48:19 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Email Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Controller Class Initialized
DEBUG - 2015-12-30 08:48:19 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:48:19 --> Model Class Initialized
DEBUG - 2015-12-30 08:48:19 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 08:48:19 --> Final output sent to browser
DEBUG - 2015-12-30 08:48:19 --> Total execution time: 0.2123
DEBUG - 2015-12-30 08:49:27 --> Config Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:49:27 --> URI Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Router Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Output Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Security Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Input Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:49:27 --> Language Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Language Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Config Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Loader Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:49:27 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:49:27 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Session Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:49:27 --> Session routines successfully run
DEBUG - 2015-12-30 08:49:27 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Email Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Controller Class Initialized
DEBUG - 2015-12-30 08:49:27 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 08:49:27 --> Model Class Initialized
DEBUG - 2015-12-30 08:49:28 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 08:49:28 --> Final output sent to browser
DEBUG - 2015-12-30 08:49:28 --> Total execution time: 0.3444
DEBUG - 2015-12-30 08:51:00 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:51:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:51:00 --> URI Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Router Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Output Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Security Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Input Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:51:00 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Loader Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:51:00 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:51:00 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Session Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:51:00 --> Session routines successfully run
DEBUG - 2015-12-30 08:51:00 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Email Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Controller Class Initialized
DEBUG - 2015-12-30 08:51:00 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 08:51:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:51:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:51:01 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:01 --> Image Lib Class Initialized
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:51:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:51:01 --> Final output sent to browser
DEBUG - 2015-12-30 08:51:01 --> Total execution time: 0.6317
DEBUG - 2015-12-30 08:51:08 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:51:08 --> URI Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Router Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Output Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Security Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Input Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:51:08 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Loader Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:51:08 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:51:08 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Session Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:51:08 --> Session routines successfully run
DEBUG - 2015-12-30 08:51:08 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:51:08 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:51:09 --> Email Class Initialized
DEBUG - 2015-12-30 08:51:09 --> Controller Class Initialized
DEBUG - 2015-12-30 08:51:09 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:51:09 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:09 --> Image Lib Class Initialized
ERROR - 2015-12-30 08:51:09 --> Severity: Warning  --> Missing argument 2 for Property::edit_property() C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 120
ERROR - 2015-12-30 08:51:09 --> Severity: Notice  --> Undefined property: stdClass::$property_image_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 130
ERROR - 2015-12-30 08:51:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2015-12-30 08:51:09 --> Severity: Notice  --> Undefined property: stdClass::$property_image_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 135
ERROR - 2015-12-30 08:51:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:51:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:51:09 --> Final output sent to browser
DEBUG - 2015-12-30 08:51:09 --> Total execution time: 0.4362
DEBUG - 2015-12-30 08:51:17 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:51:17 --> URI Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Router Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Output Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Security Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Input Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:51:17 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Loader Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:51:17 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:51:17 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Session Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:51:17 --> Session routines successfully run
DEBUG - 2015-12-30 08:51:17 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Email Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Controller Class Initialized
DEBUG - 2015-12-30 08:51:17 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 08:51:17 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:51:17 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:51:17 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:51:18 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:18 --> Image Lib Class Initialized
ERROR - 2015-12-30 08:51:18 --> Severity: Warning  --> Missing argument 2 for Property::deactivate_property() C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 261
ERROR - 2015-12-30 08:51:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2015-12-30 08:51:18 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 272
ERROR - 2015-12-30 08:51:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\helpers\url_helper.php 543
DEBUG - 2015-12-30 08:51:24 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:51:24 --> URI Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Router Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Output Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Security Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Input Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:51:24 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Language Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Config Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Loader Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:51:24 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:51:24 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Session Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:51:24 --> Session routines successfully run
DEBUG - 2015-12-30 08:51:24 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Email Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Controller Class Initialized
DEBUG - 2015-12-30 08:51:24 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 08:51:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:51:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:51:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:51:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:24 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:51:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:51:25 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:51:25 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:51:25 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:51:25 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:51:25 --> Model Class Initialized
DEBUG - 2015-12-30 08:51:25 --> Image Lib Class Initialized
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:51:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:51:25 --> Final output sent to browser
DEBUG - 2015-12-30 08:51:25 --> Total execution time: 0.3460
DEBUG - 2015-12-30 08:53:04 --> Config Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:53:04 --> URI Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Router Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Output Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Security Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Input Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:53:04 --> Language Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Language Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Config Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Loader Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:53:04 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:53:04 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Session Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:53:04 --> Session routines successfully run
DEBUG - 2015-12-30 08:53:04 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Email Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Controller Class Initialized
DEBUG - 2015-12-30 08:53:04 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:53:04 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:53:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:53:04 --> Final output sent to browser
DEBUG - 2015-12-30 08:53:04 --> Total execution time: 0.6088
DEBUG - 2015-12-30 08:53:07 --> Config Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:53:07 --> URI Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Router Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Output Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Security Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Input Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:53:07 --> Language Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Language Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Config Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Loader Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:53:07 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:53:07 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Session Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:53:07 --> Session routines successfully run
DEBUG - 2015-12-30 08:53:07 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Email Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Controller Class Initialized
DEBUG - 2015-12-30 08:53:07 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:07 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:53:07 --> Model Class Initialized
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:53:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:53:08 --> Final output sent to browser
DEBUG - 2015-12-30 08:53:08 --> Total execution time: 0.6923
DEBUG - 2015-12-30 08:54:11 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:54:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:54:11 --> URI Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Router Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Output Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Security Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Input Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:54:11 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Loader Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:54:11 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:54:11 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Session Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:54:11 --> Session routines successfully run
DEBUG - 2015-12-30 08:54:11 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Email Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Controller Class Initialized
DEBUG - 2015-12-30 08:54:11 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:54:11 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:54:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:54:11 --> Final output sent to browser
DEBUG - 2015-12-30 08:54:11 --> Total execution time: 0.3597
DEBUG - 2015-12-30 08:54:39 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:54:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:54:39 --> URI Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Router Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Output Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Security Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Input Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:54:39 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Loader Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:54:39 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:54:39 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Session Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:54:39 --> Session routines successfully run
DEBUG - 2015-12-30 08:54:39 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Email Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Controller Class Initialized
DEBUG - 2015-12-30 08:54:39 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:54:39 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:54:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:54:39 --> Final output sent to browser
DEBUG - 2015-12-30 08:54:39 --> Total execution time: 0.2978
DEBUG - 2015-12-30 08:54:48 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:54:48 --> URI Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Router Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Output Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Security Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Input Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:54:48 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Language Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Config Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Loader Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:54:48 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:54:48 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Session Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:54:48 --> Session routines successfully run
DEBUG - 2015-12-30 08:54:48 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Email Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Controller Class Initialized
DEBUG - 2015-12-30 08:54:48 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:54:48 --> Model Class Initialized
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:54:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:54:48 --> Final output sent to browser
DEBUG - 2015-12-30 08:54:48 --> Total execution time: 0.2678
DEBUG - 2015-12-30 08:55:29 --> Config Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:55:29 --> URI Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Router Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Output Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Security Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Input Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:55:29 --> Language Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Language Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Config Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Loader Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:55:29 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:55:29 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Session Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:55:29 --> Session routines successfully run
DEBUG - 2015-12-30 08:55:29 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Email Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Controller Class Initialized
DEBUG - 2015-12-30 08:55:29 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:55:29 --> Model Class Initialized
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:55:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:55:29 --> Final output sent to browser
DEBUG - 2015-12-30 08:55:29 --> Total execution time: 0.2735
DEBUG - 2015-12-30 08:57:21 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:21 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:21 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:21 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:21 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:21 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:21 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:21 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:21 --> DB Transaction Failure
ERROR - 2015-12-30 08:57:21 --> Query error: Table 'rents.personnel_emergency' doesn't exist
DEBUG - 2015-12-30 08:57:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-30 08:57:31 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:31 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:31 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:31 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:31 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:31 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:31 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 08:57:31 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:31 --> Image Lib Class Initialized
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:57:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:57:31 --> Final output sent to browser
DEBUG - 2015-12-30 08:57:31 --> Total execution time: 0.2533
DEBUG - 2015-12-30 08:57:37 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:37 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:37 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:37 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:37 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:37 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:37 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:37 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:37 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/real_estate_administration/views/property_owners/all_property_owners.php
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:57:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:57:37 --> Final output sent to browser
DEBUG - 2015-12-30 08:57:37 --> Total execution time: 0.3042
DEBUG - 2015-12-30 08:57:40 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:40 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:40 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:41 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:41 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:41 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:41 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:41 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:41 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:41 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:41 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/real_estate_administration/views/property_owners/edit_property_owner.php
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:57:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:57:41 --> Final output sent to browser
DEBUG - 2015-12-30 08:57:41 --> Total execution time: 0.2464
DEBUG - 2015-12-30 08:57:45 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:45 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:45 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:45 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:45 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:45 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:45 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:45 --> Property_owners MX_Controller Initialized
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:45 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/real_estate_administration/views/property_owners/edit_property_owner.php
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:57:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:57:45 --> Final output sent to browser
DEBUG - 2015-12-30 08:57:45 --> Total execution time: 0.2453
DEBUG - 2015-12-30 08:57:55 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:55 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:55 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:55 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:55 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:55 --> Session routines successfully run
DEBUG - 2015-12-30 08:57:55 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Email Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Controller Class Initialized
DEBUG - 2015-12-30 08:57:55 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:57:55 --> Model Class Initialized
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:57:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:57:55 --> Final output sent to browser
DEBUG - 2015-12-30 08:57:55 --> Total execution time: 0.3039
DEBUG - 2015-12-30 08:57:59 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:57:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:57:59 --> URI Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Router Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Output Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Security Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Input Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:57:59 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Language Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Config Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Loader Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:57:59 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:57:59 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Session Class Initialized
DEBUG - 2015-12-30 08:57:59 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:57:59 --> Session routines successfully run
DEBUG - 2015-12-30 08:58:00 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:58:00 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:58:00 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:58:00 --> Email Class Initialized
DEBUG - 2015-12-30 08:58:00 --> Controller Class Initialized
DEBUG - 2015-12-30 08:58:00 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:58:00 --> Model Class Initialized
DEBUG - 2015-12-30 08:58:00 --> DB Transaction Failure
ERROR - 2015-12-30 08:58:00 --> Query error: Table 'rents.personnel_emergency' doesn't exist
DEBUG - 2015-12-30 08:58:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-30 08:59:05 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:59:05 --> URI Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Router Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Output Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Security Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Input Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:59:05 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Loader Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:59:05 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:59:05 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Session Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:59:05 --> Session routines successfully run
DEBUG - 2015-12-30 08:59:05 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Email Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Controller Class Initialized
DEBUG - 2015-12-30 08:59:05 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:05 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:59:05 --> Model Class Initialized
ERROR - 2015-12-30 08:59:05 --> Severity: Notice  --> Undefined variable: personnel C:\xampp\htdocs\rents\application\modules\hr\views\personnel\edit_personnel.php 3
DEBUG - 2015-12-30 08:59:24 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:59:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:59:24 --> URI Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Router Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Output Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Security Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Input Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:59:24 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Loader Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:59:24 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:59:24 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Session Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:59:24 --> Session routines successfully run
DEBUG - 2015-12-30 08:59:24 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Email Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Controller Class Initialized
DEBUG - 2015-12-30 08:59:24 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:59:24 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:24 --> File loaded: application/modules/hr/views/personnel/edit/about.php
ERROR - 2015-12-30 08:59:24 --> Severity: Notice  --> Undefined variable: roles C:\xampp\htdocs\rents\application\modules\hr\views\personnel\edit\account.php 246
DEBUG - 2015-12-30 08:59:51 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Utf8 Class Initialized
DEBUG - 2015-12-30 08:59:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 08:59:51 --> URI Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Router Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Output Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Security Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Input Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 08:59:51 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Language Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Config Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Loader Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Helper loaded: url_helper
DEBUG - 2015-12-30 08:59:51 --> Helper loaded: form_helper
DEBUG - 2015-12-30 08:59:51 --> Database Driver Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Session Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Helper loaded: string_helper
DEBUG - 2015-12-30 08:59:51 --> Session routines successfully run
DEBUG - 2015-12-30 08:59:51 --> Form Validation Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Pagination Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Encrypt Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Email Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Controller Class Initialized
DEBUG - 2015-12-30 08:59:51 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 08:59:51 --> Model Class Initialized
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 08:59:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 08:59:51 --> Final output sent to browser
DEBUG - 2015-12-30 08:59:51 --> Total execution time: 0.2748
DEBUG - 2015-12-30 14:13:39 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:40 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:40 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:40 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:40 --> Router Class Initialized
DEBUG - 2015-12-30 14:13:41 --> Output Class Initialized
DEBUG - 2015-12-30 14:13:41 --> Security Class Initialized
DEBUG - 2015-12-30 14:13:41 --> Input Class Initialized
DEBUG - 2015-12-30 14:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:13:41 --> Language Class Initialized
DEBUG - 2015-12-30 14:13:42 --> Language Class Initialized
DEBUG - 2015-12-30 14:13:42 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:42 --> Loader Class Initialized
DEBUG - 2015-12-30 14:13:42 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:13:43 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:13:43 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:13:45 --> Session Class Initialized
DEBUG - 2015-12-30 14:13:45 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:13:45 --> A session cookie was not found.
DEBUG - 2015-12-30 14:13:45 --> Session routines successfully run
DEBUG - 2015-12-30 14:13:45 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:13:46 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:13:46 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:13:46 --> Email Class Initialized
DEBUG - 2015-12-30 14:13:46 --> Controller Class Initialized
DEBUG - 2015-12-30 14:13:46 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-30 14:13:46 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 14:13:46 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:13:46 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:47 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-30 14:13:47 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:48 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-30 14:13:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:48 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-30 14:13:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:48 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Router Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Output Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Security Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Input Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:13:48 --> Language Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Language Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Loader Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:13:48 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:13:48 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Session Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:13:48 --> Session routines successfully run
DEBUG - 2015-12-30 14:13:48 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Email Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Controller Class Initialized
DEBUG - 2015-12-30 14:13:48 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 14:13:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 14:13:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:13:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:13:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 14:13:49 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-30 14:13:49 --> Final output sent to browser
DEBUG - 2015-12-30 14:13:49 --> Total execution time: 1.2884
DEBUG - 2015-12-30 14:13:57 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:57 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:57 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Router Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Config Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Config Class Initialized
ERROR - 2015-12-30 14:13:57 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:57 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:13:57 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:13:57 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Router Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Router Class Initialized
DEBUG - 2015-12-30 14:13:57 --> URI Class Initialized
DEBUG - 2015-12-30 14:13:57 --> Router Class Initialized
ERROR - 2015-12-30 14:13:57 --> 404 Page Not Found --> 
ERROR - 2015-12-30 14:13:57 --> 404 Page Not Found --> 
ERROR - 2015-12-30 14:13:57 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 14:31:26 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:31:26 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:31:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:31:27 --> URI Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Router Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Output Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Security Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Input Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:31:27 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Loader Class Initialized
DEBUG - 2015-12-30 14:31:27 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:31:27 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:31:27 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:31:28 --> Session Class Initialized
DEBUG - 2015-12-30 14:31:28 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:31:28 --> Session routines successfully run
DEBUG - 2015-12-30 14:31:29 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Email Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Controller Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 14:31:29 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 14:31:29 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:31:29 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-30 14:31:29 --> XSS Filtering completed
DEBUG - 2015-12-30 14:31:29 --> Unable to find validation rule: exists
DEBUG - 2015-12-30 14:31:29 --> XSS Filtering completed
DEBUG - 2015-12-30 14:31:30 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:31:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:31:30 --> URI Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Router Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Output Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Security Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Input Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:31:30 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Loader Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:31:30 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:31:30 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Session Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:31:30 --> Session routines successfully run
DEBUG - 2015-12-30 14:31:30 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Email Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Controller Class Initialized
DEBUG - 2015-12-30 14:31:30 --> Admin MX_Controller Initialized
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 14:31:30 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:31 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-30 14:31:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 14:31:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 14:31:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 14:31:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 14:31:31 --> Final output sent to browser
DEBUG - 2015-12-30 14:31:31 --> Total execution time: 1.7990
DEBUG - 2015-12-30 14:31:47 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:31:47 --> URI Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Router Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Output Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Security Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Input Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:31:47 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Loader Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:31:47 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:31:47 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Session Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:31:47 --> Session routines successfully run
DEBUG - 2015-12-30 14:31:47 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:31:47 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:31:48 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:31:48 --> Email Class Initialized
DEBUG - 2015-12-30 14:31:48 --> Controller Class Initialized
DEBUG - 2015-12-30 14:31:48 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:31:48 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/water_management/views/water_records.php
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 14:31:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 14:31:48 --> Final output sent to browser
DEBUG - 2015-12-30 14:31:49 --> Total execution time: 1.2528
DEBUG - 2015-12-30 14:31:51 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:31:51 --> URI Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Router Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Output Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Security Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Input Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:31:51 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Language Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Config Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Loader Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:31:51 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:31:51 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Session Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:31:51 --> Session routines successfully run
DEBUG - 2015-12-30 14:31:51 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Email Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Controller Class Initialized
DEBUG - 2015-12-30 14:31:51 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:31:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:51 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:31:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:31:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:31:52 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:31:52 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:31:52 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:31:52 --> Model Class Initialized
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:31:52 --> Model Class Initialized
ERROR - 2015-12-30 14:31:52 --> Severity: Notice  --> Undefined variable: dis C:\xampp\htdocs\rents\application\modules\water_management\views\reading_reports.php 748
ERROR - 2015-12-30 14:31:52 --> Severity: Notice  --> Undefined variable: dis C:\xampp\htdocs\rents\application\modules\water_management\views\reading_reports.php 748
DEBUG - 2015-12-30 14:31:52 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:31:52 --> Final output sent to browser
DEBUG - 2015-12-30 14:31:52 --> Total execution time: 0.4630
DEBUG - 2015-12-30 14:32:04 --> Config Class Initialized
DEBUG - 2015-12-30 14:32:04 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:32:04 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:32:04 --> URI Class Initialized
DEBUG - 2015-12-30 14:32:04 --> Router Class Initialized
DEBUG - 2015-12-30 14:32:04 --> Output Class Initialized
DEBUG - 2015-12-30 14:32:04 --> Security Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Input Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:32:05 --> Language Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Language Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Config Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Loader Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:32:05 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:32:05 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Session Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:32:05 --> Session routines successfully run
DEBUG - 2015-12-30 14:32:05 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Email Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Controller Class Initialized
DEBUG - 2015-12-30 14:32:05 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:32:05 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:05 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:32:05 --> Final output sent to browser
DEBUG - 2015-12-30 14:32:05 --> Total execution time: 0.2681
DEBUG - 2015-12-30 14:32:37 --> Config Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:32:37 --> URI Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Router Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Output Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Security Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Input Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:32:37 --> Language Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Language Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Config Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Loader Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:32:37 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:32:37 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Session Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:32:37 --> Session routines successfully run
DEBUG - 2015-12-30 14:32:37 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Email Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Controller Class Initialized
DEBUG - 2015-12-30 14:32:37 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:32:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:32:37 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:32:37 --> Final output sent to browser
DEBUG - 2015-12-30 14:32:37 --> Total execution time: 0.5646
DEBUG - 2015-12-30 14:37:19 --> Config Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:37:20 --> URI Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Router Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Output Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Security Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Input Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:37:20 --> Language Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Language Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Config Class Initialized
DEBUG - 2015-12-30 14:37:20 --> Loader Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:37:21 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:37:21 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Session Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:37:21 --> Session routines successfully run
DEBUG - 2015-12-30 14:37:21 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Email Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Controller Class Initialized
DEBUG - 2015-12-30 14:37:21 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:37:21 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:21 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:37:21 --> Final output sent to browser
DEBUG - 2015-12-30 14:37:21 --> Total execution time: 1.8005
DEBUG - 2015-12-30 14:37:37 --> Config Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:37:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:37:37 --> URI Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Router Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Output Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Security Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Input Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:37:37 --> Language Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Language Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Config Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Loader Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:37:37 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:37:37 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Session Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:37:37 --> Session routines successfully run
DEBUG - 2015-12-30 14:37:37 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Email Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Controller Class Initialized
DEBUG - 2015-12-30 14:37:37 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:37:37 --> Model Class Initialized
DEBUG - 2015-12-30 14:37:37 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:37:37 --> Final output sent to browser
DEBUG - 2015-12-30 14:37:37 --> Total execution time: 0.2152
DEBUG - 2015-12-30 14:38:03 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:38:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:38:03 --> URI Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Router Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Output Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Security Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Input Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:38:03 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Loader Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:38:03 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:38:03 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Session Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:38:03 --> Session routines successfully run
DEBUG - 2015-12-30 14:38:03 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Email Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Controller Class Initialized
DEBUG - 2015-12-30 14:38:03 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:38:03 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:03 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:38:03 --> Final output sent to browser
DEBUG - 2015-12-30 14:38:03 --> Total execution time: 0.1969
DEBUG - 2015-12-30 14:38:26 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:26 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:38:26 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:38:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:38:26 --> URI Class Initialized
DEBUG - 2015-12-30 14:38:26 --> Router Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Output Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Security Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Input Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:38:27 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Loader Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:38:27 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:38:27 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Session Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:38:27 --> Session routines successfully run
DEBUG - 2015-12-30 14:38:27 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Email Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Controller Class Initialized
DEBUG - 2015-12-30 14:38:27 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:38:27 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:27 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:38:27 --> Final output sent to browser
DEBUG - 2015-12-30 14:38:27 --> Total execution time: 0.5005
DEBUG - 2015-12-30 14:38:51 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:38:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:38:51 --> URI Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Router Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Output Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Security Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Input Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:38:51 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Language Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Config Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Loader Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:38:51 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:38:51 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Session Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:38:51 --> Session routines successfully run
DEBUG - 2015-12-30 14:38:51 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Email Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Controller Class Initialized
DEBUG - 2015-12-30 14:38:51 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:38:51 --> Model Class Initialized
DEBUG - 2015-12-30 14:38:51 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:38:51 --> Final output sent to browser
DEBUG - 2015-12-30 14:38:51 --> Total execution time: 0.2412
DEBUG - 2015-12-30 14:39:38 --> Config Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:39:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:39:38 --> URI Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Router Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Output Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Security Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Input Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:39:38 --> Language Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Language Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Config Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Loader Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:39:38 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:39:38 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Session Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:39:38 --> Session routines successfully run
DEBUG - 2015-12-30 14:39:38 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Email Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Controller Class Initialized
DEBUG - 2015-12-30 14:39:38 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:39:38 --> Model Class Initialized
DEBUG - 2015-12-30 14:39:38 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:39:38 --> Final output sent to browser
DEBUG - 2015-12-30 14:39:38 --> Total execution time: 0.2372
DEBUG - 2015-12-30 14:40:01 --> Config Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:40:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:40:01 --> URI Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Router Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Output Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Security Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Input Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:40:01 --> Language Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Language Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Config Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Loader Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:40:01 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:40:01 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Session Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:40:01 --> Session routines successfully run
DEBUG - 2015-12-30 14:40:01 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Email Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Controller Class Initialized
DEBUG - 2015-12-30 14:40:01 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:40:01 --> Model Class Initialized
DEBUG - 2015-12-30 14:40:01 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:40:01 --> Final output sent to browser
DEBUG - 2015-12-30 14:40:01 --> Total execution time: 0.2121
DEBUG - 2015-12-30 14:44:32 --> Config Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Hooks Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Utf8 Class Initialized
DEBUG - 2015-12-30 14:44:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 14:44:32 --> URI Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Router Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Output Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Security Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Input Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 14:44:32 --> Language Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Language Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Config Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Loader Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Helper loaded: url_helper
DEBUG - 2015-12-30 14:44:32 --> Helper loaded: form_helper
DEBUG - 2015-12-30 14:44:32 --> Database Driver Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Session Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Helper loaded: string_helper
DEBUG - 2015-12-30 14:44:32 --> Session routines successfully run
DEBUG - 2015-12-30 14:44:32 --> Form Validation Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Pagination Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Encrypt Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Email Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Controller Class Initialized
DEBUG - 2015-12-30 14:44:32 --> Water_management MX_Controller Initialized
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:32 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2015-12-30 14:44:32 --> Model Class Initialized
DEBUG - 2015-12-30 14:44:33 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2015-12-30 14:44:33 --> Final output sent to browser
DEBUG - 2015-12-30 14:44:33 --> Total execution time: 0.2734
DEBUG - 2015-12-30 18:13:33 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:33 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:33 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:33 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:33 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:34 --> No URI present. Default controller set.
DEBUG - 2015-12-30 18:13:34 --> Output Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Security Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Input Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:13:34 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Loader Class Initialized
DEBUG - 2015-12-30 18:13:34 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:13:34 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:13:34 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Session Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:13:35 --> A session cookie was not found.
DEBUG - 2015-12-30 18:13:35 --> Session routines successfully run
DEBUG - 2015-12-30 18:13:35 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Email Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Controller Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 18:13:35 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:13:35 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:13:35 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:35 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Output Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Security Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Input Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:13:35 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Loader Class Initialized
DEBUG - 2015-12-30 18:13:35 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:13:35 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:13:36 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Session Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:13:36 --> Session routines successfully run
DEBUG - 2015-12-30 18:13:36 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Email Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Controller Class Initialized
DEBUG - 2015-12-30 18:13:36 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 18:13:36 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:13:36 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:13:36 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:13:36 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-30 18:13:36 --> Final output sent to browser
DEBUG - 2015-12-30 18:13:36 --> Total execution time: 0.9428
DEBUG - 2015-12-30 18:13:46 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:46 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:46 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Config Class Initialized
ERROR - 2015-12-30 18:13:46 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:46 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Router Class Initialized
ERROR - 2015-12-30 18:13:46 --> 404 Page Not Found --> 
ERROR - 2015-12-30 18:13:46 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:46 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:46 --> Router Class Initialized
ERROR - 2015-12-30 18:13:46 --> 404 Page Not Found --> 
DEBUG - 2015-12-30 18:13:52 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:52 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Output Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Security Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Input Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:13:52 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Loader Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:13:52 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:13:52 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Session Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:13:52 --> Session routines successfully run
DEBUG - 2015-12-30 18:13:52 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Email Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Controller Class Initialized
DEBUG - 2015-12-30 18:13:52 --> Auth MX_Controller Initialized
DEBUG - 2015-12-30 18:13:52 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:13:52 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:13:52 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-30 18:13:53 --> XSS Filtering completed
DEBUG - 2015-12-30 18:13:53 --> Unable to find validation rule: exists
DEBUG - 2015-12-30 18:13:53 --> XSS Filtering completed
DEBUG - 2015-12-30 18:13:53 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:13:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:13:53 --> URI Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Router Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Output Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Security Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Input Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:13:53 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Language Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Config Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Loader Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:13:53 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:13:53 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Session Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:13:53 --> Session routines successfully run
DEBUG - 2015-12-30 18:13:53 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Email Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Controller Class Initialized
DEBUG - 2015-12-30 18:13:53 --> Admin MX_Controller Initialized
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:13:53 --> Model Class Initialized
DEBUG - 2015-12-30 18:13:53 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-30 18:13:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:13:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:13:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:13:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:13:55 --> Final output sent to browser
DEBUG - 2015-12-30 18:13:55 --> Total execution time: 2.0862
DEBUG - 2015-12-30 18:14:03 --> Config Class Initialized
DEBUG - 2015-12-30 18:14:03 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:14:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:14:04 --> URI Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Router Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Output Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Security Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Input Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:14:04 --> Language Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Language Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Config Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Loader Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:14:04 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:14:04 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Session Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:14:04 --> Session routines successfully run
DEBUG - 2015-12-30 18:14:04 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Email Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Controller Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:14:04 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:04 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:14:05 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:14:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:14:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:14:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:14:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:14:05 --> Final output sent to browser
DEBUG - 2015-12-30 18:14:05 --> Total execution time: 1.2109
DEBUG - 2015-12-30 18:14:07 --> Config Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:14:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:14:07 --> URI Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Router Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Output Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Security Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Input Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:14:07 --> Language Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Language Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Config Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Loader Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:14:07 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:14:07 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Session Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:14:07 --> Session routines successfully run
DEBUG - 2015-12-30 18:14:07 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Email Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Controller Class Initialized
DEBUG - 2015-12-30 18:14:07 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:14:07 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:14:07 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:14:07 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:14:07 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:07 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:14:07 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:14:08 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:14:08 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:14:08 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:14:08 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:14:08 --> Model Class Initialized
DEBUG - 2015-12-30 18:14:08 --> Image Lib Class Initialized
ERROR - 2015-12-30 18:14:08 --> Severity: Warning  --> Missing argument 2 for Property::edit_property() C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 120
ERROR - 2015-12-30 18:14:08 --> Severity: Notice  --> Undefined property: stdClass::$property_image_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 130
ERROR - 2015-12-30 18:14:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
ERROR - 2015-12-30 18:14:08 --> Severity: Notice  --> Undefined property: stdClass::$property_image_name C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 135
ERROR - 2015-12-30 18:14:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\rents\system\core\Exceptions.php:186) C:\xampp\htdocs\rents\system\libraries\Session.php 689
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:14:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:14:08 --> Final output sent to browser
DEBUG - 2015-12-30 18:14:08 --> Total execution time: 0.3573
DEBUG - 2015-12-30 18:15:34 --> Config Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:15:34 --> URI Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Router Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Output Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Security Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Input Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:15:34 --> Language Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Language Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Config Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Loader Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:15:34 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:15:34 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Session Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:15:34 --> Session routines successfully run
DEBUG - 2015-12-30 18:15:34 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Email Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Controller Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:15:34 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:34 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:15:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:15:34 --> Final output sent to browser
DEBUG - 2015-12-30 18:15:34 --> Total execution time: 0.2794
DEBUG - 2015-12-30 18:15:48 --> Config Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:15:48 --> URI Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Router Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Output Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Security Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Input Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:15:48 --> Language Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Language Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Config Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Loader Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:15:48 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:15:48 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Session Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:15:48 --> Session routines successfully run
DEBUG - 2015-12-30 18:15:48 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Email Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Controller Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:15:48 --> Model Class Initialized
DEBUG - 2015-12-30 18:15:48 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:15:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:15:48 --> Final output sent to browser
DEBUG - 2015-12-30 18:15:48 --> Total execution time: 0.2229
DEBUG - 2015-12-30 18:16:02 --> Config Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:16:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:16:02 --> URI Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Router Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Output Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Security Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Input Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:16:02 --> Language Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Language Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Config Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Loader Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:16:02 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:16:02 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Session Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:16:02 --> Session routines successfully run
DEBUG - 2015-12-30 18:16:02 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Email Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Controller Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:16:02 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:02 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:16:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:16:02 --> Final output sent to browser
DEBUG - 2015-12-30 18:16:02 --> Total execution time: 0.2207
DEBUG - 2015-12-30 18:16:58 --> Config Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:16:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:16:58 --> URI Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Router Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Output Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Security Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Input Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:16:58 --> Language Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Language Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Config Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Loader Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:16:58 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:16:58 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Session Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:16:58 --> Session routines successfully run
DEBUG - 2015-12-30 18:16:58 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Email Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Controller Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:16:58 --> Model Class Initialized
DEBUG - 2015-12-30 18:16:58 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:16:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:16:58 --> Final output sent to browser
DEBUG - 2015-12-30 18:16:58 --> Total execution time: 0.2347
DEBUG - 2015-12-30 18:18:44 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:18:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:18:44 --> URI Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Router Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Output Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Security Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Input Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:18:44 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Loader Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:18:44 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:18:44 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Session Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:18:44 --> Session routines successfully run
DEBUG - 2015-12-30 18:18:44 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Email Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Controller Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:18:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:44 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:18:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:18:44 --> Final output sent to browser
DEBUG - 2015-12-30 18:18:44 --> Total execution time: 0.2382
DEBUG - 2015-12-30 18:18:55 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:18:55 --> URI Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Router Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Output Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Security Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Input Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:18:55 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Loader Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:18:55 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Session Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:18:55 --> Session routines successfully run
DEBUG - 2015-12-30 18:18:55 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Email Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Controller Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:18:55 --> URI Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Router Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Output Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Security Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Input Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:18:55 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Loader Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:18:55 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Session Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:18:55 --> Session routines successfully run
DEBUG - 2015-12-30 18:18:55 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Email Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Controller Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:18:55 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:55 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:18:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:18:55 --> Final output sent to browser
DEBUG - 2015-12-30 18:18:55 --> Total execution time: 0.2552
DEBUG - 2015-12-30 18:18:59 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:18:59 --> URI Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Router Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Output Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Security Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Input Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:18:59 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Loader Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:18:59 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Session Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:18:59 --> Session routines successfully run
DEBUG - 2015-12-30 18:18:59 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Email Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Controller Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:18:59 --> URI Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Router Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Output Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Security Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Input Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:18:59 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Language Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Config Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Loader Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:18:59 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Session Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:18:59 --> Session routines successfully run
DEBUG - 2015-12-30 18:18:59 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Email Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Controller Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:18:59 --> Model Class Initialized
DEBUG - 2015-12-30 18:18:59 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:18:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:18:59 --> Final output sent to browser
DEBUG - 2015-12-30 18:18:59 --> Total execution time: 0.2361
DEBUG - 2015-12-30 18:21:12 --> Config Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:21:12 --> URI Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Router Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Output Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Security Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Input Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:21:12 --> Language Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Language Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Config Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Loader Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:21:12 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Session Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:21:12 --> Session routines successfully run
DEBUG - 2015-12-30 18:21:12 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Email Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Controller Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:21:12 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:12 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:21:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:21:12 --> Final output sent to browser
DEBUG - 2015-12-30 18:21:12 --> Total execution time: 0.2241
DEBUG - 2015-12-30 18:21:14 --> Config Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:21:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:21:14 --> URI Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Router Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Output Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Security Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Input Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:21:14 --> Language Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Language Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Config Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Loader Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:21:14 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:21:14 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Session Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:21:14 --> Session routines successfully run
DEBUG - 2015-12-30 18:21:14 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Email Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Controller Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:21:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:21:14 --> Image Lib Class Initialized
ERROR - 2015-12-30 18:21:14 --> Severity: Warning  --> Missing argument 2 for Property::edit_property() C:\xampp\htdocs\rents\application\modules\real_estate_administration\controllers\property.php 120
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:21:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:21:14 --> Final output sent to browser
DEBUG - 2015-12-30 18:21:14 --> Total execution time: 0.2338
DEBUG - 2015-12-30 18:23:43 --> Config Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:23:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:23:43 --> URI Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Router Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Output Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Security Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Input Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:23:43 --> Language Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Language Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Config Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Loader Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:23:43 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:23:43 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Session Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:23:43 --> Session routines successfully run
DEBUG - 2015-12-30 18:23:43 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Email Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Controller Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:23:43 --> Model Class Initialized
DEBUG - 2015-12-30 18:23:43 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:23:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:23:43 --> Final output sent to browser
DEBUG - 2015-12-30 18:23:43 --> Total execution time: 0.3081
DEBUG - 2015-12-30 18:26:14 --> Config Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:26:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:26:14 --> URI Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Router Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Output Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Security Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Input Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:26:14 --> Language Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Language Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Config Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Loader Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:26:14 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:26:14 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Session Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:26:14 --> Session routines successfully run
DEBUG - 2015-12-30 18:26:14 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Email Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Controller Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:26:14 --> Model Class Initialized
DEBUG - 2015-12-30 18:26:14 --> Image Lib Class Initialized
ERROR - 2015-12-30 18:26:14 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 5
ERROR - 2015-12-30 18:26:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 5
ERROR - 2015-12-30 18:26:14 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 12
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:26:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:26:14 --> Final output sent to browser
DEBUG - 2015-12-30 18:26:14 --> Total execution time: 0.2489
DEBUG - 2015-12-30 18:27:31 --> Config Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:27:31 --> URI Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Router Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Output Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Security Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Input Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:27:31 --> Language Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Language Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Config Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Loader Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:27:31 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:27:31 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Session Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:27:31 --> Session routines successfully run
DEBUG - 2015-12-30 18:27:31 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Email Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Controller Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:27:31 --> Model Class Initialized
DEBUG - 2015-12-30 18:27:31 --> Image Lib Class Initialized
ERROR - 2015-12-30 18:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 3
ERROR - 2015-12-30 18:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 4
ERROR - 2015-12-30 18:27:31 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\rents\application\modules\real_estate_administration\views\property\edit_property.php 19
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/real_estate_administration/views/property/edit_property.php
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-30 18:27:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-30 18:27:31 --> Final output sent to browser
DEBUG - 2015-12-30 18:27:31 --> Total execution time: 0.2425
DEBUG - 2015-12-30 18:28:21 --> Config Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:28:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:28:21 --> URI Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Router Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Output Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Security Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Input Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:28:21 --> Language Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Language Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Config Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Loader Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:28:21 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:28:21 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Session Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:28:21 --> Session routines successfully run
DEBUG - 2015-12-30 18:28:21 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Email Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Controller Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:28:21 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:21 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Config Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:28:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:28:46 --> URI Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Router Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Output Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Security Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Input Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:28:46 --> Language Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Language Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Config Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Loader Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:28:46 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:28:46 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Session Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:28:46 --> Session routines successfully run
DEBUG - 2015-12-30 18:28:46 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Email Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Controller Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:28:46 --> Model Class Initialized
DEBUG - 2015-12-30 18:28:46 --> Image Lib Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Config Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Hooks Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Utf8 Class Initialized
DEBUG - 2015-12-30 18:51:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-30 18:51:44 --> URI Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Router Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Output Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Security Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Input Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-30 18:51:44 --> Language Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Language Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Config Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Loader Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Helper loaded: url_helper
DEBUG - 2015-12-30 18:51:44 --> Helper loaded: form_helper
DEBUG - 2015-12-30 18:51:44 --> Database Driver Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Session Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Helper loaded: string_helper
DEBUG - 2015-12-30 18:51:44 --> Session routines successfully run
DEBUG - 2015-12-30 18:51:44 --> Form Validation Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Pagination Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Encrypt Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Email Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Controller Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Property MX_Controller Initialized
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2015-12-30 18:51:44 --> Model Class Initialized
DEBUG - 2015-12-30 18:51:44 --> Image Lib Class Initialized
