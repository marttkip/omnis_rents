<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-18 13:26:40 --> Config Class Initialized
DEBUG - 2016-02-18 13:26:40 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:26:40 --> Utf8 Class Initialized
DEBUG - 2016-02-18 13:26:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 13:26:40 --> URI Class Initialized
DEBUG - 2016-02-18 13:26:40 --> Router Class Initialized
DEBUG - 2016-02-18 13:26:41 --> No URI present. Default controller set.
DEBUG - 2016-02-18 13:26:41 --> Output Class Initialized
DEBUG - 2016-02-18 13:26:41 --> Security Class Initialized
DEBUG - 2016-02-18 13:26:41 --> Input Class Initialized
DEBUG - 2016-02-18 13:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-18 13:26:41 --> Language Class Initialized
DEBUG - 2016-02-18 13:26:42 --> Language Class Initialized
DEBUG - 2016-02-18 13:26:42 --> Config Class Initialized
DEBUG - 2016-02-18 13:26:42 --> Loader Class Initialized
DEBUG - 2016-02-18 13:26:42 --> Helper loaded: url_helper
DEBUG - 2016-02-18 13:26:42 --> Helper loaded: form_helper
DEBUG - 2016-02-18 13:26:43 --> Database Driver Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Session Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Helper loaded: string_helper
DEBUG - 2016-02-18 13:26:46 --> A session cookie was not found.
DEBUG - 2016-02-18 13:26:46 --> Session routines successfully run
DEBUG - 2016-02-18 13:26:46 --> Form Validation Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Pagination Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Encrypt Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Email Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Controller Class Initialized
DEBUG - 2016-02-18 13:26:46 --> Auth MX_Controller Initialized
DEBUG - 2016-02-18 13:26:46 --> Model Class Initialized
DEBUG - 2016-02-18 13:26:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-18 13:26:46 --> Model Class Initialized
DEBUG - 2016-02-18 13:26:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-18 13:26:47 --> Model Class Initialized
DEBUG - 2016-02-18 21:52:46 --> Config Class Initialized
DEBUG - 2016-02-18 21:52:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:46 --> Utf8 Class Initialized
DEBUG - 2016-02-18 21:52:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 21:52:46 --> URI Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Router Class Initialized
DEBUG - 2016-02-18 21:52:47 --> No URI present. Default controller set.
DEBUG - 2016-02-18 21:52:47 --> Output Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Input Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-18 21:52:47 --> Language Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Language Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Config Class Initialized
DEBUG - 2016-02-18 21:52:47 --> Loader Class Initialized
DEBUG - 2016-02-18 21:52:48 --> Helper loaded: url_helper
DEBUG - 2016-02-18 21:52:48 --> Helper loaded: form_helper
DEBUG - 2016-02-18 21:52:48 --> Database Driver Class Initialized
DEBUG - 2016-02-18 21:52:49 --> Session Class Initialized
DEBUG - 2016-02-18 21:52:49 --> Helper loaded: string_helper
DEBUG - 2016-02-18 21:52:49 --> A session cookie was not found.
DEBUG - 2016-02-18 21:52:49 --> Session routines successfully run
DEBUG - 2016-02-18 21:52:49 --> Form Validation Class Initialized
DEBUG - 2016-02-18 21:52:49 --> Pagination Class Initialized
DEBUG - 2016-02-18 21:52:49 --> Encrypt Class Initialized
DEBUG - 2016-02-18 21:52:50 --> Email Class Initialized
DEBUG - 2016-02-18 21:52:50 --> Controller Class Initialized
DEBUG - 2016-02-18 21:52:50 --> Auth MX_Controller Initialized
DEBUG - 2016-02-18 21:52:50 --> Model Class Initialized
DEBUG - 2016-02-18 21:52:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-18 21:52:50 --> Model Class Initialized
DEBUG - 2016-02-18 21:52:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-18 21:52:50 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:25 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:26 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Router Class Initialized
DEBUG - 2016-02-18 22:26:26 --> No URI present. Default controller set.
DEBUG - 2016-02-18 22:26:26 --> Output Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Security Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Input Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-18 22:26:26 --> Language Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Language Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Loader Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Helper loaded: url_helper
DEBUG - 2016-02-18 22:26:26 --> Helper loaded: form_helper
DEBUG - 2016-02-18 22:26:26 --> Database Driver Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Session Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Helper loaded: string_helper
DEBUG - 2016-02-18 22:26:26 --> A session cookie was not found.
DEBUG - 2016-02-18 22:26:26 --> Session routines successfully run
DEBUG - 2016-02-18 22:26:26 --> Form Validation Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Pagination Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Encrypt Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Email Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Controller Class Initialized
DEBUG - 2016-02-18 22:26:26 --> Auth MX_Controller Initialized
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:27 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Router Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Output Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Security Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Input Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-18 22:26:27 --> Language Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Language Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Loader Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Helper loaded: url_helper
DEBUG - 2016-02-18 22:26:27 --> Helper loaded: form_helper
DEBUG - 2016-02-18 22:26:27 --> Database Driver Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Session Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Helper loaded: string_helper
DEBUG - 2016-02-18 22:26:27 --> Session routines successfully run
DEBUG - 2016-02-18 22:26:27 --> Form Validation Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Pagination Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Encrypt Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Email Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Controller Class Initialized
DEBUG - 2016-02-18 22:26:27 --> Auth MX_Controller Initialized
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-18 22:26:27 --> Model Class Initialized
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-18 22:26:27 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-18 22:26:27 --> Final output sent to browser
DEBUG - 2016-02-18 22:26:27 --> Total execution time: 0.7641
DEBUG - 2016-02-18 22:26:29 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:29 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Router Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:29 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Router Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:29 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Config Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Hooks Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Utf8 Class Initialized
DEBUG - 2016-02-18 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-02-18 22:26:29 --> URI Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Router Class Initialized
DEBUG - 2016-02-18 22:26:29 --> Router Class Initialized
ERROR - 2016-02-18 22:26:29 --> 404 Page Not Found --> 
ERROR - 2016-02-18 22:26:29 --> 404 Page Not Found --> 
ERROR - 2016-02-18 22:26:29 --> 404 Page Not Found --> 
ERROR - 2016-02-18 22:26:29 --> 404 Page Not Found --> 
