<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-08 09:54:40 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:40 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Output Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Security Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Input Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:54:40 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Loader Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:54:40 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:54:40 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 09:54:40 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:54:40 --> Session Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:54:40 --> A session cookie was not found.
DEBUG - 2015-10-08 09:54:40 --> Session routines successfully run
DEBUG - 2015-10-08 09:54:40 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Email Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Controller Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:54:40 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:40 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Output Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Security Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Input Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:54:40 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:40 --> Loader Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:54:41 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:54:41 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:54:41 --> Session Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:54:41 --> Session routines successfully run
DEBUG - 2015-10-08 09:54:41 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Email Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Controller Class Initialized
DEBUG - 2015-10-08 09:54:41 --> Auth MX_Controller Initialized
DEBUG - 2015-10-08 09:54:41 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:54:41 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:54:41 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:54:41 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-08 09:54:41 --> Final output sent to browser
DEBUG - 2015-10-08 09:54:41 --> Total execution time: 0.1231
DEBUG - 2015-10-08 09:54:42 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:42 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:42 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:42 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:42 --> UTF-8 Support Enabled
ERROR - 2015-10-08 09:54:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:54:42 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Router Class Initialized
ERROR - 2015-10-08 09:54:42 --> 404 Page Not Found --> 
ERROR - 2015-10-08 09:54:42 --> 404 Page Not Found --> 
ERROR - 2015-10-08 09:54:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:54:42 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:42 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:42 --> Router Class Initialized
ERROR - 2015-10-08 09:54:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:54:47 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:47 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Output Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Security Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Input Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:54:47 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Loader Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:54:47 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 09:54:47 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:54:47 --> Session Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:54:47 --> Session routines successfully run
DEBUG - 2015-10-08 09:54:47 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Email Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Controller Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Auth MX_Controller Initialized
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-08 09:54:47 --> XSS Filtering completed
DEBUG - 2015-10-08 09:54:47 --> Unable to find validation rule: exists
DEBUG - 2015-10-08 09:54:47 --> XSS Filtering completed
DEBUG - 2015-10-08 09:54:47 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:47 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Output Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Security Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Input Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:54:47 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Loader Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:54:47 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:54:47 --> Session Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:54:47 --> Session routines successfully run
DEBUG - 2015-10-08 09:54:47 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Email Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Controller Class Initialized
DEBUG - 2015-10-08 09:54:47 --> Admin MX_Controller Initialized
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-08 09:54:47 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:54:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:54:47 --> Final output sent to browser
DEBUG - 2015-10-08 09:54:47 --> Total execution time: 0.1389
DEBUG - 2015-10-08 09:54:48 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:48 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:48 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:48 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:48 --> Router Class Initialized
ERROR - 2015-10-08 09:54:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:54:53 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:53 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Router Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Output Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Security Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Input Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:54:53 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Language Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Loader Class Initialized
DEBUG - 2015-10-08 09:54:53 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:54:53 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:54:54 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:54:54 --> Session Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:54:54 --> Session routines successfully run
DEBUG - 2015-10-08 09:54:54 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Email Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Controller Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:54:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:54:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:54:54 --> Final output sent to browser
DEBUG - 2015-10-08 09:54:54 --> Total execution time: 0.1440
DEBUG - 2015-10-08 09:54:54 --> Config Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:54:54 --> URI Class Initialized
DEBUG - 2015-10-08 09:54:54 --> Router Class Initialized
ERROR - 2015-10-08 09:54:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:56:14 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:14 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Router Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Output Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Security Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Input Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:56:14 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Loader Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:56:14 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:56:14 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:56:14 --> Session Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:56:14 --> Session routines successfully run
DEBUG - 2015-10-08 09:56:14 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Email Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Controller Class Initialized
DEBUG - 2015-10-08 09:56:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:56:14 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:56:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:56:14 --> Final output sent to browser
DEBUG - 2015-10-08 09:56:14 --> Total execution time: 0.1775
DEBUG - 2015-10-08 09:56:15 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:15 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:15 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:15 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:15 --> Router Class Initialized
ERROR - 2015-10-08 09:56:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:56:24 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:24 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Router Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Output Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Security Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Input Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:56:24 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Loader Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:56:24 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:56:24 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 09:56:24 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:56:24 --> Session Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:56:24 --> Session routines successfully run
DEBUG - 2015-10-08 09:56:24 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Email Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Controller Class Initialized
DEBUG - 2015-10-08 09:56:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:56:24 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:56:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:56:24 --> Final output sent to browser
DEBUG - 2015-10-08 09:56:24 --> Total execution time: 0.2955
DEBUG - 2015-10-08 09:56:25 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:25 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:25 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:25 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:25 --> Router Class Initialized
ERROR - 2015-10-08 09:56:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:56:44 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:44 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Router Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Output Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Security Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Input Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:56:44 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Language Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Loader Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:56:44 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:56:44 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:56:44 --> Session Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:56:44 --> Session routines successfully run
DEBUG - 2015-10-08 09:56:44 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Email Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Controller Class Initialized
DEBUG - 2015-10-08 09:56:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:56:44 --> Model Class Initialized
DEBUG - 2015-10-08 09:56:45 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 09:56:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:56:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:56:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:56:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:56:45 --> Final output sent to browser
DEBUG - 2015-10-08 09:56:45 --> Total execution time: 0.3370
DEBUG - 2015-10-08 09:56:46 --> Config Class Initialized
DEBUG - 2015-10-08 09:56:46 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:56:46 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:56:46 --> URI Class Initialized
DEBUG - 2015-10-08 09:56:46 --> Router Class Initialized
ERROR - 2015-10-08 09:56:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 09:57:54 --> Config Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:57:54 --> URI Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Router Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Output Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Security Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Input Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 09:57:54 --> Language Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Language Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Config Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Loader Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Helper loaded: url_helper
DEBUG - 2015-10-08 09:57:54 --> Helper loaded: form_helper
DEBUG - 2015-10-08 09:57:54 --> Database Driver Class Initialized
ERROR - 2015-10-08 09:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 09:57:54 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 09:57:54 --> Session Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Helper loaded: string_helper
DEBUG - 2015-10-08 09:57:54 --> Session routines successfully run
DEBUG - 2015-10-08 09:57:54 --> Form Validation Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Pagination Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Encrypt Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Email Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Controller Class Initialized
DEBUG - 2015-10-08 09:57:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 09:57:54 --> Model Class Initialized
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 09:57:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 09:57:54 --> Final output sent to browser
DEBUG - 2015-10-08 09:57:54 --> Total execution time: 0.1857
DEBUG - 2015-10-08 09:57:55 --> Config Class Initialized
DEBUG - 2015-10-08 09:57:55 --> Hooks Class Initialized
DEBUG - 2015-10-08 09:57:55 --> Utf8 Class Initialized
DEBUG - 2015-10-08 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 09:57:55 --> URI Class Initialized
DEBUG - 2015-10-08 09:57:55 --> Router Class Initialized
ERROR - 2015-10-08 09:57:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 10:47:05 --> Config Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:47:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:47:05 --> URI Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Router Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Output Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Security Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Input Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 10:47:05 --> Language Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Language Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Config Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Loader Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Helper loaded: url_helper
DEBUG - 2015-10-08 10:47:05 --> Helper loaded: form_helper
DEBUG - 2015-10-08 10:47:05 --> Database Driver Class Initialized
ERROR - 2015-10-08 10:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 10:47:05 --> Session Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Helper loaded: string_helper
DEBUG - 2015-10-08 10:47:05 --> Session routines successfully run
DEBUG - 2015-10-08 10:47:05 --> Form Validation Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Pagination Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Encrypt Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Email Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Controller Class Initialized
DEBUG - 2015-10-08 10:47:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 10:47:05 --> Model Class Initialized
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 10:47:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 10:47:05 --> Final output sent to browser
DEBUG - 2015-10-08 10:47:05 --> Total execution time: 0.1630
DEBUG - 2015-10-08 10:47:07 --> Config Class Initialized
DEBUG - 2015-10-08 10:47:07 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:47:07 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:47:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:47:07 --> URI Class Initialized
DEBUG - 2015-10-08 10:47:07 --> Router Class Initialized
ERROR - 2015-10-08 10:47:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 10:48:30 --> Config Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:48:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:48:30 --> URI Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Router Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Output Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Security Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Input Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 10:48:30 --> Language Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Language Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Config Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Loader Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Helper loaded: url_helper
DEBUG - 2015-10-08 10:48:30 --> Helper loaded: form_helper
DEBUG - 2015-10-08 10:48:30 --> Database Driver Class Initialized
ERROR - 2015-10-08 10:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 10:48:30 --> Session Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Helper loaded: string_helper
DEBUG - 2015-10-08 10:48:30 --> Session routines successfully run
DEBUG - 2015-10-08 10:48:30 --> Form Validation Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Pagination Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Encrypt Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Email Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Controller Class Initialized
DEBUG - 2015-10-08 10:48:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 10:48:30 --> Model Class Initialized
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 10:48:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 10:48:30 --> Final output sent to browser
DEBUG - 2015-10-08 10:48:30 --> Total execution time: 0.1478
DEBUG - 2015-10-08 10:48:32 --> Config Class Initialized
DEBUG - 2015-10-08 10:48:32 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:48:32 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:48:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:48:32 --> URI Class Initialized
DEBUG - 2015-10-08 10:48:32 --> Router Class Initialized
ERROR - 2015-10-08 10:48:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 10:51:13 --> Config Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:51:13 --> URI Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Router Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Output Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Security Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Input Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 10:51:13 --> Language Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Language Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Config Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Loader Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Helper loaded: url_helper
DEBUG - 2015-10-08 10:51:13 --> Helper loaded: form_helper
DEBUG - 2015-10-08 10:51:13 --> Database Driver Class Initialized
ERROR - 2015-10-08 10:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 10:51:13 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 10:51:13 --> Session Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Helper loaded: string_helper
DEBUG - 2015-10-08 10:51:13 --> Session routines successfully run
DEBUG - 2015-10-08 10:51:13 --> Form Validation Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Pagination Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Encrypt Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Email Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Controller Class Initialized
DEBUG - 2015-10-08 10:51:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 10:51:13 --> Model Class Initialized
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 10:51:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 10:51:13 --> Final output sent to browser
DEBUG - 2015-10-08 10:51:13 --> Total execution time: 0.2300
DEBUG - 2015-10-08 10:51:14 --> Config Class Initialized
DEBUG - 2015-10-08 10:51:14 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:51:14 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:51:14 --> URI Class Initialized
DEBUG - 2015-10-08 10:51:14 --> Router Class Initialized
ERROR - 2015-10-08 10:51:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 10:52:00 --> Config Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:52:00 --> URI Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Router Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Output Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Security Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Input Class Initialized
DEBUG - 2015-10-08 10:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 10:52:01 --> Language Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Language Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Config Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Loader Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Helper loaded: url_helper
DEBUG - 2015-10-08 10:52:01 --> Helper loaded: form_helper
DEBUG - 2015-10-08 10:52:01 --> Database Driver Class Initialized
ERROR - 2015-10-08 10:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 10:52:01 --> Session Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Helper loaded: string_helper
DEBUG - 2015-10-08 10:52:01 --> Session routines successfully run
DEBUG - 2015-10-08 10:52:01 --> Form Validation Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Pagination Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Encrypt Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Email Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Controller Class Initialized
DEBUG - 2015-10-08 10:52:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 10:52:01 --> Model Class Initialized
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 10:52:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 10:52:01 --> Final output sent to browser
DEBUG - 2015-10-08 10:52:01 --> Total execution time: 0.3478
DEBUG - 2015-10-08 10:52:02 --> Config Class Initialized
DEBUG - 2015-10-08 10:52:02 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:52:02 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:52:02 --> URI Class Initialized
DEBUG - 2015-10-08 10:52:02 --> Router Class Initialized
ERROR - 2015-10-08 10:52:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 10:53:38 --> Config Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:53:38 --> URI Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Router Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Output Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Security Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Input Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 10:53:38 --> Language Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Language Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Config Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Loader Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Helper loaded: url_helper
DEBUG - 2015-10-08 10:53:38 --> Helper loaded: form_helper
DEBUG - 2015-10-08 10:53:38 --> Database Driver Class Initialized
ERROR - 2015-10-08 10:53:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 10:53:38 --> Session Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Helper loaded: string_helper
DEBUG - 2015-10-08 10:53:38 --> Session routines successfully run
DEBUG - 2015-10-08 10:53:38 --> Form Validation Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Pagination Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Encrypt Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Email Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Controller Class Initialized
DEBUG - 2015-10-08 10:53:38 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 10:53:38 --> Model Class Initialized
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 10:53:38 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 10:53:38 --> Final output sent to browser
DEBUG - 2015-10-08 10:53:38 --> Total execution time: 0.3428
DEBUG - 2015-10-08 10:53:39 --> Config Class Initialized
DEBUG - 2015-10-08 10:53:39 --> Hooks Class Initialized
DEBUG - 2015-10-08 10:53:39 --> Utf8 Class Initialized
DEBUG - 2015-10-08 10:53:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 10:53:39 --> URI Class Initialized
DEBUG - 2015-10-08 10:53:39 --> Router Class Initialized
ERROR - 2015-10-08 10:53:39 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:00:00 --> Config Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:00:00 --> URI Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Router Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Output Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Security Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Input Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:00:00 --> Language Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Language Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Config Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Loader Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:00:00 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:00:00 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:00:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:00:00 --> Session Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:00:00 --> Session routines successfully run
DEBUG - 2015-10-08 11:00:00 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Email Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Controller Class Initialized
DEBUG - 2015-10-08 11:00:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:00:00 --> Model Class Initialized
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:00:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:00:00 --> Final output sent to browser
DEBUG - 2015-10-08 11:00:00 --> Total execution time: 0.1963
DEBUG - 2015-10-08 11:00:01 --> Config Class Initialized
DEBUG - 2015-10-08 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:00:01 --> URI Class Initialized
DEBUG - 2015-10-08 11:00:01 --> Router Class Initialized
ERROR - 2015-10-08 11:00:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:06:52 --> Config Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:06:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:06:52 --> URI Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Router Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Output Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Security Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Input Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:06:52 --> Language Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Language Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Config Class Initialized
DEBUG - 2015-10-08 11:06:52 --> Loader Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:06:53 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:06:53 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:06:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:06:53 --> Session Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:06:53 --> Session routines successfully run
DEBUG - 2015-10-08 11:06:53 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Email Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Controller Class Initialized
DEBUG - 2015-10-08 11:06:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:06:53 --> Model Class Initialized
ERROR - 2015-10-08 11:06:53 --> Severity: Notice  --> Undefined variable: slipnumber C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 71
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:06:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:06:53 --> Final output sent to browser
DEBUG - 2015-10-08 11:06:53 --> Total execution time: 0.1661
DEBUG - 2015-10-08 11:06:54 --> Config Class Initialized
DEBUG - 2015-10-08 11:06:54 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:06:54 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:06:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:06:54 --> URI Class Initialized
DEBUG - 2015-10-08 11:06:54 --> Router Class Initialized
ERROR - 2015-10-08 11:06:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:07:10 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:07:10 --> URI Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Router Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Output Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Security Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Input Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:07:10 --> Language Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Language Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Loader Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:07:10 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:07:10 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:07:10 --> Session Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:07:10 --> Session routines successfully run
DEBUG - 2015-10-08 11:07:10 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Email Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Controller Class Initialized
DEBUG - 2015-10-08 11:07:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:07:10 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:07:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:07:10 --> Final output sent to browser
DEBUG - 2015-10-08 11:07:10 --> Total execution time: 0.2375
DEBUG - 2015-10-08 11:07:11 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:11 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:07:11 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:07:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:07:11 --> URI Class Initialized
DEBUG - 2015-10-08 11:07:11 --> Router Class Initialized
ERROR - 2015-10-08 11:07:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:07:31 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:07:31 --> URI Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Router Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Output Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Security Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Input Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:07:31 --> Language Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Language Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Loader Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:07:31 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:07:31 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:07:31 --> Session Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:07:31 --> Session routines successfully run
DEBUG - 2015-10-08 11:07:31 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Email Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Controller Class Initialized
DEBUG - 2015-10-08 11:07:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:07:31 --> Model Class Initialized
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:07:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:07:31 --> Final output sent to browser
DEBUG - 2015-10-08 11:07:31 --> Total execution time: 0.2637
DEBUG - 2015-10-08 11:07:32 --> Config Class Initialized
DEBUG - 2015-10-08 11:07:32 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:07:32 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:07:32 --> URI Class Initialized
DEBUG - 2015-10-08 11:07:32 --> Router Class Initialized
ERROR - 2015-10-08 11:07:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:08:13 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:08:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:08:13 --> URI Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Router Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Output Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Security Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Input Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:08:13 --> Language Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Language Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Loader Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:08:13 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:08:13 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:08:13 --> Session Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:08:13 --> Session routines successfully run
DEBUG - 2015-10-08 11:08:13 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Email Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Controller Class Initialized
DEBUG - 2015-10-08 11:08:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:08:13 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:08:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:08:13 --> Final output sent to browser
DEBUG - 2015-10-08 11:08:13 --> Total execution time: 0.1945
DEBUG - 2015-10-08 11:08:14 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:14 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:08:14 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:08:14 --> URI Class Initialized
DEBUG - 2015-10-08 11:08:14 --> Router Class Initialized
ERROR - 2015-10-08 11:08:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:08:42 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:08:42 --> URI Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Router Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Output Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Security Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Input Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:08:42 --> Language Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Language Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Loader Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:08:42 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:08:42 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:08:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-08 11:08:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:08:42 --> Session Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:08:42 --> Session routines successfully run
DEBUG - 2015-10-08 11:08:42 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Email Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Controller Class Initialized
DEBUG - 2015-10-08 11:08:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:08:42 --> Model Class Initialized
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:08:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:08:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:08:43 --> Final output sent to browser
DEBUG - 2015-10-08 11:08:43 --> Total execution time: 0.1622
DEBUG - 2015-10-08 11:08:44 --> Config Class Initialized
DEBUG - 2015-10-08 11:08:44 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:08:44 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:08:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:08:44 --> URI Class Initialized
DEBUG - 2015-10-08 11:08:44 --> Router Class Initialized
ERROR - 2015-10-08 11:08:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-08 11:09:19 --> Config Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:09:19 --> URI Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Router Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Output Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Security Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Input Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-08 11:09:19 --> Language Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Language Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Config Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Loader Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Helper loaded: url_helper
DEBUG - 2015-10-08 11:09:19 --> Helper loaded: form_helper
DEBUG - 2015-10-08 11:09:19 --> Database Driver Class Initialized
ERROR - 2015-10-08 11:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-08 11:09:19 --> Session Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Helper loaded: string_helper
DEBUG - 2015-10-08 11:09:19 --> Session routines successfully run
DEBUG - 2015-10-08 11:09:19 --> Form Validation Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Pagination Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Encrypt Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Email Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Controller Class Initialized
DEBUG - 2015-10-08 11:09:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-08 11:09:19 --> Model Class Initialized
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-08 11:09:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-08 11:09:19 --> Final output sent to browser
DEBUG - 2015-10-08 11:09:19 --> Total execution time: 0.1358
DEBUG - 2015-10-08 11:09:20 --> Config Class Initialized
DEBUG - 2015-10-08 11:09:20 --> Hooks Class Initialized
DEBUG - 2015-10-08 11:09:20 --> Utf8 Class Initialized
DEBUG - 2015-10-08 11:09:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-08 11:09:20 --> URI Class Initialized
DEBUG - 2015-10-08 11:09:20 --> Router Class Initialized
ERROR - 2015-10-08 11:09:20 --> 404 Page Not Found --> 
