<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-28 16:46:20 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:20 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:20 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:20 --> Router Class Initialized
DEBUG - 2016-02-28 16:46:21 --> No URI present. Default controller set.
DEBUG - 2016-02-28 16:46:21 --> Output Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Security Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Input Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-28 16:46:21 --> Language Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Language Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Loader Class Initialized
DEBUG - 2016-02-28 16:46:21 --> Helper loaded: url_helper
DEBUG - 2016-02-28 16:46:21 --> Helper loaded: form_helper
DEBUG - 2016-02-28 16:46:21 --> Database Driver Class Initialized
DEBUG - 2016-02-28 16:46:22 --> Session Class Initialized
DEBUG - 2016-02-28 16:46:22 --> Helper loaded: string_helper
DEBUG - 2016-02-28 16:46:22 --> A session cookie was not found.
DEBUG - 2016-02-28 16:46:23 --> Session routines successfully run
DEBUG - 2016-02-28 16:46:23 --> Form Validation Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Pagination Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Encrypt Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Email Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Controller Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Auth MX_Controller Initialized
DEBUG - 2016-02-28 16:46:23 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-28 16:46:23 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-28 16:46:23 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:23 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Router Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Output Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Security Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Input Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-28 16:46:23 --> Language Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Language Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Loader Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Helper loaded: url_helper
DEBUG - 2016-02-28 16:46:23 --> Helper loaded: form_helper
DEBUG - 2016-02-28 16:46:23 --> Database Driver Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Session Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Helper loaded: string_helper
DEBUG - 2016-02-28 16:46:23 --> Session routines successfully run
DEBUG - 2016-02-28 16:46:23 --> Form Validation Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Pagination Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Encrypt Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Email Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Controller Class Initialized
DEBUG - 2016-02-28 16:46:23 --> Auth MX_Controller Initialized
DEBUG - 2016-02-28 16:46:23 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-28 16:46:23 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-28 16:46:24 --> Model Class Initialized
DEBUG - 2016-02-28 16:46:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-28 16:46:25 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-28 16:46:25 --> Final output sent to browser
DEBUG - 2016-02-28 16:46:25 --> Total execution time: 1.5023
DEBUG - 2016-02-28 16:46:44 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:44 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Router Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:44 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:44 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Router Class Initialized
DEBUG - 2016-02-28 16:46:44 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Router Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Config Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:46:44 --> URI Class Initialized
DEBUG - 2016-02-28 16:46:44 --> Router Class Initialized
ERROR - 2016-02-28 16:46:44 --> 404 Page Not Found --> 
ERROR - 2016-02-28 16:46:44 --> 404 Page Not Found --> 
ERROR - 2016-02-28 16:46:44 --> 404 Page Not Found --> 
ERROR - 2016-02-28 16:46:44 --> 404 Page Not Found --> 
DEBUG - 2016-02-28 16:47:09 --> Config Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:47:09 --> URI Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Router Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Output Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Security Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Input Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-28 16:47:09 --> Language Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Language Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Config Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Loader Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Helper loaded: url_helper
DEBUG - 2016-02-28 16:47:09 --> Helper loaded: form_helper
DEBUG - 2016-02-28 16:47:09 --> Database Driver Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Session Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Helper loaded: string_helper
DEBUG - 2016-02-28 16:47:09 --> Session routines successfully run
DEBUG - 2016-02-28 16:47:09 --> Form Validation Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Pagination Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Encrypt Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Email Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Controller Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Auth MX_Controller Initialized
DEBUG - 2016-02-28 16:47:09 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-28 16:47:09 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-28 16:47:09 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-28 16:47:09 --> XSS Filtering completed
DEBUG - 2016-02-28 16:47:09 --> Unable to find validation rule: exists
DEBUG - 2016-02-28 16:47:09 --> XSS Filtering completed
DEBUG - 2016-02-28 16:47:09 --> Config Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:47:09 --> URI Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Router Class Initialized
DEBUG - 2016-02-28 16:47:09 --> Output Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Security Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Input Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-28 16:47:10 --> Language Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Language Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Config Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Loader Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Helper loaded: url_helper
DEBUG - 2016-02-28 16:47:10 --> Helper loaded: form_helper
DEBUG - 2016-02-28 16:47:10 --> Database Driver Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Session Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Helper loaded: string_helper
DEBUG - 2016-02-28 16:47:10 --> Session routines successfully run
DEBUG - 2016-02-28 16:47:10 --> Form Validation Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Pagination Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Encrypt Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Email Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Controller Class Initialized
DEBUG - 2016-02-28 16:47:10 --> Admin MX_Controller Initialized
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-28 16:47:10 --> Model Class Initialized
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-28 16:47:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-28 16:47:10 --> Final output sent to browser
DEBUG - 2016-02-28 16:47:10 --> Total execution time: 0.8787
DEBUG - 2016-02-28 16:47:18 --> Config Class Initialized
DEBUG - 2016-02-28 16:47:18 --> Hooks Class Initialized
DEBUG - 2016-02-28 16:47:18 --> Utf8 Class Initialized
DEBUG - 2016-02-28 16:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-28 16:47:18 --> URI Class Initialized
DEBUG - 2016-02-28 16:47:18 --> Router Class Initialized
ERROR - 2016-02-28 16:47:18 --> 404 Page Not Found --> 
