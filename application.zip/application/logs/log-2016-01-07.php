<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-07 08:24:50 --> Config Class Initialized
DEBUG - 2016-01-07 08:24:50 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:24:50 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:24:51 --> URI Class Initialized
DEBUG - 2016-01-07 08:24:51 --> Router Class Initialized
DEBUG - 2016-01-07 08:24:52 --> No URI present. Default controller set.
DEBUG - 2016-01-07 08:24:52 --> Output Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Security Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Input Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:24:52 --> Language Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Language Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Config Class Initialized
DEBUG - 2016-01-07 08:24:52 --> Loader Class Initialized
DEBUG - 2016-01-07 08:24:53 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:24:53 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:24:53 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Session Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:24:54 --> A session cookie was not found.
DEBUG - 2016-01-07 08:24:54 --> Session routines successfully run
DEBUG - 2016-01-07 08:24:54 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Email Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Controller Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Auth MX_Controller Initialized
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Config Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:24:54 --> URI Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Router Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Output Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Security Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Input Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:24:54 --> Language Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Language Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Config Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Loader Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:24:54 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:24:54 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Session Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:24:54 --> Session routines successfully run
DEBUG - 2016-01-07 08:24:54 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Email Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Controller Class Initialized
DEBUG - 2016-01-07 08:24:54 --> Auth MX_Controller Initialized
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:24:54 --> Model Class Initialized
DEBUG - 2016-01-07 08:24:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:24:55 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-07 08:24:55 --> Final output sent to browser
DEBUG - 2016-01-07 08:24:55 --> Total execution time: 0.6314
DEBUG - 2016-01-07 08:25:05 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:05 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:05 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:05 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:05 --> Router Class Initialized
ERROR - 2016-01-07 08:25:07 --> 404 Page Not Found --> 
DEBUG - 2016-01-07 08:25:08 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:08 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:08 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Router Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:08 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Router Class Initialized
ERROR - 2016-01-07 08:25:08 --> 404 Page Not Found --> 
DEBUG - 2016-01-07 08:25:08 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:08 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:08 --> Router Class Initialized
ERROR - 2016-01-07 08:25:08 --> 404 Page Not Found --> 
ERROR - 2016-01-07 08:25:08 --> 404 Page Not Found --> 
DEBUG - 2016-01-07 08:25:20 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:20 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Router Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Output Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Security Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Input Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:25:20 --> Language Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Language Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Loader Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:25:20 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Session Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:25:20 --> Session routines successfully run
DEBUG - 2016-01-07 08:25:20 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Email Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Controller Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Auth MX_Controller Initialized
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-07 08:25:20 --> XSS Filtering completed
DEBUG - 2016-01-07 08:25:20 --> Unable to find validation rule: exists
DEBUG - 2016-01-07 08:25:20 --> XSS Filtering completed
DEBUG - 2016-01-07 08:25:20 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:25:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:25:20 --> URI Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Router Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Output Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Security Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Input Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:25:20 --> Language Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Language Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Config Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Loader Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:25:20 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Session Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:25:20 --> Session routines successfully run
DEBUG - 2016-01-07 08:25:20 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Email Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Controller Class Initialized
DEBUG - 2016-01-07 08:25:20 --> Admin MX_Controller Initialized
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:20 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:25:20 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:25:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:25:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:25:21 --> Final output sent to browser
DEBUG - 2016-01-07 08:25:21 --> Total execution time: 0.6379
DEBUG - 2016-01-07 08:28:08 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:28:08 --> URI Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Router Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Output Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Security Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Input Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:28:08 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Loader Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:28:08 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:28:08 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Session Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:28:08 --> Session routines successfully run
DEBUG - 2016-01-07 08:28:08 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Email Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Controller Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:28:08 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:08 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:28:09 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:28:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:28:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:28:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:28:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:28:09 --> Final output sent to browser
DEBUG - 2016-01-07 08:28:09 --> Total execution time: 0.9123
DEBUG - 2016-01-07 08:28:13 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:28:13 --> URI Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Router Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Output Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Security Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Input Class Initialized
DEBUG - 2016-01-07 08:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:28:13 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Loader Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:28:14 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:28:14 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Session Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:28:14 --> Session routines successfully run
DEBUG - 2016-01-07 08:28:14 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Email Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Controller Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:28:14 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:28:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:28:14 --> Final output sent to browser
DEBUG - 2016-01-07 08:28:14 --> Total execution time: 0.7575
DEBUG - 2016-01-07 08:28:17 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:28:17 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:28:17 --> URI Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Router Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Output Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Security Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Input Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:28:17 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Language Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Config Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Loader Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:28:17 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:28:17 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Session Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:28:17 --> Session routines successfully run
DEBUG - 2016-01-07 08:28:17 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Email Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Controller Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:28:17 --> Model Class Initialized
DEBUG - 2016-01-07 08:28:17 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:28:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:28:17 --> Final output sent to browser
DEBUG - 2016-01-07 08:28:17 --> Total execution time: 0.2837
DEBUG - 2016-01-07 08:32:30 --> Config Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:32:30 --> URI Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Router Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Output Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Security Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Input Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:32:30 --> Language Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Language Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Config Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Loader Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:32:30 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:32:30 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Session Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:32:30 --> Session routines successfully run
DEBUG - 2016-01-07 08:32:30 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Email Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Controller Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:32:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:32:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:32:30 --> Final output sent to browser
DEBUG - 2016-01-07 08:32:30 --> Total execution time: 0.2812
DEBUG - 2016-01-07 08:37:21 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:37:21 --> URI Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Router Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Output Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Security Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Input Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:37:21 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Loader Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:37:21 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:37:21 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Session Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:37:21 --> Session routines successfully run
DEBUG - 2016-01-07 08:37:21 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Email Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Controller Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:37:21 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:21 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:37:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:37:21 --> Final output sent to browser
DEBUG - 2016-01-07 08:37:21 --> Total execution time: 0.2682
DEBUG - 2016-01-07 08:37:27 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:27 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:37:27 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:37:27 --> URI Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Router Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Output Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Security Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Input Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:37:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Loader Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:37:28 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:37:28 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Session Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:37:28 --> Session routines successfully run
DEBUG - 2016-01-07 08:37:28 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Email Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Controller Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:37:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:37:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:37:28 --> Final output sent to browser
DEBUG - 2016-01-07 08:37:28 --> Total execution time: 0.4197
DEBUG - 2016-01-07 08:37:32 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:37:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:37:32 --> URI Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Router Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Output Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Security Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Input Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:37:32 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Language Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Config Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Loader Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:37:32 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:37:32 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Session Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:37:32 --> Session routines successfully run
DEBUG - 2016-01-07 08:37:32 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Email Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Controller Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:37:32 --> Model Class Initialized
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:37:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:37:32 --> Final output sent to browser
DEBUG - 2016-01-07 08:37:32 --> Total execution time: 0.2885
DEBUG - 2016-01-07 08:38:58 --> Config Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:38:58 --> URI Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Router Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Output Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Security Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Input Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:38:58 --> Language Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Language Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Config Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Loader Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:38:58 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:38:58 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Session Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:38:58 --> Session routines successfully run
DEBUG - 2016-01-07 08:38:58 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Email Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Controller Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Property MX_Controller Initialized
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:38:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:38:58 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:38:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:38:58 --> Final output sent to browser
DEBUG - 2016-01-07 08:38:58 --> Total execution time: 0.4302
DEBUG - 2016-01-07 08:39:03 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:39:03 --> URI Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Router Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Output Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Security Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Input Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:39:03 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Loader Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:39:03 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:39:03 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Session Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:39:03 --> Session routines successfully run
DEBUG - 2016-01-07 08:39:03 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Email Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Controller Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:39:03 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:03 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:39:04 --> File loaded: application/modules/real_estate_administration/views/rental_unit/all_rental_units.php
DEBUG - 2016-01-07 08:39:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:39:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:39:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:39:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:39:04 --> Final output sent to browser
DEBUG - 2016-01-07 08:39:04 --> Total execution time: 0.4308
DEBUG - 2016-01-07 08:39:06 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:39:06 --> URI Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Router Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Output Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Security Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Input Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:39:06 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Loader Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:39:06 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:39:06 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Session Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:39:06 --> Session routines successfully run
DEBUG - 2016-01-07 08:39:06 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Email Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Controller Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:39:06 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:39:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:39:06 --> Final output sent to browser
DEBUG - 2016-01-07 08:39:06 --> Total execution time: 0.2893
DEBUG - 2016-01-07 08:39:38 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:38 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:39:38 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:39:38 --> URI Class Initialized
DEBUG - 2016-01-07 08:39:38 --> Router Class Initialized
ERROR - 2016-01-07 08:39:39 --> 404 Page Not Found --> 
DEBUG - 2016-01-07 08:39:47 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:39:47 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:39:47 --> URI Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Router Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Output Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Security Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Input Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:39:47 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Language Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Config Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Loader Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:39:47 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:39:47 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Session Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:39:47 --> Session routines successfully run
DEBUG - 2016-01-07 08:39:47 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Email Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Controller Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:39:47 --> Model Class Initialized
DEBUG - 2016-01-07 08:39:47 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:39:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:39:47 --> Final output sent to browser
DEBUG - 2016-01-07 08:39:47 --> Total execution time: 0.2885
DEBUG - 2016-01-07 08:45:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:45:40 --> URI Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Router Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Output Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Security Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Input Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:45:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Loader Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:45:40 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:45:40 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Session Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:45:40 --> Session routines successfully run
DEBUG - 2016-01-07 08:45:40 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Email Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Controller Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:45:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:45:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:45:40 --> Final output sent to browser
DEBUG - 2016-01-07 08:45:40 --> Total execution time: 0.3711
DEBUG - 2016-01-07 08:48:18 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:48:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:48:18 --> URI Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Router Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Output Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Security Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Input Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:48:18 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Loader Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:48:18 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:48:18 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Session Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:48:18 --> Session routines successfully run
DEBUG - 2016-01-07 08:48:18 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Email Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Controller Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:48:18 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:18 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:48:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:48:18 --> Final output sent to browser
DEBUG - 2016-01-07 08:48:18 --> Total execution time: 0.2761
DEBUG - 2016-01-07 08:48:25 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:48:25 --> URI Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Router Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Output Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Security Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Input Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:48:25 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Loader Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:48:25 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:48:25 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Session Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:48:25 --> Session routines successfully run
DEBUG - 2016-01-07 08:48:25 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Email Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Controller Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:48:25 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:48:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:48:25 --> Final output sent to browser
DEBUG - 2016-01-07 08:48:25 --> Total execution time: 0.3152
DEBUG - 2016-01-07 08:48:29 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:48:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:48:29 --> URI Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Router Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Output Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Security Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Input Class Initialized
DEBUG - 2016-01-07 08:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:48:29 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Loader Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:48:30 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:48:30 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Session Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:48:30 --> Session routines successfully run
DEBUG - 2016-01-07 08:48:30 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Email Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Controller Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:48:30 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:48:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:48:30 --> Final output sent to browser
DEBUG - 2016-01-07 08:48:30 --> Total execution time: 0.2828
DEBUG - 2016-01-07 08:48:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:48:40 --> URI Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Router Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Output Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Security Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Input Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:48:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Loader Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:48:40 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Session Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:48:40 --> Session routines successfully run
DEBUG - 2016-01-07 08:48:40 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Email Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Controller Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-07 08:48:40 --> XSS Filtering completed
DEBUG - 2016-01-07 08:48:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:48:40 --> URI Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Router Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Output Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Security Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Input Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:48:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Language Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Config Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Loader Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:48:40 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Session Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:48:40 --> Session routines successfully run
DEBUG - 2016-01-07 08:48:40 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Email Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Controller Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:40 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:48:40 --> Model Class Initialized
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:48:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:48:41 --> Final output sent to browser
DEBUG - 2016-01-07 08:48:41 --> Total execution time: 0.2921
DEBUG - 2016-01-07 08:49:28 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:49:28 --> URI Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Router Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Output Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Security Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Input Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:49:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Loader Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:49:28 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Session Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:49:28 --> Session routines successfully run
DEBUG - 2016-01-07 08:49:28 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Email Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Controller Class Initialized
DEBUG - 2016-01-07 08:49:28 --> leases MX_Controller Initialized
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-07 08:49:28 --> XSS Filtering completed
DEBUG - 2016-01-07 08:49:28 --> XSS Filtering completed
DEBUG - 2016-01-07 08:49:28 --> XSS Filtering completed
DEBUG - 2016-01-07 08:49:28 --> XSS Filtering completed
DEBUG - 2016-01-07 08:49:28 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:49:28 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:49:28 --> URI Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Router Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Output Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Security Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Input Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:49:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Loader Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:49:28 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Session Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:49:28 --> Session routines successfully run
DEBUG - 2016-01-07 08:49:28 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Email Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Controller Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:49:28 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:49:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:49:28 --> Final output sent to browser
DEBUG - 2016-01-07 08:49:28 --> Total execution time: 0.2754
DEBUG - 2016-01-07 08:49:51 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:49:51 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:49:51 --> URI Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Router Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Output Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Security Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Input Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:49:51 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Loader Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:49:51 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:49:51 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Session Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:49:51 --> Session routines successfully run
DEBUG - 2016-01-07 08:49:51 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Email Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Controller Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:49:51 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:51 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:49:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:49:51 --> Final output sent to browser
DEBUG - 2016-01-07 08:49:51 --> Total execution time: 0.2579
DEBUG - 2016-01-07 08:49:58 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:49:58 --> URI Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Router Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Output Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Security Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Input Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:49:58 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Language Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Config Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Loader Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:49:58 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:49:58 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Session Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:49:58 --> Session routines successfully run
DEBUG - 2016-01-07 08:49:58 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Email Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Controller Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:49:58 --> Model Class Initialized
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:49:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:49:58 --> Final output sent to browser
DEBUG - 2016-01-07 08:49:58 --> Total execution time: 0.2775
DEBUG - 2016-01-07 08:50:39 --> Config Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:50:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:50:39 --> URI Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Router Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Output Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Security Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Input Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:50:39 --> Language Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Language Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Config Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Loader Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:50:39 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:50:39 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Session Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:50:39 --> Session routines successfully run
DEBUG - 2016-01-07 08:50:39 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Email Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Controller Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Rental_unit MX_Controller Initialized
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:50:39 --> Model Class Initialized
DEBUG - 2016-01-07 08:50:39 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/real_estate_administration/views/rental_unit/rental_units.php
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:50:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:50:39 --> Final output sent to browser
DEBUG - 2016-01-07 08:50:39 --> Total execution time: 0.3525
DEBUG - 2016-01-07 08:52:27 --> Config Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Hooks Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Utf8 Class Initialized
DEBUG - 2016-01-07 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-07 08:52:27 --> URI Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Router Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Output Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Security Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Input Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-07 08:52:27 --> Language Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Language Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Config Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Loader Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Helper loaded: url_helper
DEBUG - 2016-01-07 08:52:27 --> Helper loaded: form_helper
DEBUG - 2016-01-07 08:52:27 --> Database Driver Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Session Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Helper loaded: string_helper
DEBUG - 2016-01-07 08:52:27 --> Session routines successfully run
DEBUG - 2016-01-07 08:52:27 --> Form Validation Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Pagination Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Encrypt Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Email Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Controller Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Tenants MX_Controller Initialized
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> Image Lib Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-01-07 08:52:27 --> Model Class Initialized
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-07 08:52:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-07 08:52:27 --> Final output sent to browser
DEBUG - 2016-01-07 08:52:27 --> Total execution time: 0.3195
