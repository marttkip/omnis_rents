<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-02 08:11:03 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:03 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:03 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:04 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:04 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:05 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:05 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:05 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:05 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:06 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:06 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:06 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:06 --> A session cookie was not found.
DEBUG - 2015-12-02 08:11:06 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:06 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:11:07 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:07 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:07 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:08 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:08 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:08 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:08 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:08 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:08 --> Auth MX_Controller Initialized
DEBUG - 2015-12-02 08:11:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:11:09 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-02 08:11:09 --> Final output sent to browser
DEBUG - 2015-12-02 08:11:09 --> Total execution time: 1.3094
DEBUG - 2015-12-02 08:11:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:12 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:12 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:12 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:12 --> Hooks Class Initialized
ERROR - 2015-12-02 08:11:12 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 08:11:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:12 --> URI Class Initialized
ERROR - 2015-12-02 08:11:12 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 08:11:12 --> Router Class Initialized
ERROR - 2015-12-02 08:11:12 --> 404 Page Not Found --> 
ERROR - 2015-12-02 08:11:12 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 08:11:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:18 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:18 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:18 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:18 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:18 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Auth MX_Controller Initialized
DEBUG - 2015-12-02 08:11:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 08:11:18 --> XSS Filtering completed
DEBUG - 2015-12-02 08:11:18 --> Unable to find validation rule: exists
DEBUG - 2015-12-02 08:11:18 --> XSS Filtering completed
DEBUG - 2015-12-02 08:11:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:18 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:18 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:18 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:18 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:19 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:19 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:19 --> Admin MX_Controller Initialized
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:11:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:11:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:11:19 --> Final output sent to browser
DEBUG - 2015-12-02 08:11:19 --> Total execution time: 0.6235
DEBUG - 2015-12-02 08:11:31 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:31 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:31 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:31 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:32 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:32 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:32 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:32 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:11:32 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:32 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:11:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:11:32 --> Final output sent to browser
DEBUG - 2015-12-02 08:11:32 --> Total execution time: 0.6786
DEBUG - 2015-12-02 08:11:35 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:35 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:35 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:35 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:35 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:35 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:35 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:11:35 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:35 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:11:36 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:11:36 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:11:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:11:37 --> Final output sent to browser
DEBUG - 2015-12-02 08:11:37 --> Total execution time: 1.7355
DEBUG - 2015-12-02 08:11:51 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:11:51 --> URI Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Router Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Output Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Security Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Input Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:11:51 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Language Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Config Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Loader Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:11:51 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:11:51 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Session Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:11:51 --> Session routines successfully run
DEBUG - 2015-12-02 08:11:51 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Email Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Controller Class Initialized
DEBUG - 2015-12-02 08:11:51 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:51 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:11:51 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:11:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:11:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:11:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:11:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:11:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:11:52 --> Final output sent to browser
DEBUG - 2015-12-02 08:11:52 --> Total execution time: 0.6179
DEBUG - 2015-12-02 08:14:13 --> Config Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:14:13 --> URI Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Router Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Output Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Security Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Input Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:14:13 --> Language Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Language Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Config Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Loader Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:14:13 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:14:13 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Session Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:14:13 --> Session routines successfully run
DEBUG - 2015-12-02 08:14:13 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Email Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Controller Class Initialized
DEBUG - 2015-12-02 08:14:13 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:14:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/hr/views/personnel/all_personnel.php
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:14:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:14:13 --> Final output sent to browser
DEBUG - 2015-12-02 08:14:13 --> Total execution time: 0.2573
DEBUG - 2015-12-02 08:14:16 --> Config Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:14:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:14:16 --> URI Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Router Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Output Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Security Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Input Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:14:16 --> Language Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Language Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Config Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Loader Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:14:16 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:14:16 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Session Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:14:16 --> Session routines successfully run
DEBUG - 2015-12-02 08:14:16 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Email Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Controller Class Initialized
DEBUG - 2015-12-02 08:14:16 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:14:16 --> Model Class Initialized
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/hr/views/personnel/add_personnel.php
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:14:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:14:16 --> Final output sent to browser
DEBUG - 2015-12-02 08:14:16 --> Total execution time: 0.2869
DEBUG - 2015-12-02 08:16:33 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:16:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:16:33 --> URI Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Router Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Output Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Security Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Input Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:16:33 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Loader Class Initialized
DEBUG - 2015-12-02 08:16:33 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:16:33 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:16:34 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Session Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:16:34 --> Session routines successfully run
DEBUG - 2015-12-02 08:16:34 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Email Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Controller Class Initialized
DEBUG - 2015-12-02 08:16:34 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:16:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/hr/views/personnel/add_personnel.php
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:16:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:16:34 --> Final output sent to browser
DEBUG - 2015-12-02 08:16:34 --> Total execution time: 0.3624
DEBUG - 2015-12-02 08:16:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:16:56 --> URI Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Router Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Output Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Security Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Input Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:16:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Loader Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:16:56 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Session Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:16:56 --> Session routines successfully run
DEBUG - 2015-12-02 08:16:56 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Email Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Controller Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> XSS Filtering completed
DEBUG - 2015-12-02 08:16:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:16:56 --> URI Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Router Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Output Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Security Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Input Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:16:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Loader Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:16:56 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Session Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:16:56 --> Session routines successfully run
DEBUG - 2015-12-02 08:16:56 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Email Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Controller Class Initialized
DEBUG - 2015-12-02 08:16:56 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:56 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:16:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:16:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:16:57 --> Final output sent to browser
DEBUG - 2015-12-02 08:16:57 --> Total execution time: 0.7061
DEBUG - 2015-12-02 08:17:09 --> Config Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:17:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:17:09 --> URI Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Router Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Output Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Security Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Input Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:17:09 --> Language Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Language Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Config Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Loader Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:17:09 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Session Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:17:09 --> Session routines successfully run
DEBUG - 2015-12-02 08:17:09 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Email Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Controller Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:17:09 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 08:17:09 --> XSS Filtering completed
DEBUG - 2015-12-02 08:17:09 --> XSS Filtering completed
DEBUG - 2015-12-02 08:17:09 --> Config Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:17:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:17:09 --> URI Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Router Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Output Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Security Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Input Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:17:09 --> Language Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Language Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Config Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Loader Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:17:09 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Session Class Initialized
DEBUG - 2015-12-02 08:17:09 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:17:09 --> Session routines successfully run
DEBUG - 2015-12-02 08:17:10 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:17:10 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:17:10 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:17:10 --> Email Class Initialized
DEBUG - 2015-12-02 08:17:10 --> Controller Class Initialized
DEBUG - 2015-12-02 08:17:10 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:17:10 --> Model Class Initialized
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:17:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:17:10 --> Final output sent to browser
DEBUG - 2015-12-02 08:17:10 --> Total execution time: 0.2795
DEBUG - 2015-12-02 08:22:52 --> Config Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:22:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:22:52 --> URI Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Router Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Output Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Security Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Input Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:22:52 --> Language Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Language Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Config Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Loader Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:22:52 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:22:52 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Session Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:22:52 --> Session routines successfully run
DEBUG - 2015-12-02 08:22:52 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Email Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Controller Class Initialized
DEBUG - 2015-12-02 08:22:52 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:22:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/about.php
ERROR - 2015-12-02 08:22:52 --> Severity: Notice  --> Undefined variable: authorize_invoice_changes C:\xampp\htdocs\mfi\application\modules\hr\views\personnel\edit\account.php 172
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:22:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:22:52 --> Final output sent to browser
DEBUG - 2015-12-02 08:22:52 --> Total execution time: 0.3271
DEBUG - 2015-12-02 08:23:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:23:12 --> URI Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Router Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Output Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Security Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Input Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:23:12 --> Language Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Language Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Loader Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:23:12 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:23:12 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Session Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:23:12 --> Session routines successfully run
DEBUG - 2015-12-02 08:23:12 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Email Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Controller Class Initialized
DEBUG - 2015-12-02 08:23:12 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:23:12 --> Model Class Initialized
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:23:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:23:12 --> Final output sent to browser
DEBUG - 2015-12-02 08:23:12 --> Total execution time: 0.3834
DEBUG - 2015-12-02 08:27:08 --> Config Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:27:08 --> URI Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Router Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Output Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Security Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Input Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:27:08 --> Language Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Language Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Config Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Loader Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:27:08 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:27:08 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Session Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:27:08 --> Session routines successfully run
DEBUG - 2015-12-02 08:27:08 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Email Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Controller Class Initialized
DEBUG - 2015-12-02 08:27:08 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:27:08 --> Model Class Initialized
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:27:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:27:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:27:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:27:09 --> Final output sent to browser
DEBUG - 2015-12-02 08:27:09 --> Total execution time: 0.2918
DEBUG - 2015-12-02 08:29:46 --> Config Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:29:46 --> URI Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Router Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Output Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Security Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Input Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:29:46 --> Language Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Language Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Config Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Loader Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:29:46 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:29:46 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Session Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:29:46 --> Session routines successfully run
DEBUG - 2015-12-02 08:29:46 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Email Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Controller Class Initialized
DEBUG - 2015-12-02 08:29:46 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:29:46 --> Model Class Initialized
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:29:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:29:46 --> Final output sent to browser
DEBUG - 2015-12-02 08:29:46 --> Total execution time: 0.3019
DEBUG - 2015-12-02 08:31:15 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:31:15 --> URI Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Router Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Output Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Security Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Input Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:31:15 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Loader Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:31:15 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:31:15 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Session Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:31:15 --> Session routines successfully run
DEBUG - 2015-12-02 08:31:15 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Email Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Controller Class Initialized
DEBUG - 2015-12-02 08:31:15 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:15 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:31:15 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:31:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:31:16 --> Final output sent to browser
DEBUG - 2015-12-02 08:31:16 --> Total execution time: 0.3688
DEBUG - 2015-12-02 08:31:28 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:31:28 --> URI Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Router Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Output Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Security Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Input Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:31:28 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Loader Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:31:28 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:31:28 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Session Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:31:28 --> Session routines successfully run
DEBUG - 2015-12-02 08:31:28 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Email Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Controller Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:31:28 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 08:31:28 --> XSS Filtering completed
DEBUG - 2015-12-02 08:31:28 --> XSS Filtering completed
DEBUG - 2015-12-02 08:31:28 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:31:28 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:31:29 --> URI Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Router Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Output Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Security Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Input Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:31:29 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Language Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Config Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Loader Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:31:29 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:31:29 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Session Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:31:29 --> Session routines successfully run
DEBUG - 2015-12-02 08:31:29 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Email Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Controller Class Initialized
DEBUG - 2015-12-02 08:31:29 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:31:29 --> Model Class Initialized
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:31:29 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:31:29 --> Final output sent to browser
DEBUG - 2015-12-02 08:31:29 --> Total execution time: 0.2860
DEBUG - 2015-12-02 08:33:02 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:02 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:02 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:02 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:02 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:02 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:02 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:02 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:02 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:02 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:02 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:02 --> Personnel MX_Controller Initialized
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/leave_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/hr_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/models/schedules_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:33:02 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/about.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/account.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/emergency.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/dependants.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/jobs.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit/leave.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/hr/views/personnel/edit_personnel.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:33:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:33:02 --> Final output sent to browser
DEBUG - 2015-12-02 08:33:02 --> Total execution time: 0.3483
DEBUG - 2015-12-02 08:33:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:18 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:18 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:18 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:18 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:18 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:33:18 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:18 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:33:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:33:18 --> Final output sent to browser
DEBUG - 2015-12-02 08:33:18 --> Total execution time: 0.2731
DEBUG - 2015-12-02 08:33:27 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:27 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:27 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:27 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:27 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:27 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:27 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:33:27 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:27 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:33:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:33:27 --> Final output sent to browser
DEBUG - 2015-12-02 08:33:27 --> Total execution time: 0.3695
DEBUG - 2015-12-02 08:33:44 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:44 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:44 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:44 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:44 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:44 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> Unable to find validation rule: exists
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> Unable to find validation rule: exists
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> XSS Filtering completed
DEBUG - 2015-12-02 08:33:44 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:33:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:33:44 --> URI Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Router Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Output Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Security Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Input Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:33:44 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Language Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Config Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Loader Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:33:44 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Session Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:33:44 --> Session routines successfully run
DEBUG - 2015-12-02 08:33:44 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Email Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Controller Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:33:44 --> Model Class Initialized
DEBUG - 2015-12-02 08:33:44 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:33:44 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:33:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:33:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:33:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:33:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:33:45 --> Final output sent to browser
DEBUG - 2015-12-02 08:33:45 --> Total execution time: 0.3019
DEBUG - 2015-12-02 08:35:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:35:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:35:56 --> URI Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Router Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Output Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Security Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Input Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:35:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Language Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Config Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Loader Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:35:56 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:35:56 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Session Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:35:56 --> Session routines successfully run
DEBUG - 2015-12-02 08:35:56 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Email Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Controller Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:35:56 --> Model Class Initialized
DEBUG - 2015-12-02 08:35:56 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:35:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:35:56 --> Final output sent to browser
DEBUG - 2015-12-02 08:35:56 --> Total execution time: 0.3899
DEBUG - 2015-12-02 08:38:45 --> Config Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:38:45 --> URI Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Router Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Output Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Security Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Input Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:38:45 --> Language Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Language Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Config Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Loader Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:38:45 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:38:45 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Session Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:38:45 --> Session routines successfully run
DEBUG - 2015-12-02 08:38:45 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Email Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Controller Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:38:45 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:45 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:38:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:38:45 --> Final output sent to browser
DEBUG - 2015-12-02 08:38:45 --> Total execution time: 0.3558
DEBUG - 2015-12-02 08:38:50 --> Config Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:38:50 --> URI Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Router Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Output Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Security Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Input Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:38:50 --> Language Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Language Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Config Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Loader Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:38:50 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:38:50 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Session Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:38:50 --> Session routines successfully run
DEBUG - 2015-12-02 08:38:50 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Email Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Controller Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:38:50 --> Model Class Initialized
DEBUG - 2015-12-02 08:38:50 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:38:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:38:50 --> Final output sent to browser
DEBUG - 2015-12-02 08:38:50 --> Total execution time: 0.3502
DEBUG - 2015-12-02 08:40:16 --> Config Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:40:16 --> URI Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Router Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Output Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Security Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Input Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:40:16 --> Language Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Language Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Config Class Initialized
DEBUG - 2015-12-02 08:40:16 --> Loader Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:40:17 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:40:17 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Session Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:40:17 --> Session routines successfully run
DEBUG - 2015-12-02 08:40:17 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Email Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Controller Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 08:40:17 --> Model Class Initialized
DEBUG - 2015-12-02 08:40:17 --> Image Lib Class Initialized
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:40:17 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:40:17 --> Final output sent to browser
DEBUG - 2015-12-02 08:40:17 --> Total execution time: 0.3264
DEBUG - 2015-12-02 08:56:39 --> Config Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:56:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:56:40 --> URI Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Router Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Output Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Security Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Input Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:56:40 --> Language Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Language Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Config Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Loader Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:56:40 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:56:40 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:56:40 --> Session Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:56:41 --> Session routines successfully run
DEBUG - 2015-12-02 08:56:41 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Email Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Controller Class Initialized
DEBUG - 2015-12-02 08:56:41 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:56:41 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:56:41 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Config Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:57:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:57:21 --> URI Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Router Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Output Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Security Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Input Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:57:21 --> Language Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Language Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Config Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Loader Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:57:21 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:57:21 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Session Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:57:21 --> Session routines successfully run
DEBUG - 2015-12-02 08:57:21 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Email Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Controller Class Initialized
DEBUG - 2015-12-02 08:57:21 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:57:21 --> Model Class Initialized
DEBUG - 2015-12-02 08:57:21 --> DB Transaction Failure
ERROR - 2015-12-02 08:57:21 --> Query error: Table 'mfi.payroll' doesn't exist
DEBUG - 2015-12-02 08:57:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-02 08:58:12 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:58:12 --> URI Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Router Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Output Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Security Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Input Class Initialized
DEBUG - 2015-12-02 08:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:58:12 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Loader Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:58:13 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:58:13 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Session Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:58:13 --> Session routines successfully run
DEBUG - 2015-12-02 08:58:13 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Email Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Controller Class Initialized
DEBUG - 2015-12-02 08:58:13 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:58:13 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/accounts/views/payroll/payroll_list.php
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 08:58:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 08:58:13 --> Final output sent to browser
DEBUG - 2015-12-02 08:58:13 --> Total execution time: 0.5888
DEBUG - 2015-12-02 08:58:21 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:21 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:58:21 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:58:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:58:21 --> URI Class Initialized
DEBUG - 2015-12-02 08:58:21 --> Router Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Output Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Security Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Input Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:58:22 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Loader Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:58:22 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:58:22 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Session Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:58:22 --> Session routines successfully run
DEBUG - 2015-12-02 08:58:22 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Email Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Controller Class Initialized
DEBUG - 2015-12-02 08:58:22 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:58:22 --> Model Class Initialized
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 08:58:22 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 08:58:22 --> DB Transaction Failure
ERROR - 2015-12-02 08:58:22 --> Query error: Table 'mfi.payment' doesn't exist
DEBUG - 2015-12-02 08:58:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 08:58:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 08:58:52 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:58:52 --> URI Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Router Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Output Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Security Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Input Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:58:52 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Language Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Config Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Loader Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:58:52 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:58:52 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Session Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:58:52 --> Session routines successfully run
DEBUG - 2015-12-02 08:58:52 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Email Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Controller Class Initialized
DEBUG - 2015-12-02 08:58:52 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
DEBUG - 2015-12-02 08:58:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:58:52 --> Model Class Initialized
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 08:58:52 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 08:58:52 --> DB Transaction Failure
ERROR - 2015-12-02 08:58:52 --> Query error: Table 'mfi.benefit' doesn't exist
DEBUG - 2015-12-02 08:58:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 08:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 08:59:19 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:59:19 --> URI Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Router Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Output Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Security Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Input Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:59:19 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Loader Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:59:19 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:59:19 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Session Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:59:19 --> Session routines successfully run
DEBUG - 2015-12-02 08:59:19 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Email Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Controller Class Initialized
DEBUG - 2015-12-02 08:59:19 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:59:19 --> Model Class Initialized
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 08:59:19 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 08:59:19 --> DB Transaction Failure
ERROR - 2015-12-02 08:59:19 --> Query error: Table 'mfi.allowance' doesn't exist
DEBUG - 2015-12-02 08:59:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 08:59:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 08:59:34 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:59:34 --> URI Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Router Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Output Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Security Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Input Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:59:34 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Loader Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:59:34 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:59:34 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Session Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:59:34 --> Session routines successfully run
DEBUG - 2015-12-02 08:59:34 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Email Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Controller Class Initialized
DEBUG - 2015-12-02 08:59:34 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:59:34 --> Model Class Initialized
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 08:59:34 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 08:59:34 --> DB Transaction Failure
ERROR - 2015-12-02 08:59:34 --> Query error: Table 'mfi.deduction' doesn't exist
DEBUG - 2015-12-02 08:59:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 08:59:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 08:59:57 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Hooks Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Utf8 Class Initialized
DEBUG - 2015-12-02 08:59:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 08:59:57 --> URI Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Router Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Output Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Security Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Input Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 08:59:57 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Language Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Config Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Loader Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Helper loaded: url_helper
DEBUG - 2015-12-02 08:59:57 --> Helper loaded: form_helper
DEBUG - 2015-12-02 08:59:57 --> Database Driver Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Session Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Helper loaded: string_helper
DEBUG - 2015-12-02 08:59:57 --> Session routines successfully run
DEBUG - 2015-12-02 08:59:57 --> Form Validation Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Pagination Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Encrypt Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Email Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Controller Class Initialized
DEBUG - 2015-12-02 08:59:57 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
DEBUG - 2015-12-02 08:59:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 08:59:57 --> Model Class Initialized
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 08:59:58 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 08:59:58 --> DB Transaction Failure
ERROR - 2015-12-02 08:59:58 --> Query error: Table 'mfi.loan_scheme' doesn't exist
DEBUG - 2015-12-02 08:59:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 08:59:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 09:00:15 --> Config Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:00:15 --> URI Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Router Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Output Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Security Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Input Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:00:15 --> Language Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Language Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Config Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Loader Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:00:15 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:00:15 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Session Class Initialized
DEBUG - 2015-12-02 09:00:15 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:00:15 --> Session routines successfully run
DEBUG - 2015-12-02 09:00:16 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:00:16 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:00:16 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:00:16 --> Email Class Initialized
DEBUG - 2015-12-02 09:00:16 --> Controller Class Initialized
DEBUG - 2015-12-02 09:00:16 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:00:16 --> Model Class Initialized
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 09:00:16 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 09:00:16 --> DB Transaction Failure
ERROR - 2015-12-02 09:00:16 --> Query error: Table 'mfi.other_deduction' doesn't exist
DEBUG - 2015-12-02 09:00:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-02 09:00:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mfi\system\core\Exceptions.php:186) C:\xampp\htdocs\mfi\system\core\Common.php 441
DEBUG - 2015-12-02 09:00:36 --> Config Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:00:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:00:36 --> URI Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Router Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Output Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Security Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Input Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:00:36 --> Language Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Language Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Config Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Loader Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:00:36 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:00:36 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Session Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:00:36 --> Session routines successfully run
DEBUG - 2015-12-02 09:00:36 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Email Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Controller Class Initialized
DEBUG - 2015-12-02 09:00:36 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:00:36 --> Model Class Initialized
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 09:00:36 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 09:00:36 --> File loaded: application/modules/accounts/views/payroll/payroll.php
DEBUG - 2015-12-02 09:00:36 --> Final output sent to browser
DEBUG - 2015-12-02 09:00:36 --> Total execution time: 0.4087
DEBUG - 2015-12-02 09:01:52 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:52 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Router Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Output Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Security Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Input Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:01:52 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Loader Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:01:52 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:01:52 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Session Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:01:52 --> Session routines successfully run
DEBUG - 2015-12-02 09:01:52 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Email Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Controller Class Initialized
DEBUG - 2015-12-02 09:01:52 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:01:52 --> Model Class Initialized
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 09:01:52 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 09:01:52 --> File loaded: application/modules/accounts/views/payroll/payroll.php
DEBUG - 2015-12-02 09:01:52 --> Final output sent to browser
DEBUG - 2015-12-02 09:01:52 --> Total execution time: 0.3228
DEBUG - 2015-12-02 09:01:57 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:57 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Router Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Output Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Security Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Input Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:01:57 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Loader Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:01:57 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:01:57 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Session Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:01:57 --> Session routines successfully run
DEBUG - 2015-12-02 09:01:57 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Email Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Controller Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Auth MX_Controller Initialized
DEBUG - 2015-12-02 09:01:57 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:01:57 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:01:57 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:57 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Router Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Output Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Security Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Input Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:01:57 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Language Class Initialized
DEBUG - 2015-12-02 09:01:57 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Loader Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:01:58 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:01:58 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Session Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:01:58 --> A session cookie was not found.
DEBUG - 2015-12-02 09:01:58 --> Session routines successfully run
DEBUG - 2015-12-02 09:01:58 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Email Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Controller Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Auth MX_Controller Initialized
DEBUG - 2015-12-02 09:01:58 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:01:58 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:01:58 --> Model Class Initialized
DEBUG - 2015-12-02 09:01:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 09:01:58 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-12-02 09:01:58 --> Final output sent to browser
DEBUG - 2015-12-02 09:01:58 --> Total execution time: 0.1868
DEBUG - 2015-12-02 09:01:58 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:58 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Router Class Initialized
ERROR - 2015-12-02 09:01:58 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 09:01:58 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:58 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:58 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Router Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:58 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Router Class Initialized
ERROR - 2015-12-02 09:01:58 --> 404 Page Not Found --> 
ERROR - 2015-12-02 09:01:58 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 09:01:58 --> Config Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:01:58 --> URI Class Initialized
DEBUG - 2015-12-02 09:01:58 --> Router Class Initialized
ERROR - 2015-12-02 09:01:58 --> 404 Page Not Found --> 
DEBUG - 2015-12-02 09:02:00 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:00 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:00 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:00 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:00 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:00 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:00 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Auth MX_Controller Initialized
DEBUG - 2015-12-02 09:02:00 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:00 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:00 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-02 09:02:00 --> XSS Filtering completed
DEBUG - 2015-12-02 09:02:00 --> Unable to find validation rule: exists
DEBUG - 2015-12-02 09:02:00 --> XSS Filtering completed
DEBUG - 2015-12-02 09:02:01 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:01 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:01 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:01 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:01 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:01 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:01 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:01 --> Admin MX_Controller Initialized
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:02:01 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 09:02:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 09:02:01 --> Final output sent to browser
DEBUG - 2015-12-02 09:02:01 --> Total execution time: 0.2598
DEBUG - 2015-12-02 09:02:05 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:05 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:05 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:05 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:05 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:05 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:05 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:05 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:05 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/accounts/views/payroll/payroll_list.php
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 09:02:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 09:02:05 --> Final output sent to browser
DEBUG - 2015-12-02 09:02:05 --> Total execution time: 0.3998
DEBUG - 2015-12-02 09:02:08 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:08 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:08 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:08 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:08 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:08 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:08 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:08 --> Payroll MX_Controller Initialized
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/accounts/models/payroll_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/admin/models/branches_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/accounts/models/petty_cash_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:08 --> Model Class Initialized
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 403
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_image_name C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 404
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_id C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 405
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_address C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 406
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_post_code C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 407
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_city C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 408
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_phone C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 409
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_email C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 410
ERROR - 2015-12-02 09:02:08 --> Severity: Notice  --> Undefined variable: branch_location C:\xampp\htdocs\mfi\application\modules\accounts\controllers\payroll.php 411
DEBUG - 2015-12-02 09:02:08 --> File loaded: application/modules/accounts/views/payroll/payroll.php
DEBUG - 2015-12-02 09:02:08 --> Final output sent to browser
DEBUG - 2015-12-02 09:02:08 --> Total execution time: 0.3748
DEBUG - 2015-12-02 09:02:36 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:36 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:36 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:36 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:36 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:36 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:36 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:36 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 09:02:36 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 09:02:37 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 09:02:37 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 09:02:37 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:37 --> Image Lib Class Initialized
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/microfinance/views/individual/all_individual.php
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 09:02:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 09:02:37 --> Final output sent to browser
DEBUG - 2015-12-02 09:02:37 --> Total execution time: 0.4439
DEBUG - 2015-12-02 09:02:40 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Hooks Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Utf8 Class Initialized
DEBUG - 2015-12-02 09:02:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-02 09:02:40 --> URI Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Router Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Output Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Security Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Input Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-02 09:02:40 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Language Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Config Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Loader Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Helper loaded: url_helper
DEBUG - 2015-12-02 09:02:40 --> Helper loaded: form_helper
DEBUG - 2015-12-02 09:02:40 --> Database Driver Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Session Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Helper loaded: string_helper
DEBUG - 2015-12-02 09:02:40 --> Session routines successfully run
DEBUG - 2015-12-02 09:02:40 --> Form Validation Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Pagination Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Encrypt Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Email Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Controller Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Individual MX_Controller Initialized
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-12-02 09:02:40 --> Model Class Initialized
DEBUG - 2015-12-02 09:02:40 --> Image Lib Class Initialized
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/about.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/emergency.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/jobs.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/uploads.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/account.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit/history.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/microfinance/views/individual/edit_individual.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-12-02 09:02:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-12-02 09:02:40 --> Final output sent to browser
DEBUG - 2015-12-02 09:02:40 --> Total execution time: 0.5063
