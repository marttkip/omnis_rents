<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-13 07:29:48 --> Config Class Initialized
DEBUG - 2016-01-13 07:29:48 --> Hooks Class Initialized
DEBUG - 2016-01-13 07:29:48 --> Utf8 Class Initialized
DEBUG - 2016-01-13 07:29:48 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 07:29:48 --> URI Class Initialized
DEBUG - 2016-01-13 07:29:50 --> Router Class Initialized
DEBUG - 2016-01-13 07:29:51 --> Output Class Initialized
DEBUG - 2016-01-13 07:29:51 --> Security Class Initialized
DEBUG - 2016-01-13 07:29:51 --> Input Class Initialized
DEBUG - 2016-01-13 07:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 07:29:51 --> Language Class Initialized
DEBUG - 2016-01-13 07:29:54 --> Language Class Initialized
DEBUG - 2016-01-13 07:29:54 --> Config Class Initialized
DEBUG - 2016-01-13 07:29:54 --> Loader Class Initialized
DEBUG - 2016-01-13 07:29:55 --> Helper loaded: url_helper
DEBUG - 2016-01-13 07:29:55 --> Helper loaded: form_helper
DEBUG - 2016-01-13 07:29:56 --> Database Driver Class Initialized
ERROR - 2016-01-13 07:29:59 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'localhost' (10061) C:\xampp\htdocs\rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 07:29:59 --> Unable to connect to the database
DEBUG - 2016-01-13 07:30:00 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-13 07:30:10 --> Config Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Hooks Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Utf8 Class Initialized
DEBUG - 2016-01-13 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 07:30:10 --> URI Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Router Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Output Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Security Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Input Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 07:30:10 --> Language Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Language Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Config Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Loader Class Initialized
DEBUG - 2016-01-13 07:30:10 --> Helper loaded: url_helper
DEBUG - 2016-01-13 07:30:10 --> Helper loaded: form_helper
DEBUG - 2016-01-13 07:30:10 --> Database Driver Class Initialized
ERROR - 2016-01-13 07:30:11 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'localhost' (10061) C:\xampp\htdocs\rents\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2016-01-13 07:30:11 --> Unable to connect to the database
DEBUG - 2016-01-13 07:30:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-01-13 07:31:56 --> Config Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Hooks Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Utf8 Class Initialized
DEBUG - 2016-01-13 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 07:31:56 --> URI Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Router Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Output Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Security Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Input Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 07:31:56 --> Language Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Language Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Config Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Loader Class Initialized
DEBUG - 2016-01-13 07:31:56 --> Helper loaded: url_helper
DEBUG - 2016-01-13 07:31:56 --> Helper loaded: form_helper
DEBUG - 2016-01-13 07:31:56 --> Database Driver Class Initialized
DEBUG - 2016-01-13 07:31:58 --> Session Class Initialized
DEBUG - 2016-01-13 07:31:58 --> Helper loaded: string_helper
DEBUG - 2016-01-13 07:31:58 --> A session cookie was not found.
DEBUG - 2016-01-13 07:31:58 --> Session routines successfully run
DEBUG - 2016-01-13 07:31:59 --> Form Validation Class Initialized
DEBUG - 2016-01-13 07:31:59 --> Pagination Class Initialized
DEBUG - 2016-01-13 07:31:59 --> Encrypt Class Initialized
DEBUG - 2016-01-13 07:31:59 --> Email Class Initialized
DEBUG - 2016-01-13 07:31:59 --> Controller Class Initialized
DEBUG - 2016-01-13 07:31:59 --> Water_management MX_Controller Initialized
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:00 --> File loaded: application/modules/water_management/models/water_management_model.php
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-13 07:32:00 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:01 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-13 07:32:01 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:01 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-01-13 07:32:01 --> Model Class Initialized
DEBUG - 2016-01-13 07:32:02 --> File loaded: application/modules/water_management/views/reading_reports.php
DEBUG - 2016-01-13 07:32:02 --> Final output sent to browser
DEBUG - 2016-01-13 07:32:02 --> Total execution time: 5.9976
