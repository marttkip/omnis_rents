<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-09 11:04:53 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:53 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Output Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Security Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Input Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:04:53 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Loader Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:04:53 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:04:53 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:04:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:04:53 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:04:53 --> Session Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:04:53 --> A session cookie was not found.
DEBUG - 2015-10-09 11:04:53 --> Session routines successfully run
DEBUG - 2015-10-09 11:04:53 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Email Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Controller Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:04:53 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:53 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Output Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Security Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Input Class Initialized
DEBUG - 2015-10-09 11:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:04:53 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Loader Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:04:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:04:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:04:54 --> Session Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:04:54 --> Session routines successfully run
DEBUG - 2015-10-09 11:04:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Email Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Controller Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Auth MX_Controller Initialized
DEBUG - 2015-10-09 11:04:54 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:04:54 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:04:54 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:04:54 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-09 11:04:54 --> Final output sent to browser
DEBUG - 2015-10-09 11:04:54 --> Total execution time: 0.1057
DEBUG - 2015-10-09 11:04:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:54 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:54 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:54 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:54 --> URI Class Initialized
ERROR - 2015-10-09 11:04:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:04:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:54 --> URI Class Initialized
ERROR - 2015-10-09 11:04:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:04:54 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:54 --> Router Class Initialized
ERROR - 2015-10-09 11:04:54 --> 404 Page Not Found --> 
ERROR - 2015-10-09 11:04:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:04:55 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:55 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:55 --> Router Class Initialized
ERROR - 2015-10-09 11:04:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:04:59 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:59 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Output Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Security Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Input Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:04:59 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Loader Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:04:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:04:59 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:04:59 --> Session Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:04:59 --> Session routines successfully run
DEBUG - 2015-10-09 11:04:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Email Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Controller Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Auth MX_Controller Initialized
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:04:59 --> XSS Filtering completed
DEBUG - 2015-10-09 11:04:59 --> Unable to find validation rule: exists
DEBUG - 2015-10-09 11:04:59 --> XSS Filtering completed
DEBUG - 2015-10-09 11:04:59 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:04:59 --> URI Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Router Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Output Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Security Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Input Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:04:59 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Language Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Config Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Loader Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:04:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:04:59 --> Session Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:04:59 --> Session routines successfully run
DEBUG - 2015-10-09 11:04:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Email Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Controller Class Initialized
DEBUG - 2015-10-09 11:04:59 --> Admin MX_Controller Initialized
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 11:04:59 --> Model Class Initialized
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:04:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:04:59 --> Final output sent to browser
DEBUG - 2015-10-09 11:04:59 --> Total execution time: 0.1533
DEBUG - 2015-10-09 11:05:00 --> Config Class Initialized
DEBUG - 2015-10-09 11:05:00 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:05:00 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:05:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:05:00 --> URI Class Initialized
DEBUG - 2015-10-09 11:05:00 --> Router Class Initialized
ERROR - 2015-10-09 11:05:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:05:04 --> Config Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:05:04 --> URI Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Router Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Output Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Security Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Input Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:05:04 --> Language Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Language Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Config Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Loader Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:05:04 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:05:04 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:05:04 --> Session Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:05:04 --> Session routines successfully run
DEBUG - 2015-10-09 11:05:04 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Email Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Controller Class Initialized
DEBUG - 2015-10-09 11:05:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:05:04 --> Model Class Initialized
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:05:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:05:04 --> Final output sent to browser
DEBUG - 2015-10-09 11:05:04 --> Total execution time: 0.1494
DEBUG - 2015-10-09 11:05:05 --> Config Class Initialized
DEBUG - 2015-10-09 11:05:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:05:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:05:05 --> URI Class Initialized
DEBUG - 2015-10-09 11:05:05 --> Router Class Initialized
ERROR - 2015-10-09 11:05:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:07:39 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:07:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:07:39 --> URI Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Router Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Output Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Security Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Input Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:07:39 --> Language Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Language Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Loader Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:07:39 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:07:39 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:07:39 --> Session Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:07:39 --> Session routines successfully run
DEBUG - 2015-10-09 11:07:39 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Email Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Controller Class Initialized
DEBUG - 2015-10-09 11:07:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:07:39 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:07:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:07:39 --> Final output sent to browser
DEBUG - 2015-10-09 11:07:39 --> Total execution time: 0.1761
DEBUG - 2015-10-09 11:07:40 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:07:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:07:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:07:40 --> URI Class Initialized
DEBUG - 2015-10-09 11:07:40 --> Router Class Initialized
ERROR - 2015-10-09 11:07:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:07:43 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:07:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:07:43 --> URI Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Router Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Output Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Security Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Input Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:07:43 --> Language Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Language Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Loader Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:07:43 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:07:43 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:07:43 --> Session Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:07:43 --> Session routines successfully run
DEBUG - 2015-10-09 11:07:43 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Email Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Controller Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:07:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:07:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:07:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:07:43 --> Final output sent to browser
DEBUG - 2015-10-09 11:07:43 --> Total execution time: 0.1554
DEBUG - 2015-10-09 11:07:44 --> Config Class Initialized
DEBUG - 2015-10-09 11:07:44 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:07:44 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:07:44 --> URI Class Initialized
DEBUG - 2015-10-09 11:07:44 --> Router Class Initialized
ERROR - 2015-10-09 11:07:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:11:13 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:11:13 --> URI Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Router Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Output Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Security Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Input Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:11:13 --> Language Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Language Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Loader Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:11:13 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:11:13 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:11:13 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:11:13 --> Session Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:11:13 --> Session routines successfully run
DEBUG - 2015-10-09 11:11:13 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Email Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Controller Class Initialized
DEBUG - 2015-10-09 11:11:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:11:13 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:11:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:11:13 --> Final output sent to browser
DEBUG - 2015-10-09 11:11:13 --> Total execution time: 0.1424
DEBUG - 2015-10-09 11:11:14 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:11:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:11:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:11:14 --> URI Class Initialized
DEBUG - 2015-10-09 11:11:14 --> Router Class Initialized
ERROR - 2015-10-09 11:11:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:11:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:11:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:11:56 --> URI Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Router Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Output Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Security Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Input Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:11:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Loader Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:11:56 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:11:56 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:11:56 --> Session Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:11:56 --> Session routines successfully run
DEBUG - 2015-10-09 11:11:56 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Email Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Controller Class Initialized
DEBUG - 2015-10-09 11:11:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:11:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:11:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:11:56 --> Final output sent to browser
DEBUG - 2015-10-09 11:11:56 --> Total execution time: 0.3136
DEBUG - 2015-10-09 11:11:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:11:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:11:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:11:57 --> URI Class Initialized
DEBUG - 2015-10-09 11:11:57 --> Router Class Initialized
ERROR - 2015-10-09 11:11:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:12:18 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:18 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Router Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Output Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Security Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Input Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:12:18 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Loader Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:12:18 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:12:18 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:12:18 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:12:18 --> Session Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:12:18 --> Session routines successfully run
DEBUG - 2015-10-09 11:12:18 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Email Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Controller Class Initialized
DEBUG - 2015-10-09 11:12:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:12:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:12:18 --> Final output sent to browser
DEBUG - 2015-10-09 11:12:18 --> Total execution time: 0.1801
DEBUG - 2015-10-09 11:12:19 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:19 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:19 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:19 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:19 --> Router Class Initialized
ERROR - 2015-10-09 11:12:19 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:12:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:21 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Router Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Output Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Security Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Input Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:12:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Loader Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:12:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:12:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:12:21 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:12:21 --> Session Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:12:21 --> Session routines successfully run
DEBUG - 2015-10-09 11:12:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Email Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Controller Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:12:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:21 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Router Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Output Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Security Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Input Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:12:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Loader Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:12:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:12:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:12:21 --> Session Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:12:21 --> Session routines successfully run
DEBUG - 2015-10-09 11:12:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Email Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Controller Class Initialized
DEBUG - 2015-10-09 11:12:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:12:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:12:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:12:21 --> Final output sent to browser
DEBUG - 2015-10-09 11:12:21 --> Total execution time: 0.1466
DEBUG - 2015-10-09 11:12:22 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:22 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:22 --> Router Class Initialized
ERROR - 2015-10-09 11:12:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:12:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:57 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Router Class Initialized
DEBUG - 2015-10-09 11:12:57 --> No URI present. Default controller set.
DEBUG - 2015-10-09 11:12:57 --> Output Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Security Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Input Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:12:57 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Loader Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:12:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:12:57 --> Session Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:12:57 --> Session routines successfully run
DEBUG - 2015-10-09 11:12:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Email Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Controller Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Auth MX_Controller Initialized
DEBUG - 2015-10-09 11:12:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:12:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:12:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:12:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:12:57 --> URI Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Router Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Output Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Security Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Input Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:12:57 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Language Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Loader Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:12:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:12:57 --> Session Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:12:57 --> Session routines successfully run
DEBUG - 2015-10-09 11:12:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:12:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:12:58 --> Email Class Initialized
DEBUG - 2015-10-09 11:12:58 --> Controller Class Initialized
DEBUG - 2015-10-09 11:12:58 --> Admin MX_Controller Initialized
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 11:12:58 --> Model Class Initialized
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:12:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:12:58 --> Final output sent to browser
DEBUG - 2015-10-09 11:12:58 --> Total execution time: 0.1165
DEBUG - 2015-10-09 11:16:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:16:03 --> URI Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Router Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Output Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Security Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Input Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:16:03 --> Language Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Language Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Loader Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:16:03 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:16:03 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:16:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:16:03 --> Session Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:16:03 --> Session routines successfully run
DEBUG - 2015-10-09 11:16:03 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Email Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Controller Class Initialized
DEBUG - 2015-10-09 11:16:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:16:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:16:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:16:03 --> Final output sent to browser
DEBUG - 2015-10-09 11:16:03 --> Total execution time: 0.1871
DEBUG - 2015-10-09 11:16:05 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:16:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:16:05 --> URI Class Initialized
DEBUG - 2015-10-09 11:16:05 --> Router Class Initialized
ERROR - 2015-10-09 11:16:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:16:07 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:16:07 --> URI Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Router Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Output Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Security Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Input Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:16:07 --> Language Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Language Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Loader Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:16:07 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:16:07 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:16:07 --> Session Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:16:07 --> Session routines successfully run
DEBUG - 2015-10-09 11:16:07 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Email Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Controller Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:16:07 --> Model Class Initialized
DEBUG - 2015-10-09 11:16:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:16:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:16:07 --> Final output sent to browser
DEBUG - 2015-10-09 11:16:07 --> Total execution time: 0.1446
DEBUG - 2015-10-09 11:16:08 --> Config Class Initialized
DEBUG - 2015-10-09 11:16:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:16:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:16:08 --> URI Class Initialized
DEBUG - 2015-10-09 11:16:08 --> Router Class Initialized
ERROR - 2015-10-09 11:16:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:19:22 --> Config Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:19:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:19:22 --> URI Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Router Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Output Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Security Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Input Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:19:22 --> Language Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Language Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Config Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Loader Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:19:22 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:19:22 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:19:22 --> Session Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:19:22 --> Session routines successfully run
DEBUG - 2015-10-09 11:19:22 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Email Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Controller Class Initialized
DEBUG - 2015-10-09 11:19:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:19:22 --> Model Class Initialized
ERROR - 2015-10-09 11:19:22 --> Language file contains no data: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:19:22 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:19:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:19:22 --> Final output sent to browser
DEBUG - 2015-10-09 11:19:22 --> Total execution time: 0.1591
DEBUG - 2015-10-09 11:19:23 --> Config Class Initialized
DEBUG - 2015-10-09 11:19:23 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:19:23 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:19:23 --> URI Class Initialized
DEBUG - 2015-10-09 11:19:23 --> Router Class Initialized
ERROR - 2015-10-09 11:19:23 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:20:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:20:54 --> URI Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Router Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Output Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Security Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Input Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:20:54 --> Language Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Language Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Config Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Loader Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:20:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:20:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:20:54 --> Session Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:20:54 --> Session routines successfully run
DEBUG - 2015-10-09 11:20:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:20:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:20:55 --> Email Class Initialized
DEBUG - 2015-10-09 11:20:55 --> Controller Class Initialized
DEBUG - 2015-10-09 11:20:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:20:55 --> Model Class Initialized
DEBUG - 2015-10-09 11:20:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:20:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:20:55 --> Final output sent to browser
DEBUG - 2015-10-09 11:20:55 --> Total execution time: 0.1662
DEBUG - 2015-10-09 11:20:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:20:56 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:20:56 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:20:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:20:56 --> URI Class Initialized
DEBUG - 2015-10-09 11:20:56 --> Router Class Initialized
ERROR - 2015-10-09 11:20:56 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:21:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:21:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:21:21 --> URI Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Router Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Output Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Security Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Input Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:21:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Language Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Config Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Loader Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:21:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:21:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:21:21 --> Session Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:21:21 --> Session routines successfully run
DEBUG - 2015-10-09 11:21:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Email Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Controller Class Initialized
DEBUG - 2015-10-09 11:21:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:21:21 --> Model Class Initialized
ERROR - 2015-10-09 11:21:21 --> Language file contains no data: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:21:21 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:21:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:21:21 --> Final output sent to browser
DEBUG - 2015-10-09 11:21:21 --> Total execution time: 0.3147
DEBUG - 2015-10-09 11:21:22 --> Config Class Initialized
DEBUG - 2015-10-09 11:21:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:21:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:21:22 --> URI Class Initialized
DEBUG - 2015-10-09 11:21:22 --> Router Class Initialized
ERROR - 2015-10-09 11:21:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:22:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:22:36 --> URI Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Router Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Output Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Security Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Input Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:22:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Loader Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:22:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:22:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:22:36 --> Session Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:22:36 --> Session routines successfully run
DEBUG - 2015-10-09 11:22:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Email Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Controller Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:22:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:22:36 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:22:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:22:36 --> Final output sent to browser
DEBUG - 2015-10-09 11:22:36 --> Total execution time: 0.1923
DEBUG - 2015-10-09 11:22:37 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:22:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:22:37 --> URI Class Initialized
DEBUG - 2015-10-09 11:22:37 --> Router Class Initialized
ERROR - 2015-10-09 11:22:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:22:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:22:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:22:56 --> URI Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Router Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Output Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Security Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Input Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:22:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Loader Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:22:56 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:22:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:22:56 --> Session Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:22:56 --> Session routines successfully run
DEBUG - 2015-10-09 11:22:56 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Email Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Controller Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:22:56 --> Unable to find validation rule: customer
DEBUG - 2015-10-09 11:22:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:22:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:22:56 --> URI Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Router Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Output Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Security Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Input Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:22:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Loader Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:22:56 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:22:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:22:56 --> Session Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:22:56 --> Session routines successfully run
DEBUG - 2015-10-09 11:22:56 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Email Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Controller Class Initialized
DEBUG - 2015-10-09 11:22:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:22:56 --> Model Class Initialized
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:22:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:22:56 --> Final output sent to browser
DEBUG - 2015-10-09 11:22:56 --> Total execution time: 0.1441
DEBUG - 2015-10-09 11:22:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:22:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:22:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:22:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:22:57 --> URI Class Initialized
DEBUG - 2015-10-09 11:22:57 --> Router Class Initialized
ERROR - 2015-10-09 11:22:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:23:00 --> URI Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Router Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Output Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Security Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Input Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Loader Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:23:00 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:23:00 --> Session Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:23:00 --> Session routines successfully run
DEBUG - 2015-10-09 11:23:00 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Email Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Controller Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:23:00 --> Unable to find validation rule: customer
DEBUG - 2015-10-09 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:23:00 --> URI Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Router Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Output Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Security Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Input Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Loader Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:23:00 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:23:00 --> Session Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:23:00 --> Session routines successfully run
DEBUG - 2015-10-09 11:23:00 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Email Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Controller Class Initialized
DEBUG - 2015-10-09 11:23:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:23:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:23:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:23:01 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:23:01 --> Final output sent to browser
DEBUG - 2015-10-09 11:23:01 --> Total execution time: 0.1747
DEBUG - 2015-10-09 11:23:02 --> Config Class Initialized
DEBUG - 2015-10-09 11:23:02 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:23:02 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:23:02 --> URI Class Initialized
DEBUG - 2015-10-09 11:23:02 --> Router Class Initialized
ERROR - 2015-10-09 11:23:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:30:31 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:30:31 --> URI Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Router Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Output Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Security Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Input Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:30:31 --> Language Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Language Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Loader Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:30:31 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:30:31 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:30:31 --> Session Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:30:31 --> Session routines successfully run
DEBUG - 2015-10-09 11:30:31 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Email Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Controller Class Initialized
DEBUG - 2015-10-09 11:30:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:30:32 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:30:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:30:32 --> Final output sent to browser
DEBUG - 2015-10-09 11:30:32 --> Total execution time: 0.3400
DEBUG - 2015-10-09 11:30:33 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:33 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:30:33 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:30:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:30:33 --> URI Class Initialized
DEBUG - 2015-10-09 11:30:33 --> Router Class Initialized
ERROR - 2015-10-09 11:30:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:30:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:30:36 --> URI Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Router Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Output Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Security Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Input Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:30:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Loader Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:30:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:30:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
ERROR - 2015-10-09 11:30:36 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:30:36 --> Session Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:30:36 --> Session routines successfully run
DEBUG - 2015-10-09 11:30:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Email Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Controller Class Initialized
DEBUG - 2015-10-09 11:30:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:30:36 --> Model Class Initialized
ERROR - 2015-10-09 11:30:36 --> Language file contains no data: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:30:36 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:30:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:30:36 --> Final output sent to browser
DEBUG - 2015-10-09 11:30:36 --> Total execution time: 0.1890
DEBUG - 2015-10-09 11:30:37 --> Config Class Initialized
DEBUG - 2015-10-09 11:30:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:30:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:30:37 --> URI Class Initialized
DEBUG - 2015-10-09 11:30:37 --> Router Class Initialized
ERROR - 2015-10-09 11:30:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:33:35 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:33:35 --> URI Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Router Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Output Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Security Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Input Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:33:35 --> Language Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Language Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Loader Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:33:35 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:33:35 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:33:35 --> Session Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:33:35 --> Session routines successfully run
DEBUG - 2015-10-09 11:33:35 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Email Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Controller Class Initialized
DEBUG - 2015-10-09 11:33:35 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:33:35 --> Model Class Initialized
ERROR - 2015-10-09 11:33:35 --> Language file contains no data: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:33:35 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:33:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:33:35 --> Final output sent to browser
DEBUG - 2015-10-09 11:33:35 --> Total execution time: 0.1566
DEBUG - 2015-10-09 11:33:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:33:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:33:36 --> URI Class Initialized
DEBUG - 2015-10-09 11:33:36 --> Router Class Initialized
ERROR - 2015-10-09 11:33:36 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:33:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:33:46 --> URI Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Router Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Output Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Security Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Input Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:33:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Loader Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:33:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:33:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:33:46 --> Session Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:33:46 --> Session routines successfully run
DEBUG - 2015-10-09 11:33:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Email Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Controller Class Initialized
DEBUG - 2015-10-09 11:33:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:33:46 --> Model Class Initialized
ERROR - 2015-10-09 11:33:46 --> Language file contains no data: language/english/form_validation_lang.php
ERROR - 2015-10-09 11:33:46 --> Could not find the language line "greater_than"
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:33:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:33:46 --> Final output sent to browser
DEBUG - 2015-10-09 11:33:46 --> Total execution time: 0.1514
DEBUG - 2015-10-09 11:33:47 --> Config Class Initialized
DEBUG - 2015-10-09 11:33:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:33:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:33:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:33:47 --> URI Class Initialized
DEBUG - 2015-10-09 11:33:47 --> Router Class Initialized
ERROR - 2015-10-09 11:33:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:34:17 --> Config Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:34:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:34:17 --> URI Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Router Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Output Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Security Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Input Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:34:17 --> Language Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Language Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Config Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Loader Class Initialized
DEBUG - 2015-10-09 11:34:17 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:34:17 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:34:17 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:34:18 --> Session Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:34:18 --> Session routines successfully run
DEBUG - 2015-10-09 11:34:18 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Email Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Controller Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:34:18 --> Model Class Initialized
DEBUG - 2015-10-09 11:34:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:34:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:34:18 --> Final output sent to browser
DEBUG - 2015-10-09 11:34:18 --> Total execution time: 0.1433
DEBUG - 2015-10-09 11:34:19 --> Config Class Initialized
DEBUG - 2015-10-09 11:34:19 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:34:19 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:34:19 --> URI Class Initialized
DEBUG - 2015-10-09 11:34:19 --> Router Class Initialized
ERROR - 2015-10-09 11:34:19 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:35:11 --> Config Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:35:11 --> URI Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Router Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Output Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Security Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Input Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:35:11 --> Language Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Language Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Config Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Loader Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:35:11 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:35:11 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:35:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:35:11 --> Session Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:35:11 --> Session routines successfully run
DEBUG - 2015-10-09 11:35:11 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Email Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Controller Class Initialized
DEBUG - 2015-10-09 11:35:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:35:11 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:35:11 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:35:12 --> Model Class Initialized
DEBUG - 2015-10-09 11:35:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:35:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:35:12 --> Final output sent to browser
DEBUG - 2015-10-09 11:35:12 --> Total execution time: 0.1432
DEBUG - 2015-10-09 11:35:13 --> Config Class Initialized
DEBUG - 2015-10-09 11:35:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:35:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:35:13 --> URI Class Initialized
DEBUG - 2015-10-09 11:35:13 --> Router Class Initialized
ERROR - 2015-10-09 11:35:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:36:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:01 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:01 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:01 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:01 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:01 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:01 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:01 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:36:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:01 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:02 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:02 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:02 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:02 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:02 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:36:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:36:02 --> Final output sent to browser
DEBUG - 2015-10-09 11:36:02 --> Total execution time: 0.1434
DEBUG - 2015-10-09 11:36:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:03 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:03 --> Router Class Initialized
ERROR - 2015-10-09 11:36:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:36:06 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:06 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:06 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:06 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:06 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:06 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:06 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:36:06 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:06 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:06 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:06 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:06 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:06 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:06 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:06 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:36:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:36:06 --> Final output sent to browser
DEBUG - 2015-10-09 11:36:06 --> Total execution time: 0.1411
DEBUG - 2015-10-09 11:36:07 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:07 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:07 --> Router Class Initialized
ERROR - 2015-10-09 11:36:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:36:16 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:16 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:16 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:16 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:16 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:16 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:16 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:16 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:16 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:36:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:36:16 --> Final output sent to browser
DEBUG - 2015-10-09 11:36:16 --> Total execution time: 0.1433
DEBUG - 2015-10-09 11:36:17 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:17 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:17 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:17 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:17 --> Router Class Initialized
ERROR - 2015-10-09 11:36:17 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:36:42 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:42 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:42 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:42 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:42 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:43 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:43 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:43 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:36:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:36:43 --> Final output sent to browser
DEBUG - 2015-10-09 11:36:43 --> Total execution time: 0.1613
DEBUG - 2015-10-09 11:36:44 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:44 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:44 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:44 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:44 --> Router Class Initialized
ERROR - 2015-10-09 11:36:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:36:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:46 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Router Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Output Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Security Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Input Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:36:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Loader Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:36:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:36:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:36:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:36:46 --> Session Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:36:46 --> Session routines successfully run
DEBUG - 2015-10-09 11:36:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Email Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Controller Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:36:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:36:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:36:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:36:46 --> Final output sent to browser
DEBUG - 2015-10-09 11:36:46 --> Total execution time: 0.1449
DEBUG - 2015-10-09 11:36:47 --> Config Class Initialized
DEBUG - 2015-10-09 11:36:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:36:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:36:47 --> URI Class Initialized
DEBUG - 2015-10-09 11:36:47 --> Router Class Initialized
ERROR - 2015-10-09 11:36:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:46:20 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:46:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:46:20 --> URI Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Router Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Output Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Security Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Input Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:46:20 --> Language Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Language Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Loader Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:46:20 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:46:20 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:46:20 --> Session Class Initialized
DEBUG - 2015-10-09 11:46:20 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:46:20 --> Session routines successfully run
DEBUG - 2015-10-09 11:46:20 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Email Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Controller Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:46:21 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:46:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:46:21 --> Final output sent to browser
DEBUG - 2015-10-09 11:46:21 --> Total execution time: 0.1578
DEBUG - 2015-10-09 11:46:22 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:46:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:46:22 --> URI Class Initialized
DEBUG - 2015-10-09 11:46:22 --> Router Class Initialized
ERROR - 2015-10-09 11:46:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:46:48 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:46:48 --> URI Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Router Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Output Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Security Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Input Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:46:48 --> Language Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Language Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Loader Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:46:48 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:46:48 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:46:48 --> Session Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:46:48 --> Session routines successfully run
DEBUG - 2015-10-09 11:46:48 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Email Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Controller Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:46:48 --> Model Class Initialized
DEBUG - 2015-10-09 11:46:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:46:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:46:48 --> Final output sent to browser
DEBUG - 2015-10-09 11:46:48 --> Total execution time: 0.1758
DEBUG - 2015-10-09 11:46:49 --> Config Class Initialized
DEBUG - 2015-10-09 11:46:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:46:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:46:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:46:49 --> URI Class Initialized
DEBUG - 2015-10-09 11:46:49 --> Router Class Initialized
ERROR - 2015-10-09 11:46:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:47:30 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:47:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:47:30 --> URI Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Router Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Output Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Security Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Input Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:47:30 --> Language Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Language Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Loader Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:47:30 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:47:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:47:30 --> Session Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:47:30 --> Session routines successfully run
DEBUG - 2015-10-09 11:47:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:47:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Email Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Controller Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:47:31 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:47:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:47:31 --> Final output sent to browser
DEBUG - 2015-10-09 11:47:31 --> Total execution time: 0.1754
DEBUG - 2015-10-09 11:47:31 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:47:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:47:31 --> URI Class Initialized
DEBUG - 2015-10-09 11:47:31 --> Router Class Initialized
ERROR - 2015-10-09 11:47:31 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:47:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:47:46 --> URI Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Router Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Output Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Security Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Input Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:47:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Language Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Loader Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:47:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:47:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:47:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:47:46 --> Session Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:47:46 --> Session routines successfully run
DEBUG - 2015-10-09 11:47:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Email Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Controller Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:47:46 --> Model Class Initialized
DEBUG - 2015-10-09 11:47:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:47:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:47:46 --> Final output sent to browser
DEBUG - 2015-10-09 11:47:46 --> Total execution time: 0.1424
DEBUG - 2015-10-09 11:47:47 --> Config Class Initialized
DEBUG - 2015-10-09 11:47:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:47:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:47:47 --> URI Class Initialized
DEBUG - 2015-10-09 11:47:47 --> Router Class Initialized
ERROR - 2015-10-09 11:47:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:48:28 --> Config Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:48:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:48:28 --> URI Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Router Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Output Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Security Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Input Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:48:28 --> Language Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Language Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Config Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Loader Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:48:28 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:48:28 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:48:28 --> Session Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:48:28 --> Session routines successfully run
DEBUG - 2015-10-09 11:48:28 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Email Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Controller Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:48:28 --> Model Class Initialized
DEBUG - 2015-10-09 11:48:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:48:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:48:28 --> Final output sent to browser
DEBUG - 2015-10-09 11:48:28 --> Total execution time: 0.1699
DEBUG - 2015-10-09 11:48:29 --> Config Class Initialized
DEBUG - 2015-10-09 11:48:29 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:48:29 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:48:29 --> URI Class Initialized
DEBUG - 2015-10-09 11:48:29 --> Router Class Initialized
ERROR - 2015-10-09 11:48:29 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:49:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:49:56 --> URI Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Router Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Output Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Security Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Input Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:49:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Language Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Config Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Loader Class Initialized
DEBUG - 2015-10-09 11:49:56 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:49:56 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:49:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:49:57 --> Session Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:49:57 --> Session routines successfully run
DEBUG - 2015-10-09 11:49:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Email Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Controller Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:49:57 --> Model Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:49:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:49:57 --> Final output sent to browser
DEBUG - 2015-10-09 11:49:57 --> Total execution time: 0.1749
DEBUG - 2015-10-09 11:49:57 --> Config Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:49:57 --> URI Class Initialized
DEBUG - 2015-10-09 11:49:57 --> Router Class Initialized
ERROR - 2015-10-09 11:49:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:51:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:51:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:51:36 --> URI Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Router Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Output Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Security Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Input Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:51:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Language Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Config Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Loader Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:51:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:51:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:51:36 --> Session Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:51:36 --> Session routines successfully run
DEBUG - 2015-10-09 11:51:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Email Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Controller Class Initialized
DEBUG - 2015-10-09 11:51:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:51:36 --> Model Class Initialized
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:51:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:51:36 --> Final output sent to browser
DEBUG - 2015-10-09 11:51:36 --> Total execution time: 0.1622
DEBUG - 2015-10-09 11:51:37 --> Config Class Initialized
DEBUG - 2015-10-09 11:51:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:51:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:51:37 --> URI Class Initialized
DEBUG - 2015-10-09 11:51:37 --> Router Class Initialized
ERROR - 2015-10-09 11:51:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:52:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:52:01 --> URI Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Router Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Output Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Security Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Input Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:52:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Language Class Initialized
DEBUG - 2015-10-09 11:52:01 --> Config Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Loader Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:52:02 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:52:02 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:52:02 --> Session Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:52:02 --> Session routines successfully run
DEBUG - 2015-10-09 11:52:02 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Email Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Controller Class Initialized
DEBUG - 2015-10-09 11:52:02 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:52:02 --> Model Class Initialized
ERROR - 2015-10-09 11:52:02 --> Severity: Notice  --> Undefined variable: customers C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 9
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:52:02 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:52:02 --> Final output sent to browser
DEBUG - 2015-10-09 11:52:02 --> Total execution time: 0.1629
DEBUG - 2015-10-09 11:52:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:52:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:52:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:52:03 --> URI Class Initialized
DEBUG - 2015-10-09 11:52:03 --> Router Class Initialized
ERROR - 2015-10-09 11:52:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:53:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:53:03 --> URI Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Router Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Output Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Security Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Input Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:53:03 --> Language Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Language Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Config Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Loader Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:53:03 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:53:03 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:53:03 --> Session Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:53:03 --> Session routines successfully run
DEBUG - 2015-10-09 11:53:03 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Email Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Controller Class Initialized
DEBUG - 2015-10-09 11:53:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:53:03 --> Model Class Initialized
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:53:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:53:03 --> Final output sent to browser
DEBUG - 2015-10-09 11:53:03 --> Total execution time: 0.1758
DEBUG - 2015-10-09 11:53:04 --> Config Class Initialized
DEBUG - 2015-10-09 11:53:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:53:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:53:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:53:04 --> URI Class Initialized
DEBUG - 2015-10-09 11:53:04 --> Router Class Initialized
ERROR - 2015-10-09 11:53:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:57:47 --> Config Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:57:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:57:47 --> URI Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Router Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Output Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Security Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Input Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:57:47 --> Language Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Language Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Config Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Loader Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:57:47 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:57:47 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:57:47 --> Session Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:57:47 --> Session routines successfully run
DEBUG - 2015-10-09 11:57:47 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Email Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Controller Class Initialized
DEBUG - 2015-10-09 11:57:47 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:57:47 --> Model Class Initialized
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:57:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:57:47 --> Final output sent to browser
DEBUG - 2015-10-09 11:57:47 --> Total execution time: 0.1816
DEBUG - 2015-10-09 11:57:48 --> Config Class Initialized
DEBUG - 2015-10-09 11:57:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:57:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:57:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:57:48 --> URI Class Initialized
DEBUG - 2015-10-09 11:57:48 --> Router Class Initialized
ERROR - 2015-10-09 11:57:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 11:58:10 --> Config Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:58:10 --> URI Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Router Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Output Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Security Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Input Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 11:58:10 --> Language Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Language Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Config Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Loader Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Helper loaded: url_helper
DEBUG - 2015-10-09 11:58:10 --> Helper loaded: form_helper
DEBUG - 2015-10-09 11:58:10 --> Database Driver Class Initialized
ERROR - 2015-10-09 11:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 11:58:10 --> Session Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Helper loaded: string_helper
DEBUG - 2015-10-09 11:58:10 --> Session routines successfully run
DEBUG - 2015-10-09 11:58:10 --> Form Validation Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Pagination Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Encrypt Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Email Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Controller Class Initialized
DEBUG - 2015-10-09 11:58:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 11:58:10 --> Model Class Initialized
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 11:58:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 11:58:10 --> Final output sent to browser
DEBUG - 2015-10-09 11:58:10 --> Total execution time: 0.1443
DEBUG - 2015-10-09 11:58:11 --> Config Class Initialized
DEBUG - 2015-10-09 11:58:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 11:58:12 --> Utf8 Class Initialized
DEBUG - 2015-10-09 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 11:58:12 --> URI Class Initialized
DEBUG - 2015-10-09 11:58:12 --> Router Class Initialized
ERROR - 2015-10-09 11:58:12 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:00:13 --> Config Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:00:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:00:13 --> URI Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Router Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Output Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Security Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Input Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:00:13 --> Language Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Language Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Config Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Loader Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:00:13 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:00:13 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:00:13 --> Session Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:00:13 --> Session routines successfully run
DEBUG - 2015-10-09 12:00:13 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Email Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Controller Class Initialized
DEBUG - 2015-10-09 12:00:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:00:13 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:00:13 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:00:13 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:00:13 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:00:13 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:00:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:00:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:00:14 --> Final output sent to browser
DEBUG - 2015-10-09 12:00:14 --> Total execution time: 0.1871
DEBUG - 2015-10-09 12:00:15 --> Config Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:00:15 --> URI Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Router Class Initialized
ERROR - 2015-10-09 12:00:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:00:15 --> Config Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:00:15 --> URI Class Initialized
DEBUG - 2015-10-09 12:00:15 --> Router Class Initialized
ERROR - 2015-10-09 12:00:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:01:08 --> Config Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:01:08 --> URI Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Router Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Output Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Security Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Input Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:01:08 --> Language Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Language Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Config Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Loader Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:01:08 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:01:08 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:01:08 --> Session Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:01:08 --> Session routines successfully run
DEBUG - 2015-10-09 12:01:08 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Email Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Controller Class Initialized
DEBUG - 2015-10-09 12:01:08 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:01:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:01:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:01:08 --> Final output sent to browser
DEBUG - 2015-10-09 12:01:08 --> Total execution time: 0.3524
DEBUG - 2015-10-09 12:01:10 --> Config Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:01:10 --> URI Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Router Class Initialized
ERROR - 2015-10-09 12:01:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:01:10 --> Config Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:01:10 --> URI Class Initialized
DEBUG - 2015-10-09 12:01:10 --> Router Class Initialized
ERROR - 2015-10-09 12:01:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:05:37 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:05:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:05:37 --> URI Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Router Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Output Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Security Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Input Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:05:37 --> Language Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Language Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Loader Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:05:37 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:05:37 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:05:37 --> Session Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:05:37 --> Session routines successfully run
DEBUG - 2015-10-09 12:05:37 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Email Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Controller Class Initialized
DEBUG - 2015-10-09 12:05:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:05:37 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:05:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:05:37 --> Final output sent to browser
DEBUG - 2015-10-09 12:05:37 --> Total execution time: 0.1829
DEBUG - 2015-10-09 12:05:38 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:05:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:05:38 --> URI Class Initialized
DEBUG - 2015-10-09 12:05:38 --> Router Class Initialized
ERROR - 2015-10-09 12:05:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:05:51 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:05:51 --> URI Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Router Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Output Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Security Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Input Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:05:51 --> Language Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Language Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Loader Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:05:51 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:05:51 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:05:51 --> Session Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:05:51 --> Session routines successfully run
DEBUG - 2015-10-09 12:05:51 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Email Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Controller Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:05:51 --> Model Class Initialized
DEBUG - 2015-10-09 12:05:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:05:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:05:51 --> Final output sent to browser
DEBUG - 2015-10-09 12:05:51 --> Total execution time: 0.1667
DEBUG - 2015-10-09 12:05:52 --> Config Class Initialized
DEBUG - 2015-10-09 12:05:52 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:05:52 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:05:52 --> URI Class Initialized
DEBUG - 2015-10-09 12:05:52 --> Router Class Initialized
ERROR - 2015-10-09 12:05:52 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:07:54 --> Config Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:07:54 --> URI Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Router Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Output Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Security Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Input Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:07:54 --> Language Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Language Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Config Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Loader Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:07:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:07:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:07:54 --> Session Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:07:54 --> Session routines successfully run
DEBUG - 2015-10-09 12:07:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Email Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Controller Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:07:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:07:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:07:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:07:54 --> Final output sent to browser
DEBUG - 2015-10-09 12:07:54 --> Total execution time: 0.1487
DEBUG - 2015-10-09 12:07:55 --> Config Class Initialized
DEBUG - 2015-10-09 12:07:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:07:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:07:55 --> URI Class Initialized
DEBUG - 2015-10-09 12:07:55 --> Router Class Initialized
ERROR - 2015-10-09 12:07:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:08:03 --> Config Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:08:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:08:03 --> URI Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Router Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Output Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Security Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Input Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:08:03 --> Language Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Language Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Config Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Loader Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:08:03 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:08:03 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:08:03 --> Session Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:08:03 --> Session routines successfully run
DEBUG - 2015-10-09 12:08:03 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Email Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Controller Class Initialized
DEBUG - 2015-10-09 12:08:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:08:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:08:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:08:03 --> Final output sent to browser
DEBUG - 2015-10-09 12:08:03 --> Total execution time: 0.1417
DEBUG - 2015-10-09 12:08:04 --> Config Class Initialized
DEBUG - 2015-10-09 12:08:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:08:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:08:04 --> URI Class Initialized
DEBUG - 2015-10-09 12:08:04 --> Router Class Initialized
ERROR - 2015-10-09 12:08:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:09:07 --> Config Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:09:07 --> URI Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Router Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Output Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Security Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Input Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:09:07 --> Language Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Language Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Config Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Loader Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:09:07 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:09:07 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:09:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:09:07 --> Session Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:09:07 --> Session routines successfully run
DEBUG - 2015-10-09 12:09:07 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Email Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Controller Class Initialized
DEBUG - 2015-10-09 12:09:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:09:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:09:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:09:07 --> Final output sent to browser
DEBUG - 2015-10-09 12:09:07 --> Total execution time: 0.1419
DEBUG - 2015-10-09 12:09:08 --> Config Class Initialized
DEBUG - 2015-10-09 12:09:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:09:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:09:08 --> URI Class Initialized
DEBUG - 2015-10-09 12:09:08 --> Router Class Initialized
ERROR - 2015-10-09 12:09:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:11:55 --> Config Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:11:55 --> URI Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Router Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Output Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Security Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Input Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:11:55 --> Language Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Language Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Config Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Loader Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:11:55 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:11:55 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:11:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:11:55 --> Session Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:11:55 --> Session routines successfully run
DEBUG - 2015-10-09 12:11:55 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Email Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Controller Class Initialized
DEBUG - 2015-10-09 12:11:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:11:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:11:55 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Config Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:12:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:12:24 --> URI Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Router Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Output Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Security Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Input Class Initialized
DEBUG - 2015-10-09 12:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:12:24 --> Language Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Language Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Config Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Loader Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:12:25 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:12:25 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:12:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:12:25 --> Session Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:12:25 --> Session routines successfully run
DEBUG - 2015-10-09 12:12:25 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Email Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Controller Class Initialized
DEBUG - 2015-10-09 12:12:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:12:25 --> Model Class Initialized
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:12:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:12:25 --> Final output sent to browser
DEBUG - 2015-10-09 12:12:25 --> Total execution time: 0.2282
DEBUG - 2015-10-09 12:12:26 --> Config Class Initialized
DEBUG - 2015-10-09 12:12:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:12:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:12:26 --> URI Class Initialized
DEBUG - 2015-10-09 12:12:26 --> Router Class Initialized
ERROR - 2015-10-09 12:12:26 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:13:07 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:07 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Router Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Output Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Security Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Input Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:13:07 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Loader Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:13:07 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:13:07 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:13:07 --> Session Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:13:07 --> Session routines successfully run
DEBUG - 2015-10-09 12:13:07 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Email Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Controller Class Initialized
DEBUG - 2015-10-09 12:13:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:13:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:13:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:13:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:13:07 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:13:08 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:13:08 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:13:08 --> Final output sent to browser
DEBUG - 2015-10-09 12:13:08 --> Total execution time: 0.1584
DEBUG - 2015-10-09 12:13:08 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:08 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:08 --> Router Class Initialized
ERROR - 2015-10-09 12:13:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:13:25 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:25 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:25 --> Router Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Output Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Security Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Input Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:13:26 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Loader Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:13:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:13:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:13:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:13:26 --> Session Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:13:26 --> Session routines successfully run
DEBUG - 2015-10-09 12:13:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Email Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Controller Class Initialized
DEBUG - 2015-10-09 12:13:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:13:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:13:26 --> Final output sent to browser
DEBUG - 2015-10-09 12:13:26 --> Total execution time: 0.3080
DEBUG - 2015-10-09 12:13:27 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:27 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:27 --> Router Class Initialized
ERROR - 2015-10-09 12:13:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:13:42 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:42 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Router Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Output Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Security Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Input Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:13:42 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Language Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Loader Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:13:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:13:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:13:42 --> Session Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:13:42 --> Session routines successfully run
DEBUG - 2015-10-09 12:13:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Email Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Controller Class Initialized
DEBUG - 2015-10-09 12:13:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:13:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:13:42 --> Final output sent to browser
DEBUG - 2015-10-09 12:13:42 --> Total execution time: 0.3495
DEBUG - 2015-10-09 12:13:43 --> Config Class Initialized
DEBUG - 2015-10-09 12:13:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:13:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:13:43 --> URI Class Initialized
DEBUG - 2015-10-09 12:13:43 --> Router Class Initialized
ERROR - 2015-10-09 12:13:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:14:18 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:14:18 --> URI Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Router Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Output Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Security Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Input Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:14:18 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Loader Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:14:18 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:14:18 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:14:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:14:18 --> Session Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:14:18 --> Session routines successfully run
DEBUG - 2015-10-09 12:14:18 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Email Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Controller Class Initialized
DEBUG - 2015-10-09 12:14:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:14:18 --> Model Class Initialized
ERROR - 2015-10-09 12:14:18 --> Severity: Notice  --> Use of undefined constant num_rows - assumed 'num_rows' C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 47
DEBUG - 2015-10-09 12:14:21 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:14:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:14:21 --> URI Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Router Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Output Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Security Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Input Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:14:21 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Loader Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:14:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:14:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:14:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:14:21 --> Session Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:14:21 --> Session routines successfully run
DEBUG - 2015-10-09 12:14:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Email Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Controller Class Initialized
DEBUG - 2015-10-09 12:14:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:14:21 --> Model Class Initialized
ERROR - 2015-10-09 12:14:21 --> Severity: Notice  --> Use of undefined constant num_rows - assumed 'num_rows' C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_individual_payments.php 47
DEBUG - 2015-10-09 12:14:31 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:14:31 --> URI Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Router Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Output Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Security Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Input Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:14:31 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Language Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Loader Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:14:31 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:14:31 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:14:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:14:31 --> Session Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:14:31 --> Session routines successfully run
DEBUG - 2015-10-09 12:14:31 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Email Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Controller Class Initialized
DEBUG - 2015-10-09 12:14:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:14:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:14:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:14:31 --> Final output sent to browser
DEBUG - 2015-10-09 12:14:31 --> Total execution time: 0.1908
DEBUG - 2015-10-09 12:14:32 --> Config Class Initialized
DEBUG - 2015-10-09 12:14:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:14:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:14:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:14:32 --> URI Class Initialized
DEBUG - 2015-10-09 12:14:32 --> Router Class Initialized
ERROR - 2015-10-09 12:14:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:15:32 --> Config Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:15:32 --> URI Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Router Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Output Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Security Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Input Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:15:32 --> Language Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Language Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Config Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Loader Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:15:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:15:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:15:32 --> Session Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:15:32 --> Session routines successfully run
DEBUG - 2015-10-09 12:15:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Email Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Controller Class Initialized
DEBUG - 2015-10-09 12:15:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:15:32 --> Model Class Initialized
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:15:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:15:32 --> Final output sent to browser
DEBUG - 2015-10-09 12:15:32 --> Total execution time: 0.2455
DEBUG - 2015-10-09 12:15:33 --> Config Class Initialized
DEBUG - 2015-10-09 12:15:33 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:15:33 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:15:33 --> URI Class Initialized
DEBUG - 2015-10-09 12:15:33 --> Router Class Initialized
ERROR - 2015-10-09 12:15:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:16:54 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:16:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:16:54 --> URI Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Router Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Output Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Security Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Input Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:16:54 --> Language Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Language Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Loader Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:16:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:16:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:16:54 --> Session Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:16:54 --> Session routines successfully run
DEBUG - 2015-10-09 12:16:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Email Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Controller Class Initialized
DEBUG - 2015-10-09 12:16:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:16:54 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:16:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:16:54 --> Final output sent to browser
DEBUG - 2015-10-09 12:16:54 --> Total execution time: 0.1608
DEBUG - 2015-10-09 12:16:55 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:16:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:16:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:16:55 --> URI Class Initialized
DEBUG - 2015-10-09 12:16:55 --> Router Class Initialized
ERROR - 2015-10-09 12:16:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:16:58 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:16:58 --> URI Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Router Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Output Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Security Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Input Class Initialized
DEBUG - 2015-10-09 12:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:16:58 --> Language Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Language Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Loader Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:16:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:16:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:16:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:16:59 --> Session Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:16:59 --> Session routines successfully run
DEBUG - 2015-10-09 12:16:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Email Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Controller Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:16:59 --> Model Class Initialized
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:16:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:16:59 --> Final output sent to browser
DEBUG - 2015-10-09 12:16:59 --> Total execution time: 0.1555
DEBUG - 2015-10-09 12:16:59 --> Config Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:16:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:16:59 --> URI Class Initialized
DEBUG - 2015-10-09 12:16:59 --> Router Class Initialized
ERROR - 2015-10-09 12:16:59 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:17:47 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:17:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:17:47 --> URI Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Router Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Output Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Security Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Input Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:17:47 --> Language Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Language Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Loader Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:17:47 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:17:47 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:17:47 --> Session Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:17:47 --> Session routines successfully run
DEBUG - 2015-10-09 12:17:47 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Email Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Controller Class Initialized
DEBUG - 2015-10-09 12:17:47 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:17:47 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:17:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:17:47 --> Final output sent to browser
DEBUG - 2015-10-09 12:17:47 --> Total execution time: 0.2373
DEBUG - 2015-10-09 12:17:48 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:17:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:17:48 --> URI Class Initialized
DEBUG - 2015-10-09 12:17:48 --> Router Class Initialized
ERROR - 2015-10-09 12:17:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:17:58 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:17:58 --> URI Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Router Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Output Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Security Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Input Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:17:58 --> Language Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Language Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Loader Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:17:58 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:17:58 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:17:58 --> Session Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:17:58 --> Session routines successfully run
DEBUG - 2015-10-09 12:17:58 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Email Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Controller Class Initialized
DEBUG - 2015-10-09 12:17:58 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:17:58 --> Model Class Initialized
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/microfinance/views/loans_plan/add_loans_plan.php
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:17:58 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:17:58 --> Final output sent to browser
DEBUG - 2015-10-09 12:17:58 --> Total execution time: 0.1450
DEBUG - 2015-10-09 12:17:59 --> Config Class Initialized
DEBUG - 2015-10-09 12:17:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:17:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:17:59 --> URI Class Initialized
DEBUG - 2015-10-09 12:17:59 --> Router Class Initialized
ERROR - 2015-10-09 12:17:59 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:18:36 --> Config Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:18:36 --> URI Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Router Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Output Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Security Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Input Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:18:36 --> Language Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Language Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Config Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Loader Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:18:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:18:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:18:36 --> Session Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:18:36 --> Session routines successfully run
DEBUG - 2015-10-09 12:18:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Email Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Controller Class Initialized
DEBUG - 2015-10-09 12:18:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:18:36 --> Model Class Initialized
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:18:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:18:36 --> Final output sent to browser
DEBUG - 2015-10-09 12:18:36 --> Total execution time: 0.1401
DEBUG - 2015-10-09 12:18:37 --> Config Class Initialized
DEBUG - 2015-10-09 12:18:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:18:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:18:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:18:37 --> URI Class Initialized
DEBUG - 2015-10-09 12:18:37 --> Router Class Initialized
ERROR - 2015-10-09 12:18:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:18:43 --> Config Class Initialized
DEBUG - 2015-10-09 12:18:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:18:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:18:43 --> URI Class Initialized
DEBUG - 2015-10-09 12:18:43 --> Router Class Initialized
ERROR - 2015-10-09 12:18:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:18:46 --> Config Class Initialized
DEBUG - 2015-10-09 12:18:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:18:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:18:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:18:46 --> URI Class Initialized
DEBUG - 2015-10-09 12:18:46 --> Router Class Initialized
ERROR - 2015-10-09 12:18:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:22:39 --> Config Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:22:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:22:39 --> URI Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Router Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Output Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Security Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Input Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:22:39 --> Language Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Language Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Config Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Loader Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:22:39 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:22:39 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:22:39 --> Session Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:22:39 --> Session routines successfully run
DEBUG - 2015-10-09 12:22:39 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Email Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Controller Class Initialized
DEBUG - 2015-10-09 12:22:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:22:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:22:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:22:39 --> Final output sent to browser
DEBUG - 2015-10-09 12:22:39 --> Total execution time: 0.1596
DEBUG - 2015-10-09 12:22:40 --> Config Class Initialized
DEBUG - 2015-10-09 12:22:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:22:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:22:40 --> URI Class Initialized
DEBUG - 2015-10-09 12:22:40 --> Router Class Initialized
ERROR - 2015-10-09 12:22:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:24:24 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:24:24 --> URI Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Router Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Output Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Security Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Input Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:24:24 --> Language Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Language Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Loader Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:24:24 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:24:24 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:24:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:24:24 --> Session Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:24:24 --> Session routines successfully run
DEBUG - 2015-10-09 12:24:24 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Email Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Controller Class Initialized
DEBUG - 2015-10-09 12:24:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:24:24 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:24:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:24:24 --> Final output sent to browser
DEBUG - 2015-10-09 12:24:24 --> Total execution time: 0.1454
DEBUG - 2015-10-09 12:24:25 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:24:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:24:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:24:25 --> URI Class Initialized
DEBUG - 2015-10-09 12:24:25 --> Router Class Initialized
ERROR - 2015-10-09 12:24:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:24:38 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:24:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:24:38 --> URI Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Router Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Output Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Security Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Input Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:24:38 --> Language Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Language Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Loader Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:24:38 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:24:38 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:24:38 --> Session Class Initialized
DEBUG - 2015-10-09 12:24:38 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:24:38 --> Session routines successfully run
DEBUG - 2015-10-09 12:24:38 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:24:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:24:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:24:39 --> Email Class Initialized
DEBUG - 2015-10-09 12:24:39 --> Controller Class Initialized
DEBUG - 2015-10-09 12:24:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:24:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:24:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:24:39 --> Final output sent to browser
DEBUG - 2015-10-09 12:24:39 --> Total execution time: 0.1459
DEBUG - 2015-10-09 12:24:40 --> Config Class Initialized
DEBUG - 2015-10-09 12:24:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:24:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:24:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:24:40 --> URI Class Initialized
DEBUG - 2015-10-09 12:24:40 --> Router Class Initialized
ERROR - 2015-10-09 12:24:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:25:18 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:25:18 --> URI Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Router Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Output Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Security Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Input Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:25:18 --> Language Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Language Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Loader Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:25:18 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:25:18 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:25:18 --> Session Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:25:18 --> Session routines successfully run
DEBUG - 2015-10-09 12:25:18 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Email Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Controller Class Initialized
DEBUG - 2015-10-09 12:25:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:25:18 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:25:18 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:25:18 --> Final output sent to browser
DEBUG - 2015-10-09 12:25:18 --> Total execution time: 0.3991
DEBUG - 2015-10-09 12:25:19 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:19 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:25:19 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:25:19 --> URI Class Initialized
DEBUG - 2015-10-09 12:25:19 --> Router Class Initialized
ERROR - 2015-10-09 12:25:19 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:25:39 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:25:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:25:39 --> URI Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Router Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Output Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Security Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Input Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:25:39 --> Language Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Language Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Loader Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:25:39 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:25:39 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:25:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:25:39 --> Session Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:25:39 --> Session routines successfully run
DEBUG - 2015-10-09 12:25:39 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Email Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Controller Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:25:39 --> Model Class Initialized
DEBUG - 2015-10-09 12:25:39 --> Final output sent to browser
DEBUG - 2015-10-09 12:25:39 --> Total execution time: 0.1175
DEBUG - 2015-10-09 12:25:42 --> Config Class Initialized
DEBUG - 2015-10-09 12:25:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:25:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:25:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:25:42 --> URI Class Initialized
DEBUG - 2015-10-09 12:25:42 --> Router Class Initialized
ERROR - 2015-10-09 12:25:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:26:43 --> Config Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:26:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:26:43 --> URI Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Router Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Output Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Security Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Input Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:26:43 --> Language Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Language Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Config Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Loader Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:26:43 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:26:43 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:26:43 --> Session Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:26:43 --> Session routines successfully run
DEBUG - 2015-10-09 12:26:43 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Email Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Controller Class Initialized
DEBUG - 2015-10-09 12:26:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:26:43 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:26:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:26:43 --> Final output sent to browser
DEBUG - 2015-10-09 12:26:43 --> Total execution time: 0.1405
DEBUG - 2015-10-09 12:26:44 --> Config Class Initialized
DEBUG - 2015-10-09 12:26:44 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:26:44 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:26:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:26:44 --> URI Class Initialized
DEBUG - 2015-10-09 12:26:44 --> Router Class Initialized
ERROR - 2015-10-09 12:26:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:26:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:26:49 --> URI Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Router Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Output Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Security Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Input Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:26:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Loader Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:26:49 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:26:49 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:26:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:26:49 --> Session Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:26:49 --> Session routines successfully run
DEBUG - 2015-10-09 12:26:49 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Email Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Controller Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:26:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:26:49 --> Final output sent to browser
DEBUG - 2015-10-09 12:26:49 --> Total execution time: 0.1208
DEBUG - 2015-10-09 12:27:03 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:27:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:27:03 --> URI Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Router Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Output Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Security Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Input Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:27:03 --> Language Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Language Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Loader Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:27:03 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:27:03 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:27:03 --> Session Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:27:03 --> Session routines successfully run
DEBUG - 2015-10-09 12:27:03 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Email Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Controller Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:27:03 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:27:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:27:03 --> Final output sent to browser
DEBUG - 2015-10-09 12:27:03 --> Total execution time: 0.1417
DEBUG - 2015-10-09 12:27:04 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:27:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:27:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:27:04 --> URI Class Initialized
DEBUG - 2015-10-09 12:27:04 --> Router Class Initialized
ERROR - 2015-10-09 12:27:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:27:14 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:27:14 --> URI Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Router Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Output Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Security Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Input Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:27:14 --> Language Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Language Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Loader Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:27:14 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:27:14 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:27:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:27:14 --> Session Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:27:14 --> Session routines successfully run
DEBUG - 2015-10-09 12:27:14 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Email Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Controller Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:27:14 --> Model Class Initialized
DEBUG - 2015-10-09 12:27:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:27:14 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:27:14 --> Final output sent to browser
DEBUG - 2015-10-09 12:27:14 --> Total execution time: 0.1430
DEBUG - 2015-10-09 12:27:15 --> Config Class Initialized
DEBUG - 2015-10-09 12:27:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:27:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:27:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:27:15 --> URI Class Initialized
DEBUG - 2015-10-09 12:27:15 --> Router Class Initialized
ERROR - 2015-10-09 12:27:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:28:57 --> Config Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:28:57 --> URI Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Router Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Output Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Security Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Input Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:28:57 --> Language Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Language Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Config Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Loader Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:28:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:28:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:28:57 --> Session Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:28:57 --> Session routines successfully run
DEBUG - 2015-10-09 12:28:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Email Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Controller Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:28:57 --> Model Class Initialized
DEBUG - 2015-10-09 12:28:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:28:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:28:57 --> Final output sent to browser
DEBUG - 2015-10-09 12:28:57 --> Total execution time: 0.1659
DEBUG - 2015-10-09 12:28:58 --> Config Class Initialized
DEBUG - 2015-10-09 12:28:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:28:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:28:58 --> URI Class Initialized
DEBUG - 2015-10-09 12:28:58 --> Router Class Initialized
ERROR - 2015-10-09 12:28:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:29:14 --> Config Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:29:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:29:14 --> URI Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Router Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Output Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Security Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Input Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:29:14 --> Language Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Language Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Config Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Loader Class Initialized
DEBUG - 2015-10-09 12:29:14 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:29:14 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:29:14 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:29:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:29:14 --> Session Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:29:15 --> Session routines successfully run
DEBUG - 2015-10-09 12:29:15 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Email Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Controller Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:29:15 --> Model Class Initialized
DEBUG - 2015-10-09 12:29:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:29:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:29:15 --> Final output sent to browser
DEBUG - 2015-10-09 12:29:15 --> Total execution time: 0.1426
DEBUG - 2015-10-09 12:29:16 --> Config Class Initialized
DEBUG - 2015-10-09 12:29:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:29:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:29:16 --> URI Class Initialized
DEBUG - 2015-10-09 12:29:16 --> Router Class Initialized
ERROR - 2015-10-09 12:29:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:37:31 --> Config Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:37:31 --> URI Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Router Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Output Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Security Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Input Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:37:31 --> Language Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Language Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Config Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Loader Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:37:31 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:37:31 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:37:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:37:31 --> Session Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:37:31 --> Session routines successfully run
DEBUG - 2015-10-09 12:37:31 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Email Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Controller Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:37:31 --> Model Class Initialized
DEBUG - 2015-10-09 12:37:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:37:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:37:31 --> Final output sent to browser
DEBUG - 2015-10-09 12:37:31 --> Total execution time: 0.1428
DEBUG - 2015-10-09 12:37:32 --> Config Class Initialized
DEBUG - 2015-10-09 12:37:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:37:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:37:32 --> URI Class Initialized
DEBUG - 2015-10-09 12:37:32 --> Router Class Initialized
ERROR - 2015-10-09 12:37:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:38:50 --> Config Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:38:50 --> URI Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Router Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Output Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Security Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Input Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:38:50 --> Language Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Language Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Config Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Loader Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:38:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:38:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:38:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:38:50 --> Session Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:38:50 --> Session routines successfully run
DEBUG - 2015-10-09 12:38:50 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Email Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Controller Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:38:50 --> Model Class Initialized
DEBUG - 2015-10-09 12:38:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:38:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:38:50 --> Final output sent to browser
DEBUG - 2015-10-09 12:38:50 --> Total execution time: 0.1435
DEBUG - 2015-10-09 12:38:51 --> Config Class Initialized
DEBUG - 2015-10-09 12:38:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:38:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:38:51 --> URI Class Initialized
DEBUG - 2015-10-09 12:38:51 --> Router Class Initialized
ERROR - 2015-10-09 12:38:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:39:19 --> Config Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:39:19 --> URI Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Router Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Output Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Security Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Input Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:39:19 --> Language Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Language Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Config Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Loader Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:39:19 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:39:19 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:39:19 --> Session Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:39:19 --> Session routines successfully run
DEBUG - 2015-10-09 12:39:19 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Email Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Controller Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:39:19 --> Model Class Initialized
DEBUG - 2015-10-09 12:39:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:39:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:39:19 --> Final output sent to browser
DEBUG - 2015-10-09 12:39:19 --> Total execution time: 0.1596
DEBUG - 2015-10-09 12:39:20 --> Config Class Initialized
DEBUG - 2015-10-09 12:39:20 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:39:20 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:39:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:39:20 --> URI Class Initialized
DEBUG - 2015-10-09 12:39:20 --> Router Class Initialized
ERROR - 2015-10-09 12:39:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 12:40:01 --> Config Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:40:01 --> URI Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Router Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Output Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Security Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Input Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:40:01 --> Language Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Language Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Config Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Loader Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:40:01 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:40:01 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:40:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:40:01 --> Session Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:40:01 --> Session routines successfully run
DEBUG - 2015-10-09 12:40:01 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Email Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Controller Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:40:01 --> Model Class Initialized
DEBUG - 2015-10-09 12:40:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:45:42 --> Config Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:45:42 --> URI Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Router Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Output Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Security Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Input Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:45:42 --> Language Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Language Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Config Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Loader Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:45:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:45:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:45:42 --> Session Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:45:42 --> Session routines successfully run
DEBUG - 2015-10-09 12:45:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Email Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Controller Class Initialized
DEBUG - 2015-10-09 12:45:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:45:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:45:42 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Config Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:46:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:46:09 --> URI Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Router Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Output Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Security Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Input Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:46:09 --> Language Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Language Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Config Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Loader Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:46:09 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:46:09 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:46:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:46:09 --> Session Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:46:09 --> Session routines successfully run
DEBUG - 2015-10-09 12:46:09 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Email Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Controller Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:46:09 --> Model Class Initialized
DEBUG - 2015-10-09 12:46:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 12:46:09 --> Severity: Notice  --> Undefined variable: loans_plan_id C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 35
DEBUG - 2015-10-09 12:46:09 --> Final output sent to browser
DEBUG - 2015-10-09 12:46:09 --> Total execution time: 0.1281
DEBUG - 2015-10-09 12:47:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:47:49 --> URI Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Router Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Output Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Security Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Input Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:47:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Loader Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:47:49 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:47:49 --> Session Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:47:49 --> Session routines successfully run
DEBUG - 2015-10-09 12:47:49 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Email Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Controller Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 12:47:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:47:49 --> URI Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Router Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Output Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Security Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Input Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 12:47:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Language Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Config Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Loader Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: url_helper
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: form_helper
DEBUG - 2015-10-09 12:47:49 --> Database Driver Class Initialized
ERROR - 2015-10-09 12:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 12:47:49 --> Session Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Helper loaded: string_helper
DEBUG - 2015-10-09 12:47:49 --> Session routines successfully run
DEBUG - 2015-10-09 12:47:49 --> Form Validation Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Pagination Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Encrypt Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Email Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Controller Class Initialized
DEBUG - 2015-10-09 12:47:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 12:47:49 --> Model Class Initialized
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 12:47:49 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 12:47:49 --> Final output sent to browser
DEBUG - 2015-10-09 12:47:49 --> Total execution time: 0.1365
DEBUG - 2015-10-09 12:47:51 --> Config Class Initialized
DEBUG - 2015-10-09 12:47:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 12:47:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 12:47:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 12:47:51 --> URI Class Initialized
DEBUG - 2015-10-09 12:47:51 --> Router Class Initialized
ERROR - 2015-10-09 12:47:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:34:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:34:32 --> URI Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Router Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Output Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Security Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Input Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:34:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Loader Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:34:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:34:32 --> Session Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:34:32 --> Session routines successfully run
DEBUG - 2015-10-09 13:34:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Email Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Controller Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 13:34:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:34:32 --> URI Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Router Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Output Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Security Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Input Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:34:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Loader Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:34:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:34:32 --> Session Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:34:32 --> Session routines successfully run
DEBUG - 2015-10-09 13:34:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Email Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Controller Class Initialized
DEBUG - 2015-10-09 13:34:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:34:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:34:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:34:32 --> Final output sent to browser
DEBUG - 2015-10-09 13:34:32 --> Total execution time: 0.1272
DEBUG - 2015-10-09 13:36:39 --> Config Class Initialized
DEBUG - 2015-10-09 13:36:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:36:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:36:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:36:39 --> URI Class Initialized
DEBUG - 2015-10-09 13:36:39 --> Router Class Initialized
ERROR - 2015-10-09 13:36:39 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:38:07 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:07 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Router Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Output Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Security Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Input Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:38:07 --> Language Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Language Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Loader Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:38:07 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:38:07 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:38:07 --> Session Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:38:07 --> Session routines successfully run
DEBUG - 2015-10-09 13:38:07 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Email Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Controller Class Initialized
DEBUG - 2015-10-09 13:38:07 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:38:07 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:38:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:38:07 --> Final output sent to browser
DEBUG - 2015-10-09 13:38:07 --> Total execution time: 0.1394
DEBUG - 2015-10-09 13:38:08 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:08 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:08 --> Router Class Initialized
ERROR - 2015-10-09 13:38:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:38:41 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:41 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Router Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Output Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Security Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Input Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:38:41 --> Language Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Language Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Loader Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:38:41 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:38:41 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:38:41 --> Session Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:38:41 --> Session routines successfully run
DEBUG - 2015-10-09 13:38:41 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Email Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Controller Class Initialized
DEBUG - 2015-10-09 13:38:41 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 13:38:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:38:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:38:42 --> Model Class Initialized
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:38:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:38:42 --> Final output sent to browser
DEBUG - 2015-10-09 13:38:42 --> Total execution time: 0.3239
DEBUG - 2015-10-09 13:38:43 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:43 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:43 --> Router Class Initialized
ERROR - 2015-10-09 13:38:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:38:45 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:45 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:45 --> Router Class Initialized
ERROR - 2015-10-09 13:38:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:38:48 --> Config Class Initialized
DEBUG - 2015-10-09 13:38:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:38:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:38:48 --> URI Class Initialized
DEBUG - 2015-10-09 13:38:48 --> Router Class Initialized
ERROR - 2015-10-09 13:38:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:39:54 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:39:54 --> URI Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Router Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Output Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Security Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Input Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:39:54 --> Language Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Language Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Loader Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:39:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:39:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:39:54 --> Session Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:39:54 --> Session routines successfully run
DEBUG - 2015-10-09 13:39:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Email Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Controller Class Initialized
DEBUG - 2015-10-09 13:39:54 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:39:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:39:54 --> Final output sent to browser
DEBUG - 2015-10-09 13:39:54 --> Total execution time: 0.1301
DEBUG - 2015-10-09 13:39:55 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:39:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:39:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:39:55 --> URI Class Initialized
DEBUG - 2015-10-09 13:39:55 --> Router Class Initialized
ERROR - 2015-10-09 13:39:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:39:57 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:39:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:39:57 --> URI Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Router Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Output Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Security Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Input Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:39:57 --> Language Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Language Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Loader Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:39:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:39:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:39:57 --> Session Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:39:57 --> Session routines successfully run
DEBUG - 2015-10-09 13:39:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Email Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Controller Class Initialized
DEBUG - 2015-10-09 13:39:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:39:57 --> Model Class Initialized
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:39:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:39:57 --> Final output sent to browser
DEBUG - 2015-10-09 13:39:57 --> Total execution time: 0.1349
DEBUG - 2015-10-09 13:39:58 --> Config Class Initialized
DEBUG - 2015-10-09 13:39:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:39:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:39:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:39:58 --> URI Class Initialized
DEBUG - 2015-10-09 13:39:58 --> Router Class Initialized
ERROR - 2015-10-09 13:39:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:49:16 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:49:16 --> URI Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Router Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Output Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Security Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Input Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:49:16 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Loader Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:49:16 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:49:16 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:49:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:49:16 --> Session Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:49:16 --> Session routines successfully run
DEBUG - 2015-10-09 13:49:16 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Email Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Controller Class Initialized
DEBUG - 2015-10-09 13:49:16 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:49:16 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:49:32 --> URI Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Router Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Output Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Security Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Input Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:49:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Loader Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:49:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:49:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:49:32 --> Session Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:49:32 --> Session routines successfully run
DEBUG - 2015-10-09 13:49:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Email Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Controller Class Initialized
DEBUG - 2015-10-09 13:49:32 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:32 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:49:32 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:49:41 --> URI Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Router Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Output Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Security Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Input Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:49:41 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Language Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Loader Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:49:41 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:49:41 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:49:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:49:41 --> Session Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:49:41 --> Session routines successfully run
DEBUG - 2015-10-09 13:49:41 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Email Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Controller Class Initialized
DEBUG - 2015-10-09 13:49:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:49:41 --> Model Class Initialized
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:49:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:49:41 --> Final output sent to browser
DEBUG - 2015-10-09 13:49:41 --> Total execution time: 0.2728
DEBUG - 2015-10-09 13:49:42 --> Config Class Initialized
DEBUG - 2015-10-09 13:49:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:49:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:49:42 --> URI Class Initialized
DEBUG - 2015-10-09 13:49:42 --> Router Class Initialized
ERROR - 2015-10-09 13:49:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:50:36 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:50:36 --> URI Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Router Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Output Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Security Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Input Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:50:36 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Loader Class Initialized
DEBUG - 2015-10-09 13:50:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:50:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:50:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:50:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:50:37 --> Session Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:50:37 --> Session routines successfully run
DEBUG - 2015-10-09 13:50:37 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Email Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Controller Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 13:50:37 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:50:37 --> URI Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Router Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Output Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Security Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Input Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:50:37 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Loader Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:50:37 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:50:37 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:50:37 --> Session Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:50:37 --> Session routines successfully run
DEBUG - 2015-10-09 13:50:37 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Email Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Controller Class Initialized
DEBUG - 2015-10-09 13:50:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:50:37 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:50:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:50:37 --> Final output sent to browser
DEBUG - 2015-10-09 13:50:37 --> Total execution time: 0.1249
DEBUG - 2015-10-09 13:50:38 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:50:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:50:38 --> URI Class Initialized
DEBUG - 2015-10-09 13:50:38 --> Router Class Initialized
ERROR - 2015-10-09 13:50:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:50:43 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:50:43 --> URI Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Router Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Output Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Security Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Input Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:50:43 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Language Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Loader Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:50:43 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:50:43 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:50:43 --> Session Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:50:43 --> Session routines successfully run
DEBUG - 2015-10-09 13:50:43 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Email Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Controller Class Initialized
DEBUG - 2015-10-09 13:50:43 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:50:43 --> Model Class Initialized
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:50:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:50:43 --> Final output sent to browser
DEBUG - 2015-10-09 13:50:43 --> Total execution time: 0.1501
DEBUG - 2015-10-09 13:50:44 --> Config Class Initialized
DEBUG - 2015-10-09 13:50:44 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:50:44 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:50:44 --> URI Class Initialized
DEBUG - 2015-10-09 13:50:44 --> Router Class Initialized
ERROR - 2015-10-09 13:50:44 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:51:38 --> Config Class Initialized
DEBUG - 2015-10-09 13:51:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:51:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:51:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:51:38 --> URI Class Initialized
DEBUG - 2015-10-09 13:51:38 --> Router Class Initialized
ERROR - 2015-10-09 13:51:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:52:03 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:52:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:52:03 --> URI Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Router Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Output Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Security Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Input Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:52:04 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Loader Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:52:04 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:52:04 --> Session Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:52:04 --> Session routines successfully run
DEBUG - 2015-10-09 13:52:04 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Email Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Controller Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 13:52:04 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:52:04 --> URI Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Router Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Output Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Security Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Input Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:52:04 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Loader Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:52:04 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:52:04 --> Session Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:52:04 --> Session routines successfully run
DEBUG - 2015-10-09 13:52:04 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Email Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Controller Class Initialized
DEBUG - 2015-10-09 13:52:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:52:04 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:52:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:52:04 --> Final output sent to browser
DEBUG - 2015-10-09 13:52:04 --> Total execution time: 0.1227
DEBUG - 2015-10-09 13:52:05 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:52:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:52:05 --> URI Class Initialized
DEBUG - 2015-10-09 13:52:05 --> Router Class Initialized
ERROR - 2015-10-09 13:52:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 13:52:53 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:52:53 --> URI Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Router Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Output Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Security Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Input Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 13:52:53 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Language Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Loader Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Helper loaded: url_helper
DEBUG - 2015-10-09 13:52:53 --> Helper loaded: form_helper
DEBUG - 2015-10-09 13:52:53 --> Database Driver Class Initialized
ERROR - 2015-10-09 13:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 13:52:53 --> Session Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Helper loaded: string_helper
DEBUG - 2015-10-09 13:52:53 --> Session routines successfully run
DEBUG - 2015-10-09 13:52:53 --> Form Validation Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Pagination Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Encrypt Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Email Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Controller Class Initialized
DEBUG - 2015-10-09 13:52:53 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 13:52:53 --> Model Class Initialized
DEBUG - 2015-10-09 13:52:54 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 13:52:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 13:52:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 13:52:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 13:52:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 13:52:54 --> Final output sent to browser
DEBUG - 2015-10-09 13:52:54 --> Total execution time: 0.1308
DEBUG - 2015-10-09 13:52:55 --> Config Class Initialized
DEBUG - 2015-10-09 13:52:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 13:52:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 13:52:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 13:52:55 --> URI Class Initialized
DEBUG - 2015-10-09 13:52:55 --> Router Class Initialized
ERROR - 2015-10-09 13:52:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:57:27 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:27 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Output Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Security Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Input Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:57:27 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Loader Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:57:27 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:57:27 --> Session Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:57:27 --> A session cookie was not found.
DEBUG - 2015-10-09 15:57:27 --> Session routines successfully run
DEBUG - 2015-10-09 15:57:27 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Email Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Controller Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:27 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Output Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Security Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Input Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:57:27 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Loader Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:57:27 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:57:27 --> Session Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:57:27 --> Session routines successfully run
DEBUG - 2015-10-09 15:57:27 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Email Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Controller Class Initialized
DEBUG - 2015-10-09 15:57:27 --> Auth MX_Controller Initialized
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:57:27 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:57:27 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2015-10-09 15:57:27 --> Final output sent to browser
DEBUG - 2015-10-09 15:57:27 --> Total execution time: 0.0884
DEBUG - 2015-10-09 15:57:28 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:28 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:28 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:28 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:28 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Router Class Initialized
ERROR - 2015-10-09 15:57:28 --> 404 Page Not Found --> 
ERROR - 2015-10-09 15:57:28 --> 404 Page Not Found --> 
ERROR - 2015-10-09 15:57:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:57:28 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:28 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Router Class Initialized
ERROR - 2015-10-09 15:57:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:57:28 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:28 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:28 --> Router Class Initialized
ERROR - 2015-10-09 15:57:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:57:32 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:32 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Output Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Security Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Input Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:57:32 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Loader Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:57:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:57:32 --> Session Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:57:32 --> Session routines successfully run
DEBUG - 2015-10-09 15:57:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Email Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Controller Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Auth MX_Controller Initialized
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 15:57:32 --> XSS Filtering completed
DEBUG - 2015-10-09 15:57:32 --> Unable to find validation rule: exists
DEBUG - 2015-10-09 15:57:32 --> XSS Filtering completed
DEBUG - 2015-10-09 15:57:32 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:32 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Output Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Security Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Input Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:57:32 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Loader Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:57:32 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:57:32 --> Session Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:57:32 --> Session routines successfully run
DEBUG - 2015-10-09 15:57:32 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Email Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Controller Class Initialized
DEBUG - 2015-10-09 15:57:32 --> Admin MX_Controller Initialized
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 15:57:32 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:57:32 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:57:32 --> Final output sent to browser
DEBUG - 2015-10-09 15:57:32 --> Total execution time: 0.1257
DEBUG - 2015-10-09 15:57:33 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:33 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:33 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:33 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:33 --> Router Class Initialized
ERROR - 2015-10-09 15:57:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:57:37 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:37 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Router Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Output Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Security Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Input Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:57:37 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Language Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Loader Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:57:37 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:57:37 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:57:37 --> Session Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:57:37 --> Session routines successfully run
DEBUG - 2015-10-09 15:57:37 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Email Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Controller Class Initialized
DEBUG - 2015-10-09 15:57:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:57:37 --> Model Class Initialized
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:57:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:57:37 --> Final output sent to browser
DEBUG - 2015-10-09 15:57:37 --> Total execution time: 0.1368
DEBUG - 2015-10-09 15:57:38 --> Config Class Initialized
DEBUG - 2015-10-09 15:57:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:57:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:57:38 --> URI Class Initialized
DEBUG - 2015-10-09 15:57:38 --> Router Class Initialized
ERROR - 2015-10-09 15:57:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:58:26 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:26 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Router Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Output Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Security Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Input Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:58:26 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Loader Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:58:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:58:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:58:26 --> Session Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:58:26 --> Session routines successfully run
DEBUG - 2015-10-09 15:58:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Email Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Controller Class Initialized
DEBUG - 2015-10-09 15:58:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:58:26 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:58:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:58:26 --> Final output sent to browser
DEBUG - 2015-10-09 15:58:26 --> Total execution time: 0.1338
DEBUG - 2015-10-09 15:58:27 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:27 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:27 --> Router Class Initialized
ERROR - 2015-10-09 15:58:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:58:45 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:45 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Router Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Output Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Security Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Input Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:58:45 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Loader Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:58:45 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:58:45 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:58:45 --> Session Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:58:45 --> Session routines successfully run
DEBUG - 2015-10-09 15:58:45 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Email Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Controller Class Initialized
DEBUG - 2015-10-09 15:58:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:58:45 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:58:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:58:45 --> Final output sent to browser
DEBUG - 2015-10-09 15:58:45 --> Total execution time: 0.1787
DEBUG - 2015-10-09 15:58:46 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:46 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:46 --> Router Class Initialized
ERROR - 2015-10-09 15:58:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:58:55 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:56 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Router Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Output Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Security Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Input Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:58:56 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Language Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Loader Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:58:56 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:58:56 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:58:56 --> Session Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:58:56 --> Session routines successfully run
DEBUG - 2015-10-09 15:58:56 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Email Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Controller Class Initialized
DEBUG - 2015-10-09 15:58:56 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:58:56 --> Model Class Initialized
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:58:56 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:58:56 --> Final output sent to browser
DEBUG - 2015-10-09 15:58:56 --> Total execution time: 0.1452
DEBUG - 2015-10-09 15:58:57 --> Config Class Initialized
DEBUG - 2015-10-09 15:58:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:58:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:58:57 --> URI Class Initialized
DEBUG - 2015-10-09 15:58:57 --> Router Class Initialized
ERROR - 2015-10-09 15:58:57 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 15:59:12 --> Config Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:59:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:59:12 --> URI Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Router Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Output Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Security Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Input Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 15:59:12 --> Language Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Language Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Config Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Loader Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Helper loaded: url_helper
DEBUG - 2015-10-09 15:59:12 --> Helper loaded: form_helper
DEBUG - 2015-10-09 15:59:12 --> Database Driver Class Initialized
ERROR - 2015-10-09 15:59:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 15:59:12 --> Session Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Helper loaded: string_helper
DEBUG - 2015-10-09 15:59:12 --> Session routines successfully run
DEBUG - 2015-10-09 15:59:12 --> Form Validation Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Pagination Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Encrypt Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Email Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Controller Class Initialized
DEBUG - 2015-10-09 15:59:12 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 15:59:12 --> Model Class Initialized
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 15:59:12 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 15:59:12 --> Final output sent to browser
DEBUG - 2015-10-09 15:59:12 --> Total execution time: 0.1354
DEBUG - 2015-10-09 15:59:13 --> Config Class Initialized
DEBUG - 2015-10-09 15:59:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 15:59:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 15:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 15:59:13 --> URI Class Initialized
DEBUG - 2015-10-09 15:59:14 --> Router Class Initialized
ERROR - 2015-10-09 15:59:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:00:22 --> Config Class Initialized
DEBUG - 2015-10-09 16:00:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:00:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:00:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:00:22 --> URI Class Initialized
DEBUG - 2015-10-09 16:00:22 --> Router Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Output Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Security Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Input Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:00:23 --> Language Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Language Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Config Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Loader Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:00:23 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:00:23 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:00:23 --> Session Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:00:23 --> Session routines successfully run
DEBUG - 2015-10-09 16:00:23 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Email Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Controller Class Initialized
DEBUG - 2015-10-09 16:00:23 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:00:23 --> Model Class Initialized
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:00:23 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:00:23 --> Final output sent to browser
DEBUG - 2015-10-09 16:00:23 --> Total execution time: 0.1460
DEBUG - 2015-10-09 16:00:24 --> Config Class Initialized
DEBUG - 2015-10-09 16:00:24 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:00:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:00:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:00:24 --> URI Class Initialized
DEBUG - 2015-10-09 16:00:24 --> Router Class Initialized
ERROR - 2015-10-09 16:00:24 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:01:13 --> Config Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:01:13 --> URI Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Router Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Output Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Security Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Input Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:01:13 --> Language Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Language Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Config Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Loader Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:01:13 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:01:13 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:01:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:01:13 --> Session Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:01:13 --> Session routines successfully run
DEBUG - 2015-10-09 16:01:13 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Email Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Controller Class Initialized
DEBUG - 2015-10-09 16:01:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:01:13 --> Model Class Initialized
ERROR - 2015-10-09 16:01:13 --> Severity: Notice  --> Undefined property: stdClass::$individual_id C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_group_payments.php 56
ERROR - 2015-10-09 16:01:13 --> Severity: Notice  --> Undefined property: stdClass::$individual_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_group_payments.php 57
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:01:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:01:13 --> Final output sent to browser
DEBUG - 2015-10-09 16:01:13 --> Total execution time: 0.1429
DEBUG - 2015-10-09 16:01:14 --> Config Class Initialized
DEBUG - 2015-10-09 16:01:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:01:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:01:14 --> URI Class Initialized
DEBUG - 2015-10-09 16:01:14 --> Router Class Initialized
ERROR - 2015-10-09 16:01:14 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:02:03 --> Config Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:02:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:02:03 --> URI Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Router Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Output Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Security Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Input Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:02:03 --> Language Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Language Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Config Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Loader Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:02:03 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:02:03 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:02:03 --> Session Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:02:03 --> Session routines successfully run
DEBUG - 2015-10-09 16:02:03 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Email Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Controller Class Initialized
DEBUG - 2015-10-09 16:02:03 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:02:03 --> Model Class Initialized
ERROR - 2015-10-09 16:02:03 --> Severity: Notice  --> Undefined property: stdClass::$individual_id C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_group_payments.php 56
ERROR - 2015-10-09 16:02:03 --> Severity: Notice  --> Undefined property: stdClass::$individual_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\all_group_payments.php 57
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:02:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:02:03 --> Final output sent to browser
DEBUG - 2015-10-09 16:02:03 --> Total execution time: 0.1566
DEBUG - 2015-10-09 16:02:04 --> Config Class Initialized
DEBUG - 2015-10-09 16:02:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:02:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:02:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:02:04 --> URI Class Initialized
DEBUG - 2015-10-09 16:02:04 --> Router Class Initialized
ERROR - 2015-10-09 16:02:04 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:04:48 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:04:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:04:48 --> URI Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Router Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Output Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Security Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Input Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:04:48 --> Language Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Language Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Loader Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:04:48 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:04:48 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:04:48 --> Session Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:04:48 --> Session routines successfully run
DEBUG - 2015-10-09 16:04:48 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Email Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Controller Class Initialized
DEBUG - 2015-10-09 16:04:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:04:48 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:04:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:04:48 --> Final output sent to browser
DEBUG - 2015-10-09 16:04:48 --> Total execution time: 0.1629
DEBUG - 2015-10-09 16:04:49 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:04:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:04:49 --> URI Class Initialized
DEBUG - 2015-10-09 16:04:49 --> Router Class Initialized
ERROR - 2015-10-09 16:04:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:04:57 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:04:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:04:57 --> URI Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Router Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Output Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Security Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Input Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:04:57 --> Language Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Language Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Loader Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:04:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:04:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:04:57 --> Session Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:04:57 --> Session routines successfully run
DEBUG - 2015-10-09 16:04:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Email Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Controller Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:04:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:04:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:04:57 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:04:57 --> Final output sent to browser
DEBUG - 2015-10-09 16:04:57 --> Total execution time: 0.1474
DEBUG - 2015-10-09 16:04:58 --> Config Class Initialized
DEBUG - 2015-10-09 16:04:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:04:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:04:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:04:58 --> URI Class Initialized
DEBUG - 2015-10-09 16:04:58 --> Router Class Initialized
ERROR - 2015-10-09 16:04:58 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:05:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:05 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:05 --> Router Class Initialized
ERROR - 2015-10-09 16:05:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:05:18 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:18 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Router Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Output Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Security Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Input Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:05:18 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:18 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Loader Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:05:19 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:05:19 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:05:19 --> Session Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:05:19 --> Session routines successfully run
DEBUG - 2015-10-09 16:05:19 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Email Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Controller Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:05:19 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:05:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:05:19 --> Final output sent to browser
DEBUG - 2015-10-09 16:05:19 --> Total execution time: 0.1511
DEBUG - 2015-10-09 16:05:19 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:19 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:19 --> Router Class Initialized
ERROR - 2015-10-09 16:05:20 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:05:21 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:21 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Router Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Output Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Security Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Input Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:05:21 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Loader Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:05:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:05:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:05:21 --> Session Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:05:21 --> Session routines successfully run
DEBUG - 2015-10-09 16:05:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Email Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Controller Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:05:21 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:05:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:05:21 --> Final output sent to browser
DEBUG - 2015-10-09 16:05:21 --> Total execution time: 0.1456
DEBUG - 2015-10-09 16:05:22 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:22 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:22 --> Router Class Initialized
ERROR - 2015-10-09 16:05:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:05:37 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:37 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:37 --> Router Class Initialized
ERROR - 2015-10-09 16:05:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:05:59 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:05:59 --> URI Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Router Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Output Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Security Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Input Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:05:59 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Language Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Config Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Loader Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:05:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:05:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:05:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:05:59 --> Session Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:05:59 --> Session routines successfully run
DEBUG - 2015-10-09 16:05:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Email Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Controller Class Initialized
DEBUG - 2015-10-09 16:05:59 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:05:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:05:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:05:59 --> Final output sent to browser
DEBUG - 2015-10-09 16:05:59 --> Total execution time: 0.1836
DEBUG - 2015-10-09 16:06:01 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:06:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:06:01 --> URI Class Initialized
DEBUG - 2015-10-09 16:06:01 --> Router Class Initialized
ERROR - 2015-10-09 16:06:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:06:04 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:06:04 --> URI Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Router Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Output Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Security Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Input Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:06:04 --> Language Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Language Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Loader Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:06:04 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:06:04 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:06:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:06:04 --> Session Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:06:04 --> Session routines successfully run
DEBUG - 2015-10-09 16:06:04 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Email Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Controller Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:06:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:06:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:06:04 --> Final output sent to browser
DEBUG - 2015-10-09 16:06:04 --> Total execution time: 0.1410
DEBUG - 2015-10-09 16:06:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:06:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:06:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:06:05 --> URI Class Initialized
DEBUG - 2015-10-09 16:06:05 --> Router Class Initialized
ERROR - 2015-10-09 16:06:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:06:07 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:06:07 --> URI Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Router Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Output Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Security Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Input Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:06:07 --> Language Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Language Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Loader Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:06:07 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:06:07 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:06:07 --> Session Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:06:07 --> Session routines successfully run
DEBUG - 2015-10-09 16:06:07 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Email Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Controller Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:06:07 --> Model Class Initialized
DEBUG - 2015-10-09 16:06:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:06:07 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:06:07 --> Final output sent to browser
DEBUG - 2015-10-09 16:06:07 --> Total execution time: 0.1502
DEBUG - 2015-10-09 16:06:08 --> Config Class Initialized
DEBUG - 2015-10-09 16:06:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:06:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:06:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:06:08 --> URI Class Initialized
DEBUG - 2015-10-09 16:06:08 --> Router Class Initialized
ERROR - 2015-10-09 16:06:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:09:51 --> Config Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:09:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:09:51 --> URI Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Router Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Output Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Security Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Input Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:09:51 --> Language Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Language Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Config Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Loader Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:09:51 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:09:51 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:09:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:09:51 --> Session Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:09:51 --> Session routines successfully run
DEBUG - 2015-10-09 16:09:51 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Email Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Controller Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:09:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:09:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:09:51 --> Final output sent to browser
DEBUG - 2015-10-09 16:09:51 --> Total execution time: 0.1279
DEBUG - 2015-10-09 16:11:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:11:50 --> URI Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Router Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Output Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Security Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Input Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:11:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Loader Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:11:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:11:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:11:50 --> Session Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:11:50 --> Session routines successfully run
DEBUG - 2015-10-09 16:11:50 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Email Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Controller Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:11:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:11:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:11:50 --> URI Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Router Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Output Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Security Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Input Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:11:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Loader Class Initialized
DEBUG - 2015-10-09 16:11:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:11:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:11:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:11:51 --> Session Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:11:51 --> Session routines successfully run
DEBUG - 2015-10-09 16:11:51 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Email Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Controller Class Initialized
DEBUG - 2015-10-09 16:11:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:11:51 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:11:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:11:51 --> Final output sent to browser
DEBUG - 2015-10-09 16:11:51 --> Total execution time: 0.1311
DEBUG - 2015-10-09 16:11:52 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:52 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:11:52 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:11:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:11:52 --> URI Class Initialized
DEBUG - 2015-10-09 16:11:52 --> Router Class Initialized
ERROR - 2015-10-09 16:11:52 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:11:58 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:58 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:11:58 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:11:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:11:58 --> URI Class Initialized
DEBUG - 2015-10-09 16:11:58 --> Router Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Output Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Security Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Input Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:11:59 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Language Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Config Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Loader Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:11:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:11:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:11:59 --> Session Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:11:59 --> Session routines successfully run
DEBUG - 2015-10-09 16:11:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Email Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Controller Class Initialized
DEBUG - 2015-10-09 16:11:59 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:11:59 --> Model Class Initialized
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:11:59 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:11:59 --> Final output sent to browser
DEBUG - 2015-10-09 16:11:59 --> Total execution time: 0.1438
DEBUG - 2015-10-09 16:12:00 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:00 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:00 --> Router Class Initialized
ERROR - 2015-10-09 16:12:00 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:12:02 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:02 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:02 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:02 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:02 --> Router Class Initialized
ERROR - 2015-10-09 16:12:02 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:12:03 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:03 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:03 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:03 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:03 --> Router Class Initialized
ERROR - 2015-10-09 16:12:03 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:12:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:05 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Router Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Output Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Security Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Input Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:12:05 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Loader Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:12:05 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:12:05 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:12:05 --> Session Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:12:05 --> Session routines successfully run
DEBUG - 2015-10-09 16:12:05 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Email Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Controller Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:12:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:12:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:12:05 --> Final output sent to browser
DEBUG - 2015-10-09 16:12:05 --> Total execution time: 0.1423
DEBUG - 2015-10-09 16:12:06 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:06 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:06 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:06 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:06 --> Router Class Initialized
ERROR - 2015-10-09 16:12:06 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:12:40 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:40 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Router Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Output Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Security Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Input Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:12:40 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Loader Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:12:40 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:12:40 --> Session Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:12:40 --> Session routines successfully run
DEBUG - 2015-10-09 16:12:40 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Email Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Controller Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:12:40 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:40 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Router Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Output Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Security Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Input Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:12:40 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Loader Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:12:40 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:12:40 --> Session Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:12:40 --> Session routines successfully run
DEBUG - 2015-10-09 16:12:40 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Email Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Controller Class Initialized
DEBUG - 2015-10-09 16:12:40 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:12:40 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:12:40 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:12:40 --> Final output sent to browser
DEBUG - 2015-10-09 16:12:40 --> Total execution time: 0.1402
DEBUG - 2015-10-09 16:12:41 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:41 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:41 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:41 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:41 --> Router Class Initialized
ERROR - 2015-10-09 16:12:41 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:12:45 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:45 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Router Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Output Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Security Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Input Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:12:45 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Language Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Loader Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:12:45 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:12:45 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:12:45 --> Session Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:12:45 --> Session routines successfully run
DEBUG - 2015-10-09 16:12:45 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Email Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Controller Class Initialized
DEBUG - 2015-10-09 16:12:45 --> Loans_plan MX_Controller Initialized
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:12:45 --> Model Class Initialized
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/microfinance/views/loans_plan/all_loans_plan.php
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:12:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:12:45 --> Final output sent to browser
DEBUG - 2015-10-09 16:12:45 --> Total execution time: 0.1826
DEBUG - 2015-10-09 16:12:46 --> Config Class Initialized
DEBUG - 2015-10-09 16:12:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:12:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:12:46 --> URI Class Initialized
DEBUG - 2015-10-09 16:12:46 --> Router Class Initialized
ERROR - 2015-10-09 16:12:46 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:13:25 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:25 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Router Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Output Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Security Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Input Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:13:25 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Loader Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:13:25 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:13:25 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:13:25 --> Session Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:13:25 --> Session routines successfully run
DEBUG - 2015-10-09 16:13:25 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Email Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Controller Class Initialized
DEBUG - 2015-10-09 16:13:25 --> Microfinance MX_Controller Initialized
DEBUG - 2015-10-09 16:13:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:13:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:13:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:13:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:13:26 --> Model Class Initialized
ERROR - 2015-10-09 16:13:26 --> 404 Page Not Found --> microfinance/group-payments
DEBUG - 2015-10-09 16:13:33 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:33 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:33 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:33 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:33 --> Router Class Initialized
ERROR - 2015-10-09 16:13:33 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:13:36 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:36 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Router Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Output Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Security Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Input Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:13:36 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Loader Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:13:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:13:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:13:36 --> Session Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:13:36 --> Session routines successfully run
DEBUG - 2015-10-09 16:13:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Email Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Controller Class Initialized
DEBUG - 2015-10-09 16:13:36 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:13:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:13:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:13:36 --> Final output sent to browser
DEBUG - 2015-10-09 16:13:36 --> Total execution time: 0.1380
DEBUG - 2015-10-09 16:13:37 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:37 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:37 --> Router Class Initialized
ERROR - 2015-10-09 16:13:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:13:42 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:42 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Router Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Output Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Security Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Input Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:13:42 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Language Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Loader Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:13:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:13:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:13:42 --> Session Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:13:42 --> Session routines successfully run
DEBUG - 2015-10-09 16:13:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Email Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Controller Class Initialized
DEBUG - 2015-10-09 16:13:42 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:13:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:13:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:13:42 --> Final output sent to browser
DEBUG - 2015-10-09 16:13:42 --> Total execution time: 0.1427
DEBUG - 2015-10-09 16:13:43 --> Config Class Initialized
DEBUG - 2015-10-09 16:13:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:13:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:13:43 --> URI Class Initialized
DEBUG - 2015-10-09 16:13:43 --> Router Class Initialized
ERROR - 2015-10-09 16:13:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:14:09 --> Config Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:14:09 --> URI Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Router Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Output Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Security Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Input Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:14:09 --> Language Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Language Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Config Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Loader Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:14:09 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:14:09 --> Session Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:14:09 --> Session routines successfully run
DEBUG - 2015-10-09 16:14:09 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Email Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Controller Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:14:09 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:14:09 --> XSS Filtering completed
DEBUG - 2015-10-09 16:14:09 --> XSS Filtering completed
DEBUG - 2015-10-09 16:14:09 --> XSS Filtering completed
DEBUG - 2015-10-09 16:14:09 --> XSS Filtering completed
DEBUG - 2015-10-09 16:14:09 --> Config Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:14:09 --> URI Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Router Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Output Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Security Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Input Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:14:09 --> Language Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Language Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Config Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Loader Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:14:09 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:14:09 --> Session Class Initialized
DEBUG - 2015-10-09 16:14:09 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:14:09 --> Session routines successfully run
DEBUG - 2015-10-09 16:14:10 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:14:10 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:14:10 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:14:10 --> Email Class Initialized
DEBUG - 2015-10-09 16:14:10 --> Controller Class Initialized
DEBUG - 2015-10-09 16:14:10 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:14:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:14:10 --> Final output sent to browser
DEBUG - 2015-10-09 16:14:10 --> Total execution time: 0.1560
DEBUG - 2015-10-09 16:14:11 --> Config Class Initialized
DEBUG - 2015-10-09 16:14:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:14:11 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:14:11 --> URI Class Initialized
DEBUG - 2015-10-09 16:14:11 --> Router Class Initialized
ERROR - 2015-10-09 16:14:11 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:19:35 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:35 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Router Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Output Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Security Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Input Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:19:35 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Loader Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:19:35 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:19:35 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:19:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:19:35 --> Session Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:19:35 --> Session routines successfully run
DEBUG - 2015-10-09 16:19:35 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Email Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Controller Class Initialized
DEBUG - 2015-10-09 16:19:35 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:19:35 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:19:35 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:19:35 --> Final output sent to browser
DEBUG - 2015-10-09 16:19:35 --> Total execution time: 0.1232
DEBUG - 2015-10-09 16:19:37 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:37 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:37 --> Router Class Initialized
ERROR - 2015-10-09 16:19:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:19:42 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:42 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Router Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Output Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Security Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Input Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:19:42 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Loader Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:19:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:19:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:19:42 --> Session Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:19:42 --> Session routines successfully run
DEBUG - 2015-10-09 16:19:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Email Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Controller Class Initialized
DEBUG - 2015-10-09 16:19:42 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:19:42 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/views/sections/edit_section.php
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:19:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:19:42 --> Final output sent to browser
DEBUG - 2015-10-09 16:19:42 --> Total execution time: 0.1647
DEBUG - 2015-10-09 16:19:43 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:43 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:43 --> Router Class Initialized
ERROR - 2015-10-09 16:19:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:19:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:50 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Router Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Output Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Security Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Input Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:19:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Loader Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:19:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:19:50 --> Session Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:19:50 --> Session routines successfully run
DEBUG - 2015-10-09 16:19:50 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Email Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Controller Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:19:50 --> XSS Filtering completed
DEBUG - 2015-10-09 16:19:50 --> XSS Filtering completed
DEBUG - 2015-10-09 16:19:50 --> XSS Filtering completed
DEBUG - 2015-10-09 16:19:50 --> XSS Filtering completed
DEBUG - 2015-10-09 16:19:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:50 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Router Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Output Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Security Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Input Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:19:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Loader Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:19:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:19:50 --> Session Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:19:50 --> Session routines successfully run
DEBUG - 2015-10-09 16:19:50 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Email Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Controller Class Initialized
DEBUG - 2015-10-09 16:19:50 --> Sections MX_Controller Initialized
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/views/sections/all_sections.php
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:19:50 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:19:50 --> Final output sent to browser
DEBUG - 2015-10-09 16:19:50 --> Total execution time: 0.1517
DEBUG - 2015-10-09 16:19:51 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:51 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:51 --> Router Class Initialized
ERROR - 2015-10-09 16:19:51 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:19:54 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:55 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Router Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Output Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Security Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Input Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:19:55 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Language Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Loader Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:19:55 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:19:55 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:19:55 --> Session Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:19:55 --> Session routines successfully run
DEBUG - 2015-10-09 16:19:55 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Email Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Controller Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:19:55 --> Model Class Initialized
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:19:55 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:19:55 --> Final output sent to browser
DEBUG - 2015-10-09 16:19:55 --> Total execution time: 0.1317
DEBUG - 2015-10-09 16:19:55 --> Config Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:19:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:19:55 --> URI Class Initialized
DEBUG - 2015-10-09 16:19:55 --> Router Class Initialized
ERROR - 2015-10-09 16:19:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:21:31 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:21:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:21:31 --> URI Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Router Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Output Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Security Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Input Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:21:31 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Loader Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:21:31 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:21:31 --> Session Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:21:31 --> Session routines successfully run
DEBUG - 2015-10-09 16:21:31 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Email Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Controller Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 16:21:31 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:21:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:21:31 --> URI Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Router Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Output Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Security Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Input Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:21:31 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Loader Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:21:31 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:21:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:21:31 --> Session Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:21:31 --> Session routines successfully run
DEBUG - 2015-10-09 16:21:31 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Email Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Controller Class Initialized
DEBUG - 2015-10-09 16:21:31 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:21:31 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:21:31 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:21:31 --> Final output sent to browser
DEBUG - 2015-10-09 16:21:31 --> Total execution time: 0.1600
DEBUG - 2015-10-09 16:21:32 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:21:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:21:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:21:32 --> URI Class Initialized
DEBUG - 2015-10-09 16:21:32 --> Router Class Initialized
ERROR - 2015-10-09 16:21:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:21:49 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:21:49 --> URI Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Router Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Output Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Security Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Input Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:21:49 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Loader Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:21:49 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:21:49 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:21:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:21:49 --> Session Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:21:49 --> Session routines successfully run
DEBUG - 2015-10-09 16:21:49 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Email Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Controller Class Initialized
DEBUG - 2015-10-09 16:21:49 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:49 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:21:49 --> Model Class Initialized
ERROR - 2015-10-09 16:21:49 --> 404 Page Not Found --> payments/edit-group
DEBUG - 2015-10-09 16:21:57 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:21:57 --> URI Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Router Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Output Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Security Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Input Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:21:57 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Language Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Config Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Loader Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:21:57 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:21:57 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:21:57 --> Session Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:21:57 --> Session routines successfully run
DEBUG - 2015-10-09 16:21:57 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Email Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Controller Class Initialized
DEBUG - 2015-10-09 16:21:57 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
DEBUG - 2015-10-09 16:21:57 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:21:57 --> Model Class Initialized
ERROR - 2015-10-09 16:21:57 --> 404 Page Not Found --> payments/edit-group-payment
DEBUG - 2015-10-09 16:22:25 --> Config Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:22:25 --> URI Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Router Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Output Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Security Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Input Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:22:25 --> Language Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Language Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Config Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Loader Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:22:25 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:22:25 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:22:25 --> Session Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:22:25 --> Session routines successfully run
DEBUG - 2015-10-09 16:22:25 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Email Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Controller Class Initialized
DEBUG - 2015-10-09 16:22:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
DEBUG - 2015-10-09 16:22:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:22:25 --> Model Class Initialized
ERROR - 2015-10-09 16:22:25 --> 404 Page Not Found --> payments/edit-group-payment
DEBUG - 2015-10-09 16:22:42 --> Config Class Initialized
DEBUG - 2015-10-09 16:22:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:22:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:22:42 --> URI Class Initialized
DEBUG - 2015-10-09 16:22:42 --> Router Class Initialized
ERROR - 2015-10-09 16:22:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:23:00 --> URI Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Router Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Output Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Security Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Input Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Language Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Config Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Loader Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:23:00 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:23:00 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:23:00 --> Session Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:23:00 --> Session routines successfully run
DEBUG - 2015-10-09 16:23:00 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Email Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Controller Class Initialized
DEBUG - 2015-10-09 16:23:00 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:23:00 --> Model Class Initialized
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:23:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:23:00 --> Final output sent to browser
DEBUG - 2015-10-09 16:23:00 --> Total execution time: 0.1344
DEBUG - 2015-10-09 16:23:01 --> Config Class Initialized
DEBUG - 2015-10-09 16:23:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:23:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:23:01 --> URI Class Initialized
DEBUG - 2015-10-09 16:23:01 --> Router Class Initialized
ERROR - 2015-10-09 16:23:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:25:15 --> Config Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:25:15 --> URI Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Router Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Output Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Security Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Input Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:25:15 --> Language Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Language Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Config Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Loader Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:25:15 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:25:15 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:25:15 --> Session Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:25:15 --> Session routines successfully run
DEBUG - 2015-10-09 16:25:15 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Email Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Controller Class Initialized
DEBUG - 2015-10-09 16:25:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:25:15 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:25:16 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:25:16 --> Model Class Initialized
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:25:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:25:16 --> Final output sent to browser
DEBUG - 2015-10-09 16:25:16 --> Total execution time: 0.1404
DEBUG - 2015-10-09 16:36:22 --> Config Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:36:22 --> URI Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Router Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Output Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Security Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Input Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:36:22 --> Language Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Language Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Config Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Loader Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:36:22 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:36:22 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:36:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:36:22 --> Session Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:36:22 --> Session routines successfully run
DEBUG - 2015-10-09 16:36:22 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Email Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Controller Class Initialized
DEBUG - 2015-10-09 16:36:22 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:36:22 --> Model Class Initialized
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:36:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:36:22 --> Final output sent to browser
DEBUG - 2015-10-09 16:36:22 --> Total execution time: 0.1763
DEBUG - 2015-10-09 16:38:49 --> Config Class Initialized
DEBUG - 2015-10-09 16:38:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:38:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:38:49 --> URI Class Initialized
DEBUG - 2015-10-09 16:38:49 --> Router Class Initialized
ERROR - 2015-10-09 16:38:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:39:43 --> Config Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:39:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:39:43 --> URI Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Router Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Output Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Security Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Input Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:39:43 --> Language Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Language Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Config Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Loader Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:39:43 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:39:43 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:39:43 --> Session Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:39:43 --> Session routines successfully run
DEBUG - 2015-10-09 16:39:43 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Email Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Controller Class Initialized
DEBUG - 2015-10-09 16:39:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:39:43 --> Model Class Initialized
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:39:43 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:39:43 --> Final output sent to browser
DEBUG - 2015-10-09 16:39:43 --> Total execution time: 0.1545
DEBUG - 2015-10-09 16:39:45 --> Config Class Initialized
DEBUG - 2015-10-09 16:39:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:39:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:39:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:39:45 --> URI Class Initialized
DEBUG - 2015-10-09 16:39:45 --> Router Class Initialized
ERROR - 2015-10-09 16:39:45 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:44:36 --> Config Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:44:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:44:36 --> URI Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Router Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Output Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Security Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Input Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:44:36 --> Language Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Language Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Config Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Loader Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:44:36 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:44:36 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:44:36 --> Session Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:44:36 --> Session routines successfully run
DEBUG - 2015-10-09 16:44:36 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Email Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Controller Class Initialized
DEBUG - 2015-10-09 16:44:36 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:44:36 --> Model Class Initialized
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:44:36 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:44:36 --> Final output sent to browser
DEBUG - 2015-10-09 16:44:36 --> Total execution time: 0.1924
DEBUG - 2015-10-09 16:44:37 --> Config Class Initialized
DEBUG - 2015-10-09 16:44:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:44:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:44:37 --> URI Class Initialized
DEBUG - 2015-10-09 16:44:37 --> Router Class Initialized
ERROR - 2015-10-09 16:44:37 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:45:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:45:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:45:05 --> URI Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Router Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Output Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Security Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Input Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:45:05 --> Language Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Language Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Loader Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:45:05 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:45:05 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:45:05 --> Session Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:45:05 --> Session routines successfully run
DEBUG - 2015-10-09 16:45:05 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Email Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Controller Class Initialized
DEBUG - 2015-10-09 16:45:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:45:05 --> Model Class Initialized
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:45:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:45:05 --> Final output sent to browser
DEBUG - 2015-10-09 16:45:05 --> Total execution time: 0.1782
DEBUG - 2015-10-09 16:45:06 --> Config Class Initialized
DEBUG - 2015-10-09 16:45:06 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:45:06 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:45:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:45:06 --> URI Class Initialized
DEBUG - 2015-10-09 16:45:06 --> Router Class Initialized
ERROR - 2015-10-09 16:45:06 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 16:46:04 --> Config Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:46:04 --> URI Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Router Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Output Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Security Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Input Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 16:46:04 --> Language Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Language Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Config Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Loader Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Helper loaded: url_helper
DEBUG - 2015-10-09 16:46:04 --> Helper loaded: form_helper
DEBUG - 2015-10-09 16:46:04 --> Database Driver Class Initialized
ERROR - 2015-10-09 16:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 16:46:04 --> Session Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Helper loaded: string_helper
DEBUG - 2015-10-09 16:46:04 --> Session routines successfully run
DEBUG - 2015-10-09 16:46:04 --> Form Validation Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Pagination Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Encrypt Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Email Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Controller Class Initialized
DEBUG - 2015-10-09 16:46:04 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 16:46:04 --> Model Class Initialized
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 16:46:04 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 16:46:04 --> Final output sent to browser
DEBUG - 2015-10-09 16:46:04 --> Total execution time: 0.1602
DEBUG - 2015-10-09 16:46:05 --> Config Class Initialized
DEBUG - 2015-10-09 16:46:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 16:46:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 16:46:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 16:46:05 --> URI Class Initialized
DEBUG - 2015-10-09 16:46:05 --> Router Class Initialized
ERROR - 2015-10-09 16:46:05 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:08:06 --> Config Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:08:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:08:06 --> URI Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Router Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Output Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Security Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Input Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:08:06 --> Language Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Language Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Config Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Loader Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:08:06 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:08:06 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:08:06 --> Session Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:08:06 --> Session routines successfully run
DEBUG - 2015-10-09 17:08:06 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Email Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Controller Class Initialized
DEBUG - 2015-10-09 17:08:06 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:08:06 --> Model Class Initialized
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:08:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:08:06 --> Final output sent to browser
DEBUG - 2015-10-09 17:08:06 --> Total execution time: 0.1467
DEBUG - 2015-10-09 17:08:08 --> Config Class Initialized
DEBUG - 2015-10-09 17:08:08 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:08:08 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:08:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:08:08 --> URI Class Initialized
DEBUG - 2015-10-09 17:08:08 --> Router Class Initialized
ERROR - 2015-10-09 17:08:08 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:12:11 --> Config Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:12:11 --> URI Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Router Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Output Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Security Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Input Class Initialized
DEBUG - 2015-10-09 17:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:12:11 --> Language Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Config Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:12:29 --> URI Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Router Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Output Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Security Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Input Class Initialized
DEBUG - 2015-10-09 17:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:12:29 --> Language Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Config Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:12:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:12:41 --> URI Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Router Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Output Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Security Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Input Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:12:41 --> Language Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Language Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Config Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Loader Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:12:41 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:12:41 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:12:41 --> Session Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:12:41 --> Session routines successfully run
DEBUG - 2015-10-09 17:12:41 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Email Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Controller Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:12:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:12:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:12:41 --> Final output sent to browser
DEBUG - 2015-10-09 17:12:41 --> Total execution time: 0.1239
DEBUG - 2015-10-09 17:13:05 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:13:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:13:05 --> URI Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Router Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Output Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Security Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Input Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:13:05 --> Language Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Language Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Loader Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:13:05 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:13:05 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:13:05 --> Session Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:13:05 --> Session routines successfully run
DEBUG - 2015-10-09 17:13:05 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Email Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Controller Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:13:05 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:13:05 --> Final output sent to browser
DEBUG - 2015-10-09 17:13:05 --> Total execution time: 0.1307
DEBUG - 2015-10-09 17:13:13 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:13:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:13:13 --> URI Class Initialized
DEBUG - 2015-10-09 17:13:13 --> Router Class Initialized
ERROR - 2015-10-09 17:13:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:13:15 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:13:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:13:15 --> URI Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Router Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Output Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Security Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Input Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:13:15 --> Language Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Language Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Loader Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:13:15 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:13:15 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:13:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:13:15 --> Session Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:13:15 --> Session routines successfully run
DEBUG - 2015-10-09 17:13:15 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Email Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Controller Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:13:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:13:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:13:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:13:15 --> Final output sent to browser
DEBUG - 2015-10-09 17:13:15 --> Total execution time: 0.1442
DEBUG - 2015-10-09 17:13:16 --> Config Class Initialized
DEBUG - 2015-10-09 17:13:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:13:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:13:16 --> URI Class Initialized
DEBUG - 2015-10-09 17:13:16 --> Router Class Initialized
ERROR - 2015-10-09 17:13:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:14:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:14:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:14:26 --> URI Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Router Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Output Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Security Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Input Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:14:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Loader Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:14:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:14:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:14:26 --> Session Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:14:26 --> Session routines successfully run
DEBUG - 2015-10-09 17:14:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Email Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Controller Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:14:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:14:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:14:26 --> Final output sent to browser
DEBUG - 2015-10-09 17:14:26 --> Total execution time: 0.1134
DEBUG - 2015-10-09 17:17:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:17:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:17:26 --> URI Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Router Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Output Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Security Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Input Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:17:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Loader Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:17:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:17:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:17:26 --> Session Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:17:26 --> Session routines successfully run
DEBUG - 2015-10-09 17:17:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Email Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Controller Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:17:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:17:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:17:26 --> Final output sent to browser
DEBUG - 2015-10-09 17:17:26 --> Total execution time: 0.1664
DEBUG - 2015-10-09 17:17:27 --> Config Class Initialized
DEBUG - 2015-10-09 17:17:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:17:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:17:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:17:27 --> URI Class Initialized
DEBUG - 2015-10-09 17:17:27 --> Router Class Initialized
ERROR - 2015-10-09 17:17:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:17:51 --> Config Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:17:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:17:51 --> URI Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Router Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Output Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Security Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Input Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:17:51 --> Language Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Language Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Config Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Loader Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:17:51 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:17:51 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:17:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:17:51 --> Session Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:17:51 --> Session routines successfully run
DEBUG - 2015-10-09 17:17:51 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Email Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Controller Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:17:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:17:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 17:17:51 --> Severity: Notice  --> Undefined variable: query C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 6
DEBUG - 2015-10-09 17:19:49 --> Config Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:19:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:19:49 --> URI Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Router Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Output Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Security Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Input Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:19:49 --> Language Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Language Class Initialized
DEBUG - 2015-10-09 17:19:49 --> Config Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Loader Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:19:50 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:19:50 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:19:50 --> Session Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:19:50 --> Session routines successfully run
DEBUG - 2015-10-09 17:19:50 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Email Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Controller Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:19:50 --> Model Class Initialized
DEBUG - 2015-10-09 17:19:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 17:19:50 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 115
ERROR - 2015-10-09 17:19:50 --> Severity: Notice  --> Undefined variable: order_method C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 115
ERROR - 2015-10-09 17:19:50 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 147
ERROR - 2015-10-09 17:19:50 --> Severity: Notice  --> Undefined variable: order_method C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 147
DEBUG - 2015-10-09 17:19:50 --> DB Transaction Failure
ERROR - 2015-10-09 17:19:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`
LIMIT 20' at line 4
DEBUG - 2015-10-09 17:19:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 17:20:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:20:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:20:46 --> URI Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Router Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Output Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Security Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Input Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:20:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Loader Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:20:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:20:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:20:46 --> Session Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:20:46 --> Session routines successfully run
DEBUG - 2015-10-09 17:20:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Email Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Controller Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:20:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:20:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 17:20:46 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 115
ERROR - 2015-10-09 17:20:46 --> Severity: Notice  --> Undefined variable: order_method C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 115
ERROR - 2015-10-09 17:20:46 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 147
ERROR - 2015-10-09 17:20:46 --> Severity: Notice  --> Undefined variable: order_method C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 147
DEBUG - 2015-10-09 17:20:46 --> DB Transaction Failure
ERROR - 2015-10-09 17:20:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`
LIMIT 20' at line 4
DEBUG - 2015-10-09 17:20:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 17:21:24 --> Config Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:21:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:21:24 --> URI Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Router Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Output Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Security Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Input Class Initialized
DEBUG - 2015-10-09 17:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:21:24 --> Language Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Language Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Config Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Loader Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:21:25 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:21:25 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:21:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:21:25 --> Session Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:21:25 --> Session routines successfully run
DEBUG - 2015-10-09 17:21:25 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Email Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Controller Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:21:25 --> Model Class Initialized
DEBUG - 2015-10-09 17:21:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:21:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:21:25 --> Final output sent to browser
DEBUG - 2015-10-09 17:21:25 --> Total execution time: 0.1780
DEBUG - 2015-10-09 17:21:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:21:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:21:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:21:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:21:26 --> URI Class Initialized
DEBUG - 2015-10-09 17:21:26 --> Router Class Initialized
ERROR - 2015-10-09 17:21:26 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:23:54 --> Config Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:23:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:23:54 --> URI Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Router Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Output Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Security Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Input Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:23:54 --> Language Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Language Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Config Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Loader Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:23:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:23:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:23:54 --> Session Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:23:54 --> Session routines successfully run
DEBUG - 2015-10-09 17:23:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Email Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Controller Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:23:54 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:23:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:23:54 --> Final output sent to browser
DEBUG - 2015-10-09 17:23:54 --> Total execution time: 0.1467
DEBUG - 2015-10-09 17:23:55 --> Config Class Initialized
DEBUG - 2015-10-09 17:23:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:23:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:23:55 --> URI Class Initialized
DEBUG - 2015-10-09 17:23:55 --> Router Class Initialized
ERROR - 2015-10-09 17:23:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:23:59 --> Config Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:23:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:23:59 --> URI Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Router Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Output Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Security Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Input Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:23:59 --> Language Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Language Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Config Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Loader Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:23:59 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:23:59 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:23:59 --> Session Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:23:59 --> Session routines successfully run
DEBUG - 2015-10-09 17:23:59 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Email Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Controller Class Initialized
DEBUG - 2015-10-09 17:23:59 --> Group MX_Controller Initialized
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:23:59 --> Model Class Initialized
DEBUG - 2015-10-09 17:23:59 --> DB Transaction Failure
ERROR - 2015-10-09 17:23:59 --> Query error: Table 'mfi.relationship' doesn't exist
DEBUG - 2015-10-09 17:23:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 17:24:01 --> Config Class Initialized
DEBUG - 2015-10-09 17:24:01 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:24:01 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:24:01 --> URI Class Initialized
DEBUG - 2015-10-09 17:24:01 --> Router Class Initialized
ERROR - 2015-10-09 17:24:01 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:24:21 --> Config Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:24:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:24:21 --> URI Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Router Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Output Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Security Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Input Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:24:21 --> Language Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Language Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Config Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Loader Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:24:21 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:24:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:24:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:24:21 --> Session Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:24:21 --> Session routines successfully run
DEBUG - 2015-10-09 17:24:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Email Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Controller Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:24:21 --> Model Class Initialized
DEBUG - 2015-10-09 17:24:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:24:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:24:21 --> Final output sent to browser
DEBUG - 2015-10-09 17:24:21 --> Total execution time: 0.1520
DEBUG - 2015-10-09 17:24:22 --> Config Class Initialized
DEBUG - 2015-10-09 17:24:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:24:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:24:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:24:22 --> URI Class Initialized
DEBUG - 2015-10-09 17:24:22 --> Router Class Initialized
ERROR - 2015-10-09 17:24:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:25:41 --> Config Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:25:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:25:41 --> URI Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Router Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Output Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Security Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Input Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:25:41 --> Language Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Language Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Config Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Loader Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:25:41 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:25:41 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:25:41 --> Session Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:25:41 --> Session routines successfully run
DEBUG - 2015-10-09 17:25:41 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Email Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Controller Class Initialized
DEBUG - 2015-10-09 17:25:41 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:25:41 --> Model Class Initialized
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:25:41 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:25:41 --> Final output sent to browser
DEBUG - 2015-10-09 17:25:41 --> Total execution time: 0.1363
DEBUG - 2015-10-09 17:25:42 --> Config Class Initialized
DEBUG - 2015-10-09 17:25:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:25:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:25:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:25:42 --> URI Class Initialized
DEBUG - 2015-10-09 17:25:42 --> Router Class Initialized
ERROR - 2015-10-09 17:25:42 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:26:29 --> Config Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:26:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:26:29 --> URI Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Router Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Output Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Security Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Input Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:26:29 --> Language Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Language Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Config Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Loader Class Initialized
DEBUG - 2015-10-09 17:26:29 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:26:29 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:26:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:26:30 --> Session Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:26:30 --> Session routines successfully run
DEBUG - 2015-10-09 17:26:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Email Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Controller Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:26:30 --> Config Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:26:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:26:30 --> URI Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Router Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Output Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Security Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Input Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:26:30 --> Language Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Language Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Config Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Loader Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:26:30 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:26:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:26:30 --> Session Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:26:30 --> Session routines successfully run
DEBUG - 2015-10-09 17:26:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Email Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Controller Class Initialized
DEBUG - 2015-10-09 17:26:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:26:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:26:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:26:30 --> Final output sent to browser
DEBUG - 2015-10-09 17:26:30 --> Total execution time: 0.1504
DEBUG - 2015-10-09 17:26:31 --> Config Class Initialized
DEBUG - 2015-10-09 17:26:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:26:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:26:31 --> URI Class Initialized
DEBUG - 2015-10-09 17:26:31 --> Router Class Initialized
ERROR - 2015-10-09 17:26:31 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:27:34 --> Config Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:27:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:27:34 --> URI Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Router Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Output Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Security Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Input Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:27:34 --> Language Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Language Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Config Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Loader Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:27:34 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:27:34 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:27:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:27:34 --> Session Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:27:34 --> Session routines successfully run
DEBUG - 2015-10-09 17:27:34 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Email Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Controller Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:27:34 --> Model Class Initialized
DEBUG - 2015-10-09 17:27:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:27:34 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:27:34 --> Final output sent to browser
DEBUG - 2015-10-09 17:27:34 --> Total execution time: 0.1673
DEBUG - 2015-10-09 17:27:35 --> Config Class Initialized
DEBUG - 2015-10-09 17:27:35 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:27:35 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:27:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:27:35 --> URI Class Initialized
DEBUG - 2015-10-09 17:27:35 --> Router Class Initialized
ERROR - 2015-10-09 17:27:35 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:27:39 --> Config Class Initialized
DEBUG - 2015-10-09 17:27:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:27:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:27:39 --> URI Class Initialized
DEBUG - 2015-10-09 17:27:39 --> Router Class Initialized
ERROR - 2015-10-09 17:27:39 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:28:39 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:28:39 --> URI Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Router Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Output Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Security Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Input Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:28:39 --> Language Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Language Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Loader Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:28:39 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:28:39 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:28:39 --> Session Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:28:39 --> Session routines successfully run
DEBUG - 2015-10-09 17:28:39 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Email Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Controller Class Initialized
DEBUG - 2015-10-09 17:28:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:28:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:28:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:28:39 --> Final output sent to browser
DEBUG - 2015-10-09 17:28:39 --> Total execution time: 0.1397
DEBUG - 2015-10-09 17:28:40 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:28:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:28:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:28:40 --> URI Class Initialized
DEBUG - 2015-10-09 17:28:40 --> Router Class Initialized
ERROR - 2015-10-09 17:28:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:28:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:28:46 --> URI Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Router Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Output Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Security Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Input Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:28:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Loader Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:28:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:28:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:28:46 --> Session Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:28:46 --> Session routines successfully run
DEBUG - 2015-10-09 17:28:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Email Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Controller Class Initialized
DEBUG - 2015-10-09 17:28:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:28:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:28:47 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:28:47 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:28:47 --> Model Class Initialized
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/microfinance/views/payments/all_group_payments.php
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:28:47 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:28:47 --> Final output sent to browser
DEBUG - 2015-10-09 17:28:47 --> Total execution time: 0.1472
DEBUG - 2015-10-09 17:28:47 --> Config Class Initialized
DEBUG - 2015-10-09 17:28:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:28:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:28:48 --> URI Class Initialized
DEBUG - 2015-10-09 17:28:48 --> Router Class Initialized
ERROR - 2015-10-09 17:28:48 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:29:45 --> Config Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:29:45 --> URI Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Router Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Output Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Security Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Input Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:29:45 --> Language Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Language Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Config Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Loader Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:29:45 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:29:45 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:29:45 --> Session Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:29:45 --> Session routines successfully run
DEBUG - 2015-10-09 17:29:45 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Email Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Controller Class Initialized
DEBUG - 2015-10-09 17:29:45 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:29:45 --> Model Class Initialized
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:29:45 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:29:45 --> Final output sent to browser
DEBUG - 2015-10-09 17:29:45 --> Total execution time: 0.1337
DEBUG - 2015-10-09 17:29:47 --> Config Class Initialized
DEBUG - 2015-10-09 17:29:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:29:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:29:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:29:47 --> URI Class Initialized
DEBUG - 2015-10-09 17:29:47 --> Router Class Initialized
ERROR - 2015-10-09 17:29:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:30:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:30:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:30:26 --> URI Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Router Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Output Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Security Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Input Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:30:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Loader Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:30:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:30:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:30:26 --> Session Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:30:26 --> Session routines successfully run
DEBUG - 2015-10-09 17:30:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Email Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Controller Class Initialized
DEBUG - 2015-10-09 17:30:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:30:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:30:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:30:26 --> Final output sent to browser
DEBUG - 2015-10-09 17:30:26 --> Total execution time: 0.1278
DEBUG - 2015-10-09 17:30:27 --> Config Class Initialized
DEBUG - 2015-10-09 17:30:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:30:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:30:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:30:27 --> URI Class Initialized
DEBUG - 2015-10-09 17:30:27 --> Router Class Initialized
ERROR - 2015-10-09 17:30:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:31:30 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:30 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Router Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Output Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Security Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Input Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:31:30 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Loader Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:31:30 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:31:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:31:30 --> Session Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:31:30 --> Session routines successfully run
DEBUG - 2015-10-09 17:31:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Email Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Controller Class Initialized
DEBUG - 2015-10-09 17:31:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:31:30 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/microfinance/views/payments/all_individual_payments.php
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:31:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:31:30 --> Final output sent to browser
DEBUG - 2015-10-09 17:31:30 --> Total execution time: 0.1414
DEBUG - 2015-10-09 17:31:31 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:31 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:31 --> Router Class Initialized
ERROR - 2015-10-09 17:31:31 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:31:39 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:39 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Router Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Output Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Security Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Input Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:31:39 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Loader Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:31:39 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:31:39 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:31:39 --> Session Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:31:39 --> Session routines successfully run
DEBUG - 2015-10-09 17:31:39 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Email Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Controller Class Initialized
DEBUG - 2015-10-09 17:31:39 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:31:39 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/microfinance/views/payments/list_group.php
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:31:39 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:31:39 --> Final output sent to browser
DEBUG - 2015-10-09 17:31:39 --> Total execution time: 0.1726
DEBUG - 2015-10-09 17:31:40 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:40 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:40 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:40 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:40 --> Router Class Initialized
ERROR - 2015-10-09 17:31:40 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:31:42 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:42 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Router Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Output Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Security Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Input Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:31:42 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Language Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Loader Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:31:42 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:31:42 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:31:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:31:42 --> Session Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:31:42 --> Session routines successfully run
DEBUG - 2015-10-09 17:31:42 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Email Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Controller Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:31:42 --> Model Class Initialized
DEBUG - 2015-10-09 17:31:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:31:42 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:31:42 --> Final output sent to browser
DEBUG - 2015-10-09 17:31:42 --> Total execution time: 0.1646
DEBUG - 2015-10-09 17:31:43 --> Config Class Initialized
DEBUG - 2015-10-09 17:31:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:31:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:31:43 --> URI Class Initialized
DEBUG - 2015-10-09 17:31:43 --> Router Class Initialized
ERROR - 2015-10-09 17:31:43 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:37:15 --> Config Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:37:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:37:15 --> URI Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Router Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Output Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Security Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Input Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:37:15 --> Language Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Language Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Config Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Loader Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:37:15 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:37:15 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:37:15 --> Session Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:37:15 --> Session routines successfully run
DEBUG - 2015-10-09 17:37:15 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Email Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Controller Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:37:15 --> Model Class Initialized
DEBUG - 2015-10-09 17:37:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:37:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:37:15 --> Final output sent to browser
DEBUG - 2015-10-09 17:37:15 --> Total execution time: 0.1581
DEBUG - 2015-10-09 17:37:16 --> Config Class Initialized
DEBUG - 2015-10-09 17:37:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:37:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:37:16 --> URI Class Initialized
DEBUG - 2015-10-09 17:37:16 --> Router Class Initialized
ERROR - 2015-10-09 17:37:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:39:28 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:39:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:39:28 --> URI Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Router Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Output Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Security Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Input Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:39:28 --> Language Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Language Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Loader Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:39:28 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:39:28 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:39:28 --> Session Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:39:28 --> Session routines successfully run
DEBUG - 2015-10-09 17:39:28 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Email Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Controller Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:39:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 17:39:28 --> Severity: Notice  --> Undefined variable: row C:\wamp\www\mfi\application\modules\microfinance\controllers\payments.php 111
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:39:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:39:28 --> Final output sent to browser
DEBUG - 2015-10-09 17:39:28 --> Total execution time: 0.1660
DEBUG - 2015-10-09 17:39:29 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:29 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:39:29 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:39:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:39:29 --> URI Class Initialized
DEBUG - 2015-10-09 17:39:29 --> Router Class Initialized
ERROR - 2015-10-09 17:39:29 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:39:51 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:39:51 --> URI Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Router Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Output Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Security Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Input Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:39:51 --> Language Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Language Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Loader Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:39:51 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:39:51 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:39:51 --> Session Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:39:51 --> Session routines successfully run
DEBUG - 2015-10-09 17:39:51 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Email Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Controller Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:39:51 --> Model Class Initialized
DEBUG - 2015-10-09 17:39:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:39:51 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:39:51 --> Final output sent to browser
DEBUG - 2015-10-09 17:39:51 --> Total execution time: 0.1752
DEBUG - 2015-10-09 17:39:52 --> Config Class Initialized
DEBUG - 2015-10-09 17:39:52 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:39:52 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:39:52 --> URI Class Initialized
DEBUG - 2015-10-09 17:39:52 --> Router Class Initialized
ERROR - 2015-10-09 17:39:52 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:40:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:40:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:40:26 --> URI Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Router Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Output Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Security Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Input Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:40:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Language Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Config Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Loader Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:40:26 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:40:26 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:40:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:40:26 --> Session Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:40:26 --> Session routines successfully run
DEBUG - 2015-10-09 17:40:26 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Email Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Controller Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:40:26 --> Model Class Initialized
DEBUG - 2015-10-09 17:40:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:40:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:40:26 --> Final output sent to browser
DEBUG - 2015-10-09 17:40:26 --> Total execution time: 0.1770
DEBUG - 2015-10-09 17:40:27 --> Config Class Initialized
DEBUG - 2015-10-09 17:40:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:40:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:40:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:40:27 --> URI Class Initialized
DEBUG - 2015-10-09 17:40:27 --> Router Class Initialized
ERROR - 2015-10-09 17:40:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:41:53 --> Config Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:41:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:41:53 --> URI Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Router Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Output Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Security Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Input Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:41:53 --> Language Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Language Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Config Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Loader Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:41:53 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:41:53 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:41:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:41:53 --> Session Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:41:53 --> Session routines successfully run
DEBUG - 2015-10-09 17:41:53 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Email Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Controller Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:41:53 --> Model Class Initialized
DEBUG - 2015-10-09 17:41:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:41:53 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:41:53 --> Final output sent to browser
DEBUG - 2015-10-09 17:41:53 --> Total execution time: 0.1720
DEBUG - 2015-10-09 17:41:54 --> Config Class Initialized
DEBUG - 2015-10-09 17:41:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:41:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:41:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:41:54 --> URI Class Initialized
DEBUG - 2015-10-09 17:41:54 --> Router Class Initialized
ERROR - 2015-10-09 17:41:54 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:42:28 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:42:28 --> URI Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Router Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Output Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Security Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Input Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:42:28 --> Language Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Language Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Loader Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:42:28 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:42:28 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:42:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:42:28 --> Session Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:42:28 --> Session routines successfully run
DEBUG - 2015-10-09 17:42:28 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Email Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Controller Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:42:28 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:42:28 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:42:28 --> Final output sent to browser
DEBUG - 2015-10-09 17:42:28 --> Total execution time: 0.1765
DEBUG - 2015-10-09 17:42:29 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:29 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:42:29 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:42:29 --> URI Class Initialized
DEBUG - 2015-10-09 17:42:29 --> Router Class Initialized
ERROR - 2015-10-09 17:42:29 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 17:42:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:42:46 --> URI Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Router Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Output Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Security Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Input Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 17:42:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Language Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Loader Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 17:42:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 17:42:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 17:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 17:42:46 --> Session Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 17:42:46 --> Session routines successfully run
DEBUG - 2015-10-09 17:42:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Email Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Controller Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 17:42:46 --> Model Class Initialized
DEBUG - 2015-10-09 17:42:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 17:42:46 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 17:42:46 --> Final output sent to browser
DEBUG - 2015-10-09 17:42:46 --> Total execution time: 0.1911
DEBUG - 2015-10-09 17:42:47 --> Config Class Initialized
DEBUG - 2015-10-09 17:42:47 --> Hooks Class Initialized
DEBUG - 2015-10-09 17:42:47 --> Utf8 Class Initialized
DEBUG - 2015-10-09 17:42:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 17:42:47 --> URI Class Initialized
DEBUG - 2015-10-09 17:42:47 --> Router Class Initialized
ERROR - 2015-10-09 17:42:47 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:01:23 --> Config Class Initialized
DEBUG - 2015-10-09 18:01:23 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:01:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:01:24 --> URI Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Router Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Output Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Security Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Input Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:01:24 --> Language Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Language Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Config Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Loader Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:01:24 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:01:24 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:01:24 --> Session Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:01:24 --> Session routines successfully run
DEBUG - 2015-10-09 18:01:24 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Email Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Controller Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:01:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:01:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:01:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:01:24 --> Final output sent to browser
DEBUG - 2015-10-09 18:01:24 --> Total execution time: 0.1987
DEBUG - 2015-10-09 18:01:25 --> Config Class Initialized
DEBUG - 2015-10-09 18:01:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:01:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:01:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:01:25 --> URI Class Initialized
DEBUG - 2015-10-09 18:01:25 --> Router Class Initialized
ERROR - 2015-10-09 18:01:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:02:30 --> Config Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:02:30 --> URI Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Router Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Output Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Security Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Input Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:02:30 --> Language Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Language Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Config Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Loader Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:02:30 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:02:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:02:30 --> Session Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:02:30 --> Session routines successfully run
DEBUG - 2015-10-09 18:02:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Email Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Controller Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:02:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:02:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:02:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:02:30 --> Final output sent to browser
DEBUG - 2015-10-09 18:02:30 --> Total execution time: 0.1399
DEBUG - 2015-10-09 18:02:31 --> Config Class Initialized
DEBUG - 2015-10-09 18:02:31 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:02:31 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:02:31 --> URI Class Initialized
DEBUG - 2015-10-09 18:02:31 --> Router Class Initialized
ERROR - 2015-10-09 18:02:31 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:04:14 --> Config Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:04:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:04:14 --> URI Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Router Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Output Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Security Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Input Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:04:14 --> Language Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Language Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Config Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Loader Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:04:14 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:04:14 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:04:14 --> Session Class Initialized
DEBUG - 2015-10-09 18:04:14 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:04:15 --> Session routines successfully run
DEBUG - 2015-10-09 18:04:15 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Email Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Controller Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:04:15 --> Model Class Initialized
DEBUG - 2015-10-09 18:04:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:04:15 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:04:15 --> Final output sent to browser
DEBUG - 2015-10-09 18:04:15 --> Total execution time: 0.1591
DEBUG - 2015-10-09 18:04:16 --> Config Class Initialized
DEBUG - 2015-10-09 18:04:16 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:04:16 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:04:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:04:16 --> URI Class Initialized
DEBUG - 2015-10-09 18:04:16 --> Router Class Initialized
ERROR - 2015-10-09 18:04:16 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:11:11 --> Config Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:11:11 --> URI Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Router Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Output Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Security Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Input Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:11:11 --> Language Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Language Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Config Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Loader Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:11:11 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:11:11 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:11:11 --> Session Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:11:11 --> Session routines successfully run
DEBUG - 2015-10-09 18:11:11 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Email Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Controller Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:11:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:11:11 --> DB Transaction Failure
ERROR - 2015-10-09 18:11:11 --> Query error: Unknown column '$gid' in 'where clause'
DEBUG - 2015-10-09 18:11:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:11:33 --> Config Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:11:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:11:33 --> URI Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Router Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Output Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Security Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Input Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:11:33 --> Language Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Language Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Config Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Loader Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:11:33 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:11:33 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:11:33 --> Session Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:11:33 --> Session routines successfully run
DEBUG - 2015-10-09 18:11:33 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Email Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Controller Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:11:33 --> Model Class Initialized
DEBUG - 2015-10-09 18:11:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:11:33 --> DB Transaction Failure
ERROR - 2015-10-09 18:11:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '> '$gid')
WHERE `20` IS NULL
ORDER BY `ASC` ASC
LIMIT 0' at line 2
DEBUG - 2015-10-09 18:11:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:12:18 --> Config Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:12:18 --> URI Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Router Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Output Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Security Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Input Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:12:18 --> Language Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Language Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Config Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Loader Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:12:18 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:12:18 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:12:18 --> Session Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:12:18 --> Session routines successfully run
DEBUG - 2015-10-09 18:12:18 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Email Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Controller Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:12:18 --> Model Class Initialized
DEBUG - 2015-10-09 18:12:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:12:18 --> DB Transaction Failure
ERROR - 2015-10-09 18:12:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1)
WHERE `20` IS NULL
ORDER BY `ASC` ASC
LIMIT 0' at line 2
DEBUG - 2015-10-09 18:12:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:13:10 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:13:10 --> URI Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Router Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Output Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Security Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Input Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:13:10 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Loader Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:13:10 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:13:10 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:13:10 --> Session Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:13:10 --> Session routines successfully run
DEBUG - 2015-10-09 18:13:10 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Email Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Controller Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:13:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:13:10 --> DB Transaction Failure
ERROR - 2015-10-09 18:13:10 --> Query error: Unknown column 'group_name' in 'order clause'
DEBUG - 2015-10-09 18:13:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:13:43 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:13:43 --> URI Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Router Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Output Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Security Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Input Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:13:43 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Loader Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:13:43 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:13:43 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:13:43 --> Session Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:13:43 --> Session routines successfully run
DEBUG - 2015-10-09 18:13:43 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Email Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Controller Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:13:43 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:13:43 --> DB Transaction Failure
ERROR - 2015-10-09 18:13:43 --> Query error: Unknown column 'group_name' in 'order clause'
DEBUG - 2015-10-09 18:13:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:13:46 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:13:46 --> URI Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Router Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Output Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Security Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Input Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:13:46 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Language Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Config Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Loader Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:13:46 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:13:46 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:13:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:13:46 --> Session Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:13:46 --> Session routines successfully run
DEBUG - 2015-10-09 18:13:46 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Email Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Controller Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:13:46 --> Model Class Initialized
DEBUG - 2015-10-09 18:13:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:13:46 --> DB Transaction Failure
ERROR - 2015-10-09 18:13:46 --> Query error: Unknown column 'group_name' in 'order clause'
DEBUG - 2015-10-09 18:13:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-09 18:14:10 --> Config Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:14:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:14:10 --> URI Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Router Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Output Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Security Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Input Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:14:10 --> Language Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Language Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Config Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Loader Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:14:10 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:14:10 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:14:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:14:10 --> Session Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:14:10 --> Session routines successfully run
DEBUG - 2015-10-09 18:14:10 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Email Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Controller Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:14:10 --> Model Class Initialized
DEBUG - 2015-10-09 18:14:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 43
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 44
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_email C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 43
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 44
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_email C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 43
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 44
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_email C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 43
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 44
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_email C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 43
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_contact_onames C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 44
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_email C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:14:11 --> Severity: Notice  --> Undefined property: stdClass::$group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
DEBUG - 2015-10-09 18:14:11 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:14:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:14:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:14:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:14:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:14:11 --> Final output sent to browser
DEBUG - 2015-10-09 18:14:11 --> Total execution time: 0.1852
DEBUG - 2015-10-09 18:14:12 --> Config Class Initialized
DEBUG - 2015-10-09 18:14:12 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:14:12 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:14:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:14:12 --> URI Class Initialized
DEBUG - 2015-10-09 18:14:12 --> Router Class Initialized
ERROR - 2015-10-09 18:14:12 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:15:09 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:15:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:15:09 --> URI Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Router Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Output Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Security Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Input Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:15:09 --> Language Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Language Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Loader Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:15:09 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:15:09 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:15:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:15:09 --> Session Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:15:09 --> Session routines successfully run
DEBUG - 2015-10-09 18:15:09 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Email Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Controller Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:15:09 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 42
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:09 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:15:09 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:15:09 --> Final output sent to browser
DEBUG - 2015-10-09 18:15:09 --> Total execution time: 0.1762
DEBUG - 2015-10-09 18:15:10 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:10 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:15:10 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:15:10 --> URI Class Initialized
DEBUG - 2015-10-09 18:15:10 --> Router Class Initialized
ERROR - 2015-10-09 18:15:10 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:15:37 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:15:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:15:37 --> URI Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Router Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Output Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Security Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Input Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:15:37 --> Language Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Language Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Loader Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:15:37 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:15:37 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:15:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:15:37 --> Session Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:15:37 --> Session routines successfully run
DEBUG - 2015-10-09 18:15:37 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Email Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Controller Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:15:37 --> Model Class Initialized
DEBUG - 2015-10-09 18:15:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:15:37 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:15:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:15:37 --> Final output sent to browser
DEBUG - 2015-10-09 18:15:37 --> Total execution time: 0.1925
DEBUG - 2015-10-09 18:15:38 --> Config Class Initialized
DEBUG - 2015-10-09 18:15:38 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:15:38 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:15:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:15:38 --> URI Class Initialized
DEBUG - 2015-10-09 18:15:38 --> Router Class Initialized
ERROR - 2015-10-09 18:15:38 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:16:24 --> Config Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:16:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:16:24 --> URI Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Router Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Output Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Security Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Input Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:16:24 --> Language Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Language Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Config Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Loader Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:16:24 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:16:24 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:16:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:16:24 --> Session Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:16:24 --> Session routines successfully run
DEBUG - 2015-10-09 18:16:24 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Email Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Controller Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:16:24 --> Model Class Initialized
DEBUG - 2015-10-09 18:16:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_contact_fname C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 73
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:16:24 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:16:24 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:16:24 --> Final output sent to browser
DEBUG - 2015-10-09 18:16:24 --> Total execution time: 0.2436
DEBUG - 2015-10-09 18:16:25 --> Config Class Initialized
DEBUG - 2015-10-09 18:16:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:16:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:16:25 --> URI Class Initialized
DEBUG - 2015-10-09 18:16:25 --> Router Class Initialized
ERROR - 2015-10-09 18:16:25 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:17:05 --> Config Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:17:05 --> URI Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Router Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Output Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Security Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Input Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:17:05 --> Language Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Language Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Config Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Loader Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:17:05 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:17:05 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:17:05 --> Session Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:17:05 --> Session routines successfully run
DEBUG - 2015-10-09 18:17:05 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Email Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Controller Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:17:05 --> Model Class Initialized
DEBUG - 2015-10-09 18:17:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 45
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 55
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_phone C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 74
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 76
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:17:06 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
DEBUG - 2015-10-09 18:17:06 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:17:06 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:17:06 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:17:06 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:17:06 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:17:06 --> Final output sent to browser
DEBUG - 2015-10-09 18:17:06 --> Total execution time: 0.2017
DEBUG - 2015-10-09 18:17:07 --> Config Class Initialized
DEBUG - 2015-10-09 18:17:07 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:17:07 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:17:07 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:17:07 --> URI Class Initialized
DEBUG - 2015-10-09 18:17:07 --> Router Class Initialized
ERROR - 2015-10-09 18:17:07 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:18:13 --> Config Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:18:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:18:13 --> URI Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Router Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Output Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Security Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Input Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:18:13 --> Language Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Language Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Config Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Loader Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:18:13 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:18:13 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:18:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:18:13 --> Session Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:18:13 --> Session routines successfully run
DEBUG - 2015-10-09 18:18:13 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Email Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Controller Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:18:13 --> Model Class Initialized
DEBUG - 2015-10-09 18:18:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 56
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 77
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 56
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 77
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 56
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 77
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 56
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 77
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 46
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 56
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 59
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 77
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:18:13 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:18:13 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:18:13 --> Final output sent to browser
DEBUG - 2015-10-09 18:18:13 --> Total execution time: 0.1946
DEBUG - 2015-10-09 18:18:14 --> Config Class Initialized
DEBUG - 2015-10-09 18:18:14 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:18:14 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:18:15 --> URI Class Initialized
DEBUG - 2015-10-09 18:18:15 --> Router Class Initialized
ERROR - 2015-10-09 18:18:15 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:19:11 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:19:11 --> URI Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Router Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Output Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Security Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Input Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:19:11 --> Language Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Language Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Loader Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:19:11 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:19:11 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:19:11 --> Session Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:19:11 --> Session routines successfully run
DEBUG - 2015-10-09 18:19:11 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Email Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Controller Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:19:11 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:11 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:19:11 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:19:11 --> Final output sent to browser
DEBUG - 2015-10-09 18:19:11 --> Total execution time: 0.1900
DEBUG - 2015-10-09 18:19:12 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:12 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:19:12 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:19:13 --> URI Class Initialized
DEBUG - 2015-10-09 18:19:13 --> Router Class Initialized
ERROR - 2015-10-09 18:19:13 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:19:27 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:19:27 --> URI Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Router Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Output Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Security Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Input Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:19:27 --> Language Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Language Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Loader Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:19:27 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:19:27 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:19:27 --> Session Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:19:27 --> Session routines successfully run
DEBUG - 2015-10-09 18:19:27 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Email Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Controller Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:19:27 --> Model Class Initialized
DEBUG - 2015-10-09 18:19:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
ERROR - 2015-10-09 18:19:27 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 80
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:19:27 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:19:27 --> Final output sent to browser
DEBUG - 2015-10-09 18:19:27 --> Total execution time: 0.2048
DEBUG - 2015-10-09 18:19:28 --> Config Class Initialized
DEBUG - 2015-10-09 18:19:28 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:19:28 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:19:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:19:28 --> URI Class Initialized
DEBUG - 2015-10-09 18:19:28 --> Router Class Initialized
ERROR - 2015-10-09 18:19:28 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:20:25 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:20:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:20:25 --> URI Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Router Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Output Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Security Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Input Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:20:25 --> Language Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Language Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Loader Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:20:25 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:20:25 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:20:25 --> Session Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:20:25 --> Session routines successfully run
DEBUG - 2015-10-09 18:20:25 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Email Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Controller Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:20:25 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:25 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:20:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:20:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:20:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:20:26 --> Final output sent to browser
DEBUG - 2015-10-09 18:20:26 --> Total execution time: 0.2687
DEBUG - 2015-10-09 18:20:27 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:27 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:20:27 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:20:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:20:27 --> URI Class Initialized
DEBUG - 2015-10-09 18:20:27 --> Router Class Initialized
ERROR - 2015-10-09 18:20:27 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:20:48 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:20:48 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:20:48 --> URI Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Router Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Output Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Security Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Input Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:20:48 --> Language Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Language Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Loader Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:20:48 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:20:48 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:20:48 --> Session Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:20:48 --> Session routines successfully run
DEBUG - 2015-10-09 18:20:48 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Email Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Controller Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:20:48 --> Model Class Initialized
DEBUG - 2015-10-09 18:20:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 47
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 57
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 60
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 78
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
ERROR - 2015-10-09 18:20:48 --> Severity: Notice  --> Undefined variable: group_name C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 79
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:20:48 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:20:48 --> Final output sent to browser
DEBUG - 2015-10-09 18:20:48 --> Total execution time: 0.1888
DEBUG - 2015-10-09 18:20:49 --> Config Class Initialized
DEBUG - 2015-10-09 18:20:49 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:20:49 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:20:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:20:49 --> URI Class Initialized
DEBUG - 2015-10-09 18:20:49 --> Router Class Initialized
ERROR - 2015-10-09 18:20:49 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:39:20 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:39:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:39:20 --> URI Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Router Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Output Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Security Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Input Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:39:20 --> Language Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Language Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Loader Class Initialized
DEBUG - 2015-10-09 18:39:20 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:39:20 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:39:21 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:39:21 --> Session Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:39:21 --> Session routines successfully run
DEBUG - 2015-10-09 18:39:21 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Email Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Controller Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:39:21 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 48
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 48
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 48
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 48
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 48
ERROR - 2015-10-09 18:39:21 --> Severity: Notice  --> Undefined variable: group_status C:\wamp\www\mfi\application\modules\microfinance\views\payments\edit_group_payment.php 58
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:39:21 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:39:21 --> Final output sent to browser
DEBUG - 2015-10-09 18:39:21 --> Total execution time: 0.1599
DEBUG - 2015-10-09 18:39:22 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:22 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:39:22 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:39:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:39:22 --> URI Class Initialized
DEBUG - 2015-10-09 18:39:22 --> Router Class Initialized
ERROR - 2015-10-09 18:39:22 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:39:54 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:39:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:39:54 --> URI Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Router Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Output Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Security Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Input Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:39:54 --> Language Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Language Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Loader Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:39:54 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:39:54 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:39:54 --> Session Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:39:54 --> Session routines successfully run
DEBUG - 2015-10-09 18:39:54 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Email Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Controller Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:39:54 --> Model Class Initialized
DEBUG - 2015-10-09 18:39:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:39:54 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:39:54 --> Final output sent to browser
DEBUG - 2015-10-09 18:39:54 --> Total execution time: 0.1584
DEBUG - 2015-10-09 18:39:55 --> Config Class Initialized
DEBUG - 2015-10-09 18:39:55 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:39:55 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:39:55 --> URI Class Initialized
DEBUG - 2015-10-09 18:39:55 --> Router Class Initialized
ERROR - 2015-10-09 18:39:55 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:48:51 --> Config Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:48:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:48:51 --> URI Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Router Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Output Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Security Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Input Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:48:51 --> Language Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Language Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Config Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Loader Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:48:51 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:48:51 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:48:51 --> Session Class Initialized
DEBUG - 2015-10-09 18:48:51 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:48:51 --> Session routines successfully run
DEBUG - 2015-10-09 18:48:52 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Email Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Controller Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:48:52 --> Model Class Initialized
DEBUG - 2015-10-09 18:48:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:48:52 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:48:52 --> Final output sent to browser
DEBUG - 2015-10-09 18:48:52 --> Total execution time: 0.1410
DEBUG - 2015-10-09 18:48:53 --> Config Class Initialized
DEBUG - 2015-10-09 18:48:53 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:48:53 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:48:53 --> URI Class Initialized
DEBUG - 2015-10-09 18:48:53 --> Router Class Initialized
ERROR - 2015-10-09 18:48:53 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:49:30 --> Config Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:49:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:49:30 --> URI Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Router Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Output Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Security Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Input Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:49:30 --> Language Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Language Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Config Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Loader Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:49:30 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:49:30 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:49:30 --> Session Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:49:30 --> Session routines successfully run
DEBUG - 2015-10-09 18:49:30 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Email Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Controller Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:49:30 --> Model Class Initialized
DEBUG - 2015-10-09 18:49:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:49:30 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:49:30 --> Final output sent to browser
DEBUG - 2015-10-09 18:49:30 --> Total execution time: 0.1362
DEBUG - 2015-10-09 18:49:32 --> Config Class Initialized
DEBUG - 2015-10-09 18:49:32 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:49:32 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:49:32 --> URI Class Initialized
DEBUG - 2015-10-09 18:49:32 --> Router Class Initialized
ERROR - 2015-10-09 18:49:32 --> 404 Page Not Found --> 
DEBUG - 2015-10-09 18:50:44 --> Config Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:50:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:50:44 --> URI Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Router Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Output Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Security Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Input Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-09 18:50:44 --> Language Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Language Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Config Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Loader Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Helper loaded: url_helper
DEBUG - 2015-10-09 18:50:44 --> Helper loaded: form_helper
DEBUG - 2015-10-09 18:50:44 --> Database Driver Class Initialized
ERROR - 2015-10-09 18:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\mfi\system\database\drivers\mysql\mysql_driver.php 92
DEBUG - 2015-10-09 18:50:44 --> Session Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Helper loaded: string_helper
DEBUG - 2015-10-09 18:50:44 --> Session routines successfully run
DEBUG - 2015-10-09 18:50:44 --> Form Validation Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Pagination Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Encrypt Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Email Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Controller Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Payments MX_Controller Initialized
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/models/file_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/models/individual_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/models/group_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/models/savings_plan_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/models/loans_plan_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/models/payments_model.php
DEBUG - 2015-10-09 18:50:44 --> Model Class Initialized
DEBUG - 2015-10-09 18:50:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/microfinance/views/payments/edit_group_payment.php
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2015-10-09 18:50:44 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2015-10-09 18:50:44 --> Final output sent to browser
DEBUG - 2015-10-09 18:50:44 --> Total execution time: 0.1551
DEBUG - 2015-10-09 18:50:45 --> Config Class Initialized
DEBUG - 2015-10-09 18:50:45 --> Hooks Class Initialized
DEBUG - 2015-10-09 18:50:45 --> Utf8 Class Initialized
DEBUG - 2015-10-09 18:50:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-09 18:50:45 --> URI Class Initialized
DEBUG - 2015-10-09 18:50:45 --> Router Class Initialized
ERROR - 2015-10-09 18:50:45 --> 404 Page Not Found --> 
