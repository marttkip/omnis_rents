<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-09 17:52:19 --> Config Class Initialized
DEBUG - 2016-02-09 17:52:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 17:52:19 --> Utf8 Class Initialized
DEBUG - 2016-02-09 17:52:19 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 17:52:19 --> URI Class Initialized
DEBUG - 2016-02-09 17:52:19 --> Router Class Initialized
DEBUG - 2016-02-09 17:52:20 --> No URI present. Default controller set.
DEBUG - 2016-02-09 17:52:20 --> Output Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Security Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Input Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 17:52:20 --> Language Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Language Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Config Class Initialized
DEBUG - 2016-02-09 17:52:20 --> Loader Class Initialized
DEBUG - 2016-02-09 17:52:21 --> Helper loaded: url_helper
DEBUG - 2016-02-09 17:52:21 --> Helper loaded: form_helper
DEBUG - 2016-02-09 17:52:23 --> Database Driver Class Initialized
DEBUG - 2016-02-09 17:52:23 --> Session Class Initialized
DEBUG - 2016-02-09 17:52:23 --> Helper loaded: string_helper
ERROR - 2016-02-09 17:52:23 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-09 17:52:23 --> Session routines successfully run
DEBUG - 2016-02-09 17:52:23 --> Form Validation Class Initialized
DEBUG - 2016-02-09 17:52:24 --> Pagination Class Initialized
DEBUG - 2016-02-09 17:52:24 --> Encrypt Class Initialized
DEBUG - 2016-02-09 17:52:24 --> Email Class Initialized
DEBUG - 2016-02-09 17:52:24 --> Controller Class Initialized
DEBUG - 2016-02-09 17:52:24 --> Auth MX_Controller Initialized
DEBUG - 2016-02-09 17:52:24 --> Model Class Initialized
DEBUG - 2016-02-09 17:52:24 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 17:52:24 --> Model Class Initialized
DEBUG - 2016-02-09 17:52:24 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 17:52:24 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:06 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:06 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:07 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:07 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:07 --> Router Class Initialized
DEBUG - 2016-02-09 20:35:07 --> No URI present. Default controller set.
DEBUG - 2016-02-09 20:35:07 --> Output Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Security Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Input Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:35:08 --> Language Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Language Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Loader Class Initialized
DEBUG - 2016-02-09 20:35:08 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:35:08 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:35:08 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:35:09 --> Session Class Initialized
DEBUG - 2016-02-09 20:35:09 --> Helper loaded: string_helper
ERROR - 2016-02-09 20:35:09 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-09 20:35:09 --> Session routines successfully run
DEBUG - 2016-02-09 20:35:10 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Email Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Controller Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Auth MX_Controller Initialized
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:10 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Router Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Output Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Security Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Input Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:35:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Loader Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:35:10 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:35:10 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Session Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:35:10 --> Session routines successfully run
DEBUG - 2016-02-09 20:35:10 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Email Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Controller Class Initialized
DEBUG - 2016-02-09 20:35:10 --> Auth MX_Controller Initialized
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:35:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:35:11 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:35:11 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-09 20:35:11 --> Final output sent to browser
DEBUG - 2016-02-09 20:35:11 --> Total execution time: 1.2837
DEBUG - 2016-02-09 20:35:16 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:16 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:16 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:16 --> Router Class Initialized
DEBUG - 2016-02-09 20:35:16 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:17 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Router Class Initialized
ERROR - 2016-02-09 20:35:17 --> 404 Page Not Found --> 
DEBUG - 2016-02-09 20:35:17 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:17 --> Config Class Initialized
DEBUG - 2016-02-09 20:35:17 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:35:17 --> Router Class Initialized
DEBUG - 2016-02-09 20:35:17 --> URI Class Initialized
DEBUG - 2016-02-09 20:35:17 --> Router Class Initialized
ERROR - 2016-02-09 20:35:17 --> 404 Page Not Found --> 
ERROR - 2016-02-09 20:35:17 --> 404 Page Not Found --> 
ERROR - 2016-02-09 20:35:17 --> 404 Page Not Found --> 
DEBUG - 2016-02-09 20:36:25 --> Config Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:36:25 --> URI Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Router Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Output Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Security Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Input Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:36:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Config Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Loader Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:36:25 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Session Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:36:25 --> Session routines successfully run
DEBUG - 2016-02-09 20:36:25 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Email Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Controller Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Auth MX_Controller Initialized
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-09 20:36:25 --> XSS Filtering completed
DEBUG - 2016-02-09 20:36:25 --> Unable to find validation rule: exists
DEBUG - 2016-02-09 20:36:25 --> XSS Filtering completed
DEBUG - 2016-02-09 20:36:25 --> Config Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:36:25 --> URI Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Router Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Output Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Security Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Input Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:36:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Config Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Loader Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:36:25 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Session Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:36:25 --> Session routines successfully run
DEBUG - 2016-02-09 20:36:25 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Email Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Controller Class Initialized
DEBUG - 2016-02-09 20:36:25 --> Admin MX_Controller Initialized
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:36:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:36:26 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:36:26 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:36:26 --> Model Class Initialized
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:36:26 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:36:26 --> Final output sent to browser
DEBUG - 2016-02-09 20:36:26 --> Total execution time: 0.9272
DEBUG - 2016-02-09 20:39:04 --> Config Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:39:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:39:04 --> URI Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Router Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Output Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Security Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Input Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:39:04 --> Language Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Language Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Config Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Loader Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:39:04 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:39:04 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Session Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:39:04 --> Session routines successfully run
DEBUG - 2016-02-09 20:39:04 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Email Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Controller Class Initialized
DEBUG - 2016-02-09 20:39:04 --> Reports MX_Controller Initialized
DEBUG - 2016-02-09 20:39:04 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:04 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:39:04 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:39:05 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/administration/views/reports/search/defaulters.php
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/administration/views/reports/all_defaulters.php
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:39:05 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:39:05 --> Final output sent to browser
DEBUG - 2016-02-09 20:39:05 --> Total execution time: 0.8570
DEBUG - 2016-02-09 20:39:21 --> Config Class Initialized
DEBUG - 2016-02-09 20:39:21 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:39:21 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:39:21 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:39:21 --> URI Class Initialized
DEBUG - 2016-02-09 20:39:21 --> Router Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Output Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Security Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Input Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:39:22 --> Language Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Language Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Config Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Loader Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:39:22 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:39:22 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Session Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:39:22 --> Session routines successfully run
DEBUG - 2016-02-09 20:39:22 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Email Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Controller Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Reports MX_Controller Initialized
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/administration/models/personnel_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:39:22 --> Model Class Initialized
DEBUG - 2016-02-09 20:39:22 --> Final output sent to browser
DEBUG - 2016-02-09 20:39:22 --> Total execution time: 0.4001
DEBUG - 2016-02-09 20:40:59 --> Config Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:40:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:40:59 --> URI Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Router Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Output Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Security Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Input Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:40:59 --> Language Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Language Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Config Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Loader Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:40:59 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:40:59 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Session Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:40:59 --> Session routines successfully run
DEBUG - 2016-02-09 20:40:59 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Email Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Controller Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Tenants MX_Controller Initialized
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:40:59 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:40:59 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:40:59 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:41:00 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:41:00 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/leases/view_lease.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/view_detail.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/real_estate_administration/views/tenants/all_tenants.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:41:00 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:41:00 --> Final output sent to browser
DEBUG - 2016-02-09 20:41:00 --> Total execution time: 1.2585
DEBUG - 2016-02-09 20:41:03 --> Config Class Initialized
DEBUG - 2016-02-09 20:41:03 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:41:03 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:41:03 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:41:03 --> URI Class Initialized
DEBUG - 2016-02-09 20:41:03 --> Router Class Initialized
ERROR - 2016-02-09 20:41:03 --> 404 Page Not Found --> 
DEBUG - 2016-02-09 20:41:18 --> Config Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:41:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:41:18 --> URI Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Router Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Output Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Security Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Input Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:41:18 --> Language Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Language Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Config Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Loader Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:41:18 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:41:18 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Session Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:41:18 --> Session routines successfully run
DEBUG - 2016-02-09 20:41:18 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Email Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Controller Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:18 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:41:18 --> Model Class Initialized
ERROR - 2016-02-09 20:41:18 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-09 20:41:19 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-09 20:41:19 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
ERROR - 2016-02-09 20:41:19 --> Severity: Notice  --> Undefined variable: amount_paid C:\xampp\htdocs\rents\application\modules\accounts\views\cash_office\tenants_list.php 149
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/accounts/views/cash_office/lease_details.php
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/accounts/views/cash_office/tenants_list.php
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:41:19 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:41:19 --> Final output sent to browser
DEBUG - 2016-02-09 20:41:19 --> Total execution time: 0.7669
DEBUG - 2016-02-09 20:41:24 --> Config Class Initialized
DEBUG - 2016-02-09 20:41:24 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:41:24 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:41:24 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:41:24 --> URI Class Initialized
DEBUG - 2016-02-09 20:41:24 --> Router Class Initialized
DEBUG - 2016-02-09 20:41:24 --> Output Class Initialized
DEBUG - 2016-02-09 20:41:24 --> Security Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Input Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:41:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Language Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Config Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Loader Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:41:25 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:41:25 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Session Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:41:25 --> Session routines successfully run
DEBUG - 2016-02-09 20:41:25 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Email Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Controller Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:41:25 --> Model Class Initialized
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:41:25 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:41:25 --> Final output sent to browser
DEBUG - 2016-02-09 20:41:25 --> Total execution time: 0.4204
DEBUG - 2016-02-09 20:42:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:42:10 --> URI Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Router Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Output Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Security Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Input Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:42:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Loader Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:42:10 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Session Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:42:10 --> Session routines successfully run
DEBUG - 2016-02-09 20:42:10 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Email Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Controller Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-09 20:42:10 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:10 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:10 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:42:10 --> URI Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Router Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Output Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Security Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Input Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:42:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Loader Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:42:10 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Session Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:42:10 --> Session routines successfully run
DEBUG - 2016-02-09 20:42:10 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Email Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Controller Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:42:10 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:42:10 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:42:10 --> Final output sent to browser
DEBUG - 2016-02-09 20:42:10 --> Total execution time: 0.2904
DEBUG - 2016-02-09 20:42:36 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:42:36 --> URI Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Router Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Output Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Security Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Input Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:42:36 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Loader Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:42:36 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:42:36 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Session Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:42:36 --> Session routines successfully run
DEBUG - 2016-02-09 20:42:36 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Email Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Controller Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:42:36 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-09 20:42:36 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:36 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:36 --> XSS Filtering completed
DEBUG - 2016-02-09 20:42:36 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Hooks Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Utf8 Class Initialized
DEBUG - 2016-02-09 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-09 20:42:36 --> URI Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Router Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Output Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Security Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Input Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-09 20:42:36 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Language Class Initialized
DEBUG - 2016-02-09 20:42:36 --> Config Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Loader Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Helper loaded: url_helper
DEBUG - 2016-02-09 20:42:37 --> Helper loaded: form_helper
DEBUG - 2016-02-09 20:42:37 --> Database Driver Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Session Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Helper loaded: string_helper
DEBUG - 2016-02-09 20:42:37 --> Session routines successfully run
DEBUG - 2016-02-09 20:42:37 --> Form Validation Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Pagination Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Encrypt Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Email Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Controller Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Accounts MX_Controller Initialized
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> Image Lib Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/real_estate_administration/models/tenants_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/real_estate_administration/models/rental_unit_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/real_estate_administration/models/leases_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/accounts/models/accounts_model.php
DEBUG - 2016-02-09 20:42:37 --> Model Class Initialized
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/accounts/views/cash_office/payments.php
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-09 20:42:37 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-09 20:42:37 --> Final output sent to browser
DEBUG - 2016-02-09 20:42:37 --> Total execution time: 0.4789
