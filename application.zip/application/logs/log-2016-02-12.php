<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-12 08:01:41 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:41 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:41 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:41 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:41 --> Router Class Initialized
DEBUG - 2016-02-12 08:01:41 --> No URI present. Default controller set.
DEBUG - 2016-02-12 08:01:41 --> Output Class Initialized
DEBUG - 2016-02-12 08:01:41 --> Security Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Input Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 08:01:42 --> Language Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Language Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Loader Class Initialized
DEBUG - 2016-02-12 08:01:42 --> Helper loaded: url_helper
DEBUG - 2016-02-12 08:01:42 --> Helper loaded: form_helper
DEBUG - 2016-02-12 08:01:42 --> Database Driver Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Session Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Helper loaded: string_helper
DEBUG - 2016-02-12 08:01:43 --> A session cookie was not found.
DEBUG - 2016-02-12 08:01:43 --> Session routines successfully run
DEBUG - 2016-02-12 08:01:43 --> Form Validation Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Pagination Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Encrypt Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Email Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Controller Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 08:01:43 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:43 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 08:01:43 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:43 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 08:01:43 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:43 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Router Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Output Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Security Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Input Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 08:01:43 --> Language Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Language Class Initialized
DEBUG - 2016-02-12 08:01:43 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Loader Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Helper loaded: url_helper
DEBUG - 2016-02-12 08:01:44 --> Helper loaded: form_helper
DEBUG - 2016-02-12 08:01:44 --> Database Driver Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Session Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Helper loaded: string_helper
DEBUG - 2016-02-12 08:01:44 --> Session routines successfully run
DEBUG - 2016-02-12 08:01:44 --> Form Validation Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Pagination Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Encrypt Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Email Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Controller Class Initialized
DEBUG - 2016-02-12 08:01:44 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 08:01:44 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:44 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 08:01:44 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:44 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 08:01:44 --> Model Class Initialized
DEBUG - 2016-02-12 08:01:44 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-12 08:01:44 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-12 08:01:44 --> Final output sent to browser
DEBUG - 2016-02-12 08:01:44 --> Total execution time: 0.4355
DEBUG - 2016-02-12 08:01:45 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:45 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Router Class Initialized
DEBUG - 2016-02-12 08:01:45 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:45 --> Router Class Initialized
ERROR - 2016-02-12 08:01:45 --> 404 Page Not Found --> 
ERROR - 2016-02-12 08:01:45 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:01:46 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:46 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:46 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:46 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:46 --> Router Class Initialized
ERROR - 2016-02-12 08:01:47 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:01:47 --> Config Class Initialized
DEBUG - 2016-02-12 08:01:47 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:01:47 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:01:47 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:01:47 --> URI Class Initialized
DEBUG - 2016-02-12 08:01:47 --> Router Class Initialized
ERROR - 2016-02-12 08:01:47 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:02:36 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:36 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Router Class Initialized
DEBUG - 2016-02-12 08:02:36 --> No URI present. Default controller set.
DEBUG - 2016-02-12 08:02:36 --> Output Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Security Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Input Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 08:02:36 --> Language Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Language Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Loader Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: url_helper
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: form_helper
DEBUG - 2016-02-12 08:02:36 --> Database Driver Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Session Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: string_helper
ERROR - 2016-02-12 08:02:36 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-12 08:02:36 --> Session routines successfully run
DEBUG - 2016-02-12 08:02:36 --> Form Validation Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Pagination Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Encrypt Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Email Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Controller Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:36 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Router Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Output Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Security Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Input Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 08:02:36 --> Language Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Language Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Loader Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: url_helper
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: form_helper
DEBUG - 2016-02-12 08:02:36 --> Database Driver Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Session Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Helper loaded: string_helper
DEBUG - 2016-02-12 08:02:36 --> Session routines successfully run
DEBUG - 2016-02-12 08:02:36 --> Form Validation Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Pagination Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Encrypt Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Email Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Controller Class Initialized
DEBUG - 2016-02-12 08:02:36 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 08:02:36 --> Model Class Initialized
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-12 08:02:36 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-12 08:02:36 --> Final output sent to browser
DEBUG - 2016-02-12 08:02:36 --> Total execution time: 0.1649
DEBUG - 2016-02-12 08:02:37 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:37 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Router Class Initialized
ERROR - 2016-02-12 08:02:37 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:02:37 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:37 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:37 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:37 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Router Class Initialized
ERROR - 2016-02-12 08:02:37 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:02:37 --> Router Class Initialized
ERROR - 2016-02-12 08:02:37 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 08:02:37 --> Config Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Utf8 Class Initialized
DEBUG - 2016-02-12 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 08:02:37 --> URI Class Initialized
DEBUG - 2016-02-12 08:02:37 --> Router Class Initialized
ERROR - 2016-02-12 08:02:38 --> 404 Page Not Found --> 
DEBUG - 2016-02-12 11:07:34 --> Config Class Initialized
DEBUG - 2016-02-12 11:07:34 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:07:34 --> Utf8 Class Initialized
DEBUG - 2016-02-12 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 11:07:34 --> URI Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Router Class Initialized
DEBUG - 2016-02-12 11:07:36 --> No URI present. Default controller set.
DEBUG - 2016-02-12 11:07:36 --> Output Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Security Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Input Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 11:07:36 --> Language Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Language Class Initialized
DEBUG - 2016-02-12 11:07:36 --> Config Class Initialized
DEBUG - 2016-02-12 11:07:37 --> Loader Class Initialized
DEBUG - 2016-02-12 11:07:37 --> Helper loaded: url_helper
DEBUG - 2016-02-12 11:07:37 --> Helper loaded: form_helper
DEBUG - 2016-02-12 11:07:38 --> Database Driver Class Initialized
DEBUG - 2016-02-12 11:07:38 --> Session Class Initialized
DEBUG - 2016-02-12 11:07:38 --> Helper loaded: string_helper
ERROR - 2016-02-12 11:07:38 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-12 11:07:38 --> Session routines successfully run
DEBUG - 2016-02-12 11:07:38 --> Form Validation Class Initialized
DEBUG - 2016-02-12 11:07:38 --> Pagination Class Initialized
DEBUG - 2016-02-12 11:07:39 --> Encrypt Class Initialized
DEBUG - 2016-02-12 11:07:39 --> Email Class Initialized
DEBUG - 2016-02-12 11:07:39 --> Controller Class Initialized
DEBUG - 2016-02-12 11:07:39 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 11:07:39 --> Model Class Initialized
DEBUG - 2016-02-12 11:07:39 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 11:07:39 --> Model Class Initialized
DEBUG - 2016-02-12 11:07:39 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 11:07:39 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:04 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:04 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:04 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:04 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:04 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:04 --> Router Class Initialized
DEBUG - 2016-02-12 17:10:04 --> No URI present. Default controller set.
DEBUG - 2016-02-12 17:10:04 --> Output Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Security Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Input Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:10:05 --> Language Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Language Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Loader Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:10:05 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:10:05 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Session Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Helper loaded: string_helper
ERROR - 2016-02-12 17:10:05 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-12 17:10:05 --> Session routines successfully run
DEBUG - 2016-02-12 17:10:05 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Encrypt Class Initialized
DEBUG - 2016-02-12 17:10:05 --> Email Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Controller Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:06 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Router Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Output Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Security Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Input Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:10:06 --> Language Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Language Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Loader Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:10:06 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:10:06 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Session Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:10:06 --> Session routines successfully run
DEBUG - 2016-02-12 17:10:06 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Encrypt Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Email Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Controller Class Initialized
DEBUG - 2016-02-12 17:10:06 --> Auth MX_Controller Initialized
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:06 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:06 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-12 17:10:06 --> Model Class Initialized
DEBUG - 2016-02-12 17:10:07 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-12 17:10:07 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-12 17:10:07 --> Final output sent to browser
DEBUG - 2016-02-12 17:10:07 --> Total execution time: 1.2344
DEBUG - 2016-02-12 17:10:09 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:09 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Router Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Config Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:09 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:10:09 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:09 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:10:09 --> Router Class Initialized
DEBUG - 2016-02-12 17:10:09 --> URI Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Router Class Initialized
DEBUG - 2016-02-12 17:10:09 --> Router Class Initialized
ERROR - 2016-02-12 17:10:09 --> 404 Page Not Found --> 
ERROR - 2016-02-12 17:10:09 --> 404 Page Not Found --> 
ERROR - 2016-02-12 17:10:09 --> 404 Page Not Found --> 
ERROR - 2016-02-12 17:10:09 --> 404 Page Not Found --> 
