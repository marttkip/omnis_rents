<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-04 10:31:15 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:16 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:16 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:16 --> Router Class Initialized
DEBUG - 2016-01-04 10:31:16 --> No URI present. Default controller set.
DEBUG - 2016-01-04 10:31:17 --> Output Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Security Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Input Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:31:17 --> Language Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Language Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Loader Class Initialized
DEBUG - 2016-01-04 10:31:17 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:31:17 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:31:17 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:31:25 --> Session Class Initialized
DEBUG - 2016-01-04 10:31:25 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:31:25 --> A session cookie was not found.
DEBUG - 2016-01-04 10:31:25 --> Session routines successfully run
DEBUG - 2016-01-04 10:31:25 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:31:25 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:31:25 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:31:25 --> Email Class Initialized
DEBUG - 2016-01-04 10:31:26 --> Controller Class Initialized
DEBUG - 2016-01-04 10:31:26 --> Auth MX_Controller Initialized
DEBUG - 2016-01-04 10:31:26 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:26 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:31:26 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:26 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:31:26 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:27 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Router Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Output Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Security Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Input Class Initialized
DEBUG - 2016-01-04 10:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:31:27 --> Language Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Language Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Loader Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:31:28 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:31:28 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Session Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:31:28 --> Session routines successfully run
DEBUG - 2016-01-04 10:31:28 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Email Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Controller Class Initialized
DEBUG - 2016-01-04 10:31:28 --> Auth MX_Controller Initialized
DEBUG - 2016-01-04 10:31:28 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:31:28 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:31:28 --> Model Class Initialized
DEBUG - 2016-01-04 10:31:30 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-04 10:31:30 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-04 10:31:30 --> Final output sent to browser
DEBUG - 2016-01-04 10:31:30 --> Total execution time: 2.1403
DEBUG - 2016-01-04 10:31:35 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:35 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:35 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Config Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Router Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:35 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Router Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:35 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:31:35 --> Router Class Initialized
DEBUG - 2016-01-04 10:31:35 --> URI Class Initialized
DEBUG - 2016-01-04 10:31:35 --> Router Class Initialized
ERROR - 2016-01-04 10:31:35 --> 404 Page Not Found --> 
ERROR - 2016-01-04 10:31:35 --> 404 Page Not Found --> 
ERROR - 2016-01-04 10:31:35 --> 404 Page Not Found --> 
ERROR - 2016-01-04 10:31:35 --> 404 Page Not Found --> 
DEBUG - 2016-01-04 10:32:15 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:32:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:32:15 --> URI Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Router Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Output Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Security Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Input Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:32:15 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Loader Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:32:15 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:32:15 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Session Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:32:15 --> Session routines successfully run
DEBUG - 2016-01-04 10:32:15 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Email Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Controller Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Auth MX_Controller Initialized
DEBUG - 2016-01-04 10:32:15 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:15 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:32:15 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:15 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:32:15 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-04 10:32:15 --> XSS Filtering completed
DEBUG - 2016-01-04 10:32:15 --> Unable to find validation rule: exists
DEBUG - 2016-01-04 10:32:15 --> XSS Filtering completed
DEBUG - 2016-01-04 10:32:15 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:32:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:32:15 --> URI Class Initialized
DEBUG - 2016-01-04 10:32:15 --> Router Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Output Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Security Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Input Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:32:16 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Loader Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:32:16 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:32:16 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Session Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:32:16 --> Session routines successfully run
DEBUG - 2016-01-04 10:32:16 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Email Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Controller Class Initialized
DEBUG - 2016-01-04 10:32:16 --> Admin MX_Controller Initialized
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-04 10:32:16 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-04 10:32:16 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-04 10:32:16 --> Final output sent to browser
DEBUG - 2016-01-04 10:32:16 --> Total execution time: 0.8354
DEBUG - 2016-01-04 10:32:21 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:32:21 --> URI Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Router Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Output Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Security Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Input Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:32:21 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Language Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Loader Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:32:21 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:32:21 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Session Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:32:21 --> Session routines successfully run
DEBUG - 2016-01-04 10:32:21 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Email Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Controller Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Property MX_Controller Initialized
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/admin/models/reports_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/admin/models/users_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/real_estate_administration/models/property_owners_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> File loaded: application/modules/real_estate_administration/models/property_model.php
DEBUG - 2016-01-04 10:32:21 --> Model Class Initialized
DEBUG - 2016-01-04 10:32:21 --> Image Lib Class Initialized
DEBUG - 2016-01-04 10:32:22 --> File loaded: application/modules/real_estate_administration/views/property/all_properties.php
DEBUG - 2016-01-04 10:32:22 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-04 10:32:22 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-01-04 10:32:22 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-01-04 10:32:22 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-01-04 10:32:22 --> Final output sent to browser
DEBUG - 2016-01-04 10:32:22 --> Total execution time: 0.7181
DEBUG - 2016-01-04 10:32:24 --> Config Class Initialized
DEBUG - 2016-01-04 10:32:24 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:32:24 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:32:24 --> URI Class Initialized
DEBUG - 2016-01-04 10:32:24 --> Router Class Initialized
ERROR - 2016-01-04 10:32:24 --> 404 Page Not Found --> 
DEBUG - 2016-01-04 10:56:52 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:52 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:52 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:52 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Router Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Output Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Security Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Input Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:56:53 --> Language Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Language Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:53 --> Loader Class Initialized
DEBUG - 2016-01-04 10:56:54 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:56:54 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:56:54 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:56:54 --> Session Class Initialized
DEBUG - 2016-01-04 10:56:54 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:56:54 --> Session routines successfully run
DEBUG - 2016-01-04 10:56:54 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:56:54 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:56:54 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Email Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Controller Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Auth MX_Controller Initialized
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:55 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Router Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Output Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Security Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Input Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-04 10:56:55 --> Language Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Language Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Loader Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Helper loaded: url_helper
DEBUG - 2016-01-04 10:56:55 --> Helper loaded: form_helper
DEBUG - 2016-01-04 10:56:55 --> Database Driver Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Session Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Helper loaded: string_helper
DEBUG - 2016-01-04 10:56:55 --> A session cookie was not found.
DEBUG - 2016-01-04 10:56:55 --> Session routines successfully run
DEBUG - 2016-01-04 10:56:55 --> Form Validation Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Pagination Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Encrypt Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Email Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Controller Class Initialized
DEBUG - 2016-01-04 10:56:55 --> Auth MX_Controller Initialized
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-01-04 10:56:55 --> Model Class Initialized
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-01-04 10:56:55 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-01-04 10:56:55 --> Final output sent to browser
DEBUG - 2016-01-04 10:56:55 --> Total execution time: 0.3621
DEBUG - 2016-01-04 10:56:57 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:57 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:57 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Router Class Initialized
DEBUG - 2016-01-04 10:56:57 --> Router Class Initialized
ERROR - 2016-01-04 10:56:57 --> 404 Page Not Found --> 
ERROR - 2016-01-04 10:56:57 --> 404 Page Not Found --> 
DEBUG - 2016-01-04 10:56:58 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:58 --> Config Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Utf8 Class Initialized
DEBUG - 2016-01-04 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-04 10:56:58 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Router Class Initialized
ERROR - 2016-01-04 10:56:58 --> 404 Page Not Found --> 
DEBUG - 2016-01-04 10:56:58 --> URI Class Initialized
DEBUG - 2016-01-04 10:56:58 --> Router Class Initialized
ERROR - 2016-01-04 10:56:58 --> 404 Page Not Found --> 
