<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-23 17:00:50 --> Config Class Initialized
DEBUG - 2016-02-23 17:00:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 17:00:50 --> Utf8 Class Initialized
DEBUG - 2016-02-23 17:00:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 17:00:51 --> URI Class Initialized
DEBUG - 2016-02-23 17:00:51 --> Router Class Initialized
DEBUG - 2016-02-23 17:00:51 --> No URI present. Default controller set.
DEBUG - 2016-02-23 17:00:51 --> Output Class Initialized
DEBUG - 2016-02-23 17:00:51 --> Security Class Initialized
DEBUG - 2016-02-23 17:00:51 --> Input Class Initialized
DEBUG - 2016-02-23 17:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 17:00:51 --> Language Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Language Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Config Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Loader Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Helper loaded: url_helper
DEBUG - 2016-02-23 17:00:52 --> Helper loaded: form_helper
DEBUG - 2016-02-23 17:00:52 --> Database Driver Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Session Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Helper loaded: string_helper
ERROR - 2016-02-23 17:00:52 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-23 17:00:52 --> Session routines successfully run
DEBUG - 2016-02-23 17:00:52 --> Form Validation Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Pagination Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Encrypt Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Email Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Controller Class Initialized
DEBUG - 2016-02-23 17:00:52 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 17:00:52 --> Model Class Initialized
DEBUG - 2016-02-23 17:00:52 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 17:00:52 --> Model Class Initialized
DEBUG - 2016-02-23 17:00:52 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 17:00:52 --> Model Class Initialized
DEBUG - 2016-02-23 17:13:19 --> Config Class Initialized
DEBUG - 2016-02-23 17:13:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 17:13:20 --> Utf8 Class Initialized
DEBUG - 2016-02-23 17:13:20 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 17:13:20 --> URI Class Initialized
DEBUG - 2016-02-23 17:13:21 --> Router Class Initialized
DEBUG - 2016-02-23 17:13:21 --> No URI present. Default controller set.
DEBUG - 2016-02-23 17:13:21 --> Output Class Initialized
DEBUG - 2016-02-23 17:13:22 --> Security Class Initialized
DEBUG - 2016-02-23 17:13:22 --> Input Class Initialized
DEBUG - 2016-02-23 17:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 17:13:22 --> Language Class Initialized
DEBUG - 2016-02-23 17:13:22 --> Language Class Initialized
DEBUG - 2016-02-23 17:13:22 --> Config Class Initialized
DEBUG - 2016-02-23 17:13:23 --> Loader Class Initialized
DEBUG - 2016-02-23 17:13:23 --> Helper loaded: url_helper
DEBUG - 2016-02-23 17:13:23 --> Helper loaded: form_helper
DEBUG - 2016-02-23 17:13:25 --> Database Driver Class Initialized
DEBUG - 2016-02-23 17:13:26 --> Session Class Initialized
DEBUG - 2016-02-23 17:13:26 --> Helper loaded: string_helper
ERROR - 2016-02-23 17:13:26 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-23 17:13:26 --> Session routines successfully run
DEBUG - 2016-02-23 17:13:26 --> Form Validation Class Initialized
DEBUG - 2016-02-23 17:13:27 --> Pagination Class Initialized
DEBUG - 2016-02-23 17:13:27 --> Encrypt Class Initialized
DEBUG - 2016-02-23 17:13:27 --> Email Class Initialized
DEBUG - 2016-02-23 17:13:27 --> Controller Class Initialized
DEBUG - 2016-02-23 17:13:27 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 17:13:28 --> Model Class Initialized
DEBUG - 2016-02-23 17:13:28 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 17:13:28 --> Model Class Initialized
DEBUG - 2016-02-23 17:13:28 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 17:13:28 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:48 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:48 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:11:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:48 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Router Class Initialized
DEBUG - 2016-02-23 20:11:49 --> No URI present. Default controller set.
DEBUG - 2016-02-23 20:11:49 --> Output Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Security Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Input Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:11:49 --> Language Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Language Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Loader Class Initialized
DEBUG - 2016-02-23 20:11:49 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:11:49 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:11:49 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Session Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:11:50 --> A session cookie was not found.
DEBUG - 2016-02-23 20:11:50 --> Session routines successfully run
DEBUG - 2016-02-23 20:11:50 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Email Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Controller Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:11:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:50 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Router Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Output Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Security Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Input Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:11:50 --> Language Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Language Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Loader Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:11:50 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:11:50 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Session Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:11:50 --> Session routines successfully run
DEBUG - 2016-02-23 20:11:50 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Email Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Controller Class Initialized
DEBUG - 2016-02-23 20:11:50 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:50 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:50 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:11:50 --> Model Class Initialized
DEBUG - 2016-02-23 20:11:51 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 20:11:51 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-23 20:11:51 --> Final output sent to browser
DEBUG - 2016-02-23 20:11:51 --> Total execution time: 0.6038
DEBUG - 2016-02-23 20:11:57 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:57 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:57 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:57 --> Router Class Initialized
DEBUG - 2016-02-23 20:11:57 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Router Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Config Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Utf8 Class Initialized
ERROR - 2016-02-23 20:11:57 --> 404 Page Not Found --> 
ERROR - 2016-02-23 20:11:57 --> 404 Page Not Found --> 
DEBUG - 2016-02-23 20:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:11:57 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:57 --> URI Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Router Class Initialized
DEBUG - 2016-02-23 20:11:57 --> Router Class Initialized
ERROR - 2016-02-23 20:11:57 --> 404 Page Not Found --> 
ERROR - 2016-02-23 20:11:57 --> 404 Page Not Found --> 
DEBUG - 2016-02-23 20:12:02 --> Config Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:12:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:12:02 --> URI Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Router Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Output Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Security Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Input Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:12:02 --> Language Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Language Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Config Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Loader Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:12:02 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Session Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:12:02 --> Session routines successfully run
DEBUG - 2016-02-23 20:12:02 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Email Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Controller Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-23 20:12:02 --> XSS Filtering completed
DEBUG - 2016-02-23 20:12:02 --> Unable to find validation rule: exists
DEBUG - 2016-02-23 20:12:02 --> XSS Filtering completed
DEBUG - 2016-02-23 20:12:02 --> Config Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:12:02 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:12:02 --> URI Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Router Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Output Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Security Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Input Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:12:02 --> Language Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Language Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Config Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Loader Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:12:02 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Session Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:12:02 --> Session routines successfully run
DEBUG - 2016-02-23 20:12:02 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Email Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Controller Class Initialized
DEBUG - 2016-02-23 20:12:02 --> Admin MX_Controller Initialized
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/admin/models/admin_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:02 --> File loaded: application/modules/administration/models/reports_model.php
DEBUG - 2016-02-23 20:12:02 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/models/sections_model.php
DEBUG - 2016-02-23 20:12:03 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/hr/models/personnel_model.php
DEBUG - 2016-02-23 20:12:03 --> Model Class Initialized
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/views/profile_page.php
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/views/includes/top_navigation.php
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/views/includes/sidebar.php
DEBUG - 2016-02-23 20:12:03 --> File loaded: application/modules/admin/views/templates/general_page.php
DEBUG - 2016-02-23 20:12:03 --> Final output sent to browser
DEBUG - 2016-02-23 20:12:03 --> Total execution time: 0.9464
DEBUG - 2016-02-23 20:42:43 --> Config Class Initialized
DEBUG - 2016-02-23 20:42:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:42:44 --> URI Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Router Class Initialized
DEBUG - 2016-02-23 20:42:44 --> No URI present. Default controller set.
DEBUG - 2016-02-23 20:42:44 --> Output Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Security Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Input Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:42:44 --> Language Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Language Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Config Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Loader Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:42:44 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:42:44 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:42:44 --> Session Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Helper loaded: string_helper
ERROR - 2016-02-23 20:42:45 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-02-23 20:42:45 --> Session routines successfully run
DEBUG - 2016-02-23 20:42:45 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Email Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Controller Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Config Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:42:45 --> URI Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Router Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Output Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Security Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Input Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:42:45 --> Language Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Language Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Config Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Loader Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:42:45 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:42:45 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Session Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:42:45 --> Session routines successfully run
DEBUG - 2016-02-23 20:42:45 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Email Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Controller Class Initialized
DEBUG - 2016-02-23 20:42:45 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:42:45 --> Model Class Initialized
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 20:42:45 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-23 20:42:45 --> Final output sent to browser
DEBUG - 2016-02-23 20:42:45 --> Total execution time: 0.3182
DEBUG - 2016-02-23 20:44:01 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:44:01 --> URI Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Router Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Output Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Security Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Input Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:44:01 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Loader Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:44:01 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:44:01 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Session Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:44:01 --> Session routines successfully run
DEBUG - 2016-02-23 20:44:01 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Email Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Controller Class Initialized
DEBUG - 2016-02-23 20:44:01 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:44:01 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:01 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:44:01 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:01 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:44:01 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:01 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 20:44:01 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-23 20:44:01 --> Final output sent to browser
DEBUG - 2016-02-23 20:44:01 --> Total execution time: 0.2086
DEBUG - 2016-02-23 20:44:56 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:44:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:44:56 --> URI Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Router Class Initialized
DEBUG - 2016-02-23 20:44:56 --> No URI present. Default controller set.
DEBUG - 2016-02-23 20:44:56 --> Output Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Security Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Input Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:44:56 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Loader Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:44:56 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Session Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:44:56 --> Session routines successfully run
DEBUG - 2016-02-23 20:44:56 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Email Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Controller Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Utf8 Class Initialized
DEBUG - 2016-02-23 20:44:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 20:44:56 --> URI Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Router Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Output Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Security Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Input Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 20:44:56 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Language Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Config Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Loader Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: url_helper
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: form_helper
DEBUG - 2016-02-23 20:44:56 --> Database Driver Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Session Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Helper loaded: string_helper
DEBUG - 2016-02-23 20:44:56 --> Session routines successfully run
DEBUG - 2016-02-23 20:44:56 --> Form Validation Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Pagination Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Encrypt Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Email Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Controller Class Initialized
DEBUG - 2016-02-23 20:44:56 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 20:44:56 --> Model Class Initialized
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 20:44:56 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-23 20:44:56 --> Final output sent to browser
DEBUG - 2016-02-23 20:44:56 --> Total execution time: 0.1565
DEBUG - 2016-02-23 21:08:36 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:36 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Router Class Initialized
DEBUG - 2016-02-23 21:08:36 --> No URI present. Default controller set.
DEBUG - 2016-02-23 21:08:36 --> Output Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Security Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Input Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 21:08:36 --> Language Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Language Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Loader Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: url_helper
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: form_helper
DEBUG - 2016-02-23 21:08:36 --> Database Driver Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Session Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: string_helper
DEBUG - 2016-02-23 21:08:36 --> Session routines successfully run
DEBUG - 2016-02-23 21:08:36 --> Form Validation Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Pagination Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Encrypt Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Email Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Controller Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 21:08:36 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:36 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 21:08:36 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:36 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 21:08:36 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:36 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Router Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Output Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Security Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Input Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-23 21:08:36 --> Language Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Language Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Loader Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: url_helper
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: form_helper
DEBUG - 2016-02-23 21:08:36 --> Database Driver Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Session Class Initialized
DEBUG - 2016-02-23 21:08:36 --> Helper loaded: string_helper
DEBUG - 2016-02-23 21:08:36 --> Session routines successfully run
DEBUG - 2016-02-23 21:08:36 --> Form Validation Class Initialized
DEBUG - 2016-02-23 21:08:37 --> Pagination Class Initialized
DEBUG - 2016-02-23 21:08:37 --> Encrypt Class Initialized
DEBUG - 2016-02-23 21:08:37 --> Email Class Initialized
DEBUG - 2016-02-23 21:08:37 --> Controller Class Initialized
DEBUG - 2016-02-23 21:08:37 --> Auth MX_Controller Initialized
DEBUG - 2016-02-23 21:08:37 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:37 --> File loaded: application/modules/auth/models/auth_model.php
DEBUG - 2016-02-23 21:08:37 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:37 --> File loaded: application/modules/site/models/site_model.php
DEBUG - 2016-02-23 21:08:37 --> Model Class Initialized
DEBUG - 2016-02-23 21:08:37 --> File loaded: application/modules/admin/views/includes/header.php
DEBUG - 2016-02-23 21:08:37 --> File loaded: application/modules/auth/views/templates/login.php
DEBUG - 2016-02-23 21:08:37 --> Final output sent to browser
DEBUG - 2016-02-23 21:08:37 --> Total execution time: 0.1559
DEBUG - 2016-02-23 21:08:39 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:39 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:39 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Router Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:39 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Config Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Utf8 Class Initialized
DEBUG - 2016-02-23 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-23 21:08:39 --> Router Class Initialized
DEBUG - 2016-02-23 21:08:39 --> URI Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Router Class Initialized
DEBUG - 2016-02-23 21:08:39 --> Router Class Initialized
ERROR - 2016-02-23 21:08:39 --> 404 Page Not Found --> 
ERROR - 2016-02-23 21:08:39 --> 404 Page Not Found --> 
ERROR - 2016-02-23 21:08:39 --> 404 Page Not Found --> 
ERROR - 2016-02-23 21:08:39 --> 404 Page Not Found --> 
