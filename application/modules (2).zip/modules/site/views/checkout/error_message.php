<div class="container main-container headerOffset">
  
  <div class="row innerPage">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="row userInfo">
        
        <p class="lead text-center">Oops your order could not be placed<br/><a class="btn btn-danger" href="<?php echo site_url().'checkout';?>"> <i class="fa fa-arrow-left"></i> &nbsp; Please try again </a> </p>
        
        
      </div>  <!--/row end-->
    </div>
  </div> <!--/.innerPage-->
  <div style="clear:both">  </div>
</div><!-- /.main-container -->


<div class="gap"> </div>